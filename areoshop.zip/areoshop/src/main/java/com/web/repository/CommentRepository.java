package com.web.repository;

import com.web.entity.Category;
import com.web.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {

    @Query(value = "select c from Comment c where c.product.id = ?1")
    public List<Comment> findByProId(Long id);

    @Query("select count(c.id) from Comment c where c.product.stall.id = ?1")
    public Long soLuongCommentShop(Long idshop);
}
