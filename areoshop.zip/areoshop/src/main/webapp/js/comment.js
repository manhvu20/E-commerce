var token = localStorage.getItem("token");

async function showComment(){
    var id = window.location.search.split('=')[1];
    var url = 'http://localhost:8080/api/public/comments?id='+id ;
    const resp = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var list = await resp.json();
    console.log(list)
    var mains = ''
    for(i=0; i<list.length; i++){
        var del = '<i onclick="deleteComment('+list[i].id+')" class="fa fa-trash xoabl"></i>'
        if(list[i].myComment != 1){
            del = ''
        }
        mains += `<div class="col-md-4">
                    <div class="comment-user">
                        <img src="https://cdn-icons-png.flaticon.com/512/552/552721.png">
                        <div class="content-comment">
                            <div class="top-comment-user">
                                <p class="user-comment">${list[i].user.fullname}</p>
                                <p class="time-comment"><i class="fa fa-clock"></i>${list[i].createdDate}</p>
                                ${del}
                            </div>
                            <p class="contentcmt">${list[i].content}</p>
                        </div>
                    </div>
                </div>`
    }
    document.getElementById("listbinhluan").innerHTML = mains
}

async function saveComment() {
    var id = window.location.search.split('=')[1];
    var url = 'http://localhost:8080/api/user/saveCommnet';
    var noidungbl = document.getElementById("noidungbl").value

    if(noidungbl == ""){
        alert("bạn chưa nhập nội dung")
        return;
    }
    var comment = {
        "content": noidungbl,
        "product":{
            "id":id
        }
    }
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(comment)
    });
    if (response.status < 300) {
        swal({title: "Thông báo", text: "đã đăng bình luận của bạn!", type: "success"},
        function(){ 
            showComment();
        });
    }
    else {
        swal({title: "Thông báo", text: "không thể bình luận!",type: "error"},
        function(){ });
    }
}

async function deleteComment(id){
    var url = 'http://localhost:8080/api/user/deletcomments?id='+id;
    const response = await fetch(url, {
        method: 'DELETE',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({title: "Thông báo", text: "đã xóa bình luận của bạn!", type: "success"},
        function(){ 
            showComment();
        });
    }
    else {
        swal({title: "Thông báo", text: "không thể xóa bình luận!",type: "error"},
        function(){ });
    }
}
