package com.web.repository;

import com.web.entity.Blog;
import com.web.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CartRepository extends JpaRepository<Cart, Long> {

    @Query("select c from Cart c where c.user.id = ?1 and c.product.name like ?2")
    public List<Cart> gioHangCuaToi(Long userId, String search);

    @Query("select c from  Cart c where c.user.id = ?1 and c.product.id = ?2")
    public Cart gioHangBySanPham(Long userId, Long productId);
}
