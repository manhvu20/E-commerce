package com.web.repository;

import com.web.entity.ProductVoucherProduct;
import com.web.entity.Province;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.util.List;

public interface ProductVoucherProductRepository extends JpaRepository<ProductVoucherProduct, Long> {

    @Modifying
    @Transactional
    @Query("delete from ProductVoucherProduct p where p.voucherProduct.id = ?1")
    int deleteByVoucherProductId(Long voucherId);

    @Query("select p from ProductVoucherProduct p where p.voucherProduct.id = ?1")
    public List<ProductVoucherProduct> findByVoucher(Long voucherId);

    @Query("select p from ProductVoucherProduct p where p.product.id = ?1 and (p.voucherProduct.numUsed < p.voucherProduct.maxNumber) and (p.voucherProduct.startDate <= ?2 and p.voucherProduct.endDate >= ?2)")
    public List<ProductVoucherProduct> findBySanPham(Long idproduct, Date ngayHienTai);
}
