package com.web.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "voucher_customer")
@Getter
@Setter
public class VoucherCustomer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    private String code;

    private String name;

    private Float discount;

    private Date startDate;

    private Date endDate;

    private Integer maxNumber;

    private Integer numUsed;

    private Integer quantityPurchased;

    @ManyToOne
    @JoinColumn(name = "stall_id")
    private Stall stall;
}
