var token = localStorage.getItem("token");

async function tinhdoanhthu(nam) {
    if(nam < 2000){
        nam = new Date().getFullYear() 
    }
    var url = 'http://localhost:8080/api/admin/doanhthuall?nam='+nam;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var list = await response.json();
    console.log(list)
    var main = '';
    for (i = 0; i < list.length; i++) {
       if(list[i] == null){
        list[i] = 0
       }
    }
    

    var lb = 'doanh thu năm '+nam ;
    const ctx = document.getElementById("chart").getContext('2d');
    const myChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ["tháng 1", "tháng 2", "tháng 3", "tháng 4",
        "tháng 5", "tháng 6","tháng 7","tháng 8","tháng 9","tháng 10","tháng 11","tháng 12"],
        datasets: [{
          label: lb,
          backgroundColor: 'rgba(161, 198, 247, 1)',
          borderColor: 'rgb(47, 128, 237)',
          data: list,
        }]
    },
      options: {
        scales: {
          yAxes: [{
            ticks: {
                callback: function (value) {
                    return formatmoney(value);
                }
            }
          }]
        }
      },
    });
}

function loadByNam(){
    var nam = document.getElementById("nams").value;
    tinhdoanhthu(nam);
}



async function thongKeTongQuat() {
    const response = await fetch('/api/admin/thong-ke-tong-quat', {
        headers: new Headers({
            "Authorization":  'Bearer ' + token
        })
    });
    var result = await response.json();
    console.log(result)
    document.getElementById("soDonTrongNgay").innerText = result.soDonTrongNgay
    document.getElementById("soDonTuanNay").innerText = result.soDonTuanNay
    document.getElementById("soDonThangNay").innerText = result.soDonThangNay
    document.getElementById("doanhThuhomnay").innerText = formatmoney(result.doanhThuNgay)
    document.getElementById("doanhthutuannay").innerText = formatmoney(result.doanhThuTuanNay)
    document.getElementById("doanhthuthangnay").innerText = formatmoney(result.doanhThuThangNay)
    veBieuDoTron(result.soDonHoanThanh, result.soDonHuy, result.soDonKhongNhan);
}

function veBieuDoTron(soDonHoanThanh, soDonHuy, soDonKhongNhan){
    const ctx = document.getElementById('myPieChart').getContext('2d');
    // Dữ liệu biểu đồ
    const data = {
        labels: ['Đơn hoàn thành', 'Đơn hủy', 'Đơn không nhận'], // Nhãn
        datasets: [{
            label: 'Số lượng đơn hàng',
            data: [soDonHoanThanh, soDonHuy, soDonKhongNhan], // Giá trị
            backgroundColor: [
                'rgba(255, 99, 132, 0.6)',  // Màu sắc từng phần
                'rgba(54, 162, 235, 0.6)',
                'rgba(255, 206, 86, 0.6)',
                'rgba(75, 192, 192, 0.6)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)'
            ],
            borderWidth: 1
        }]
    };

    // Cấu hình biểu đồ
    const config = {
        type: 'pie', // Loại biểu đồ
        data: data,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top', // Vị trí chú thích
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            return `${label}: ${value}`;
                        }
                    }
                }
            }
        }
    };

    // Vẽ biểu đồ
    new Chart(ctx, config);
}