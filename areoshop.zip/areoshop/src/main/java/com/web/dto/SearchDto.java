package com.web.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class SearchDto {

    private List<Long> dmId;

    private List<Long> tinhs;

    private Double small;

    private Double large;

    private String sortPrice;
}
