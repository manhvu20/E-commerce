package com.web.repository;

import com.web.entity.InvoiceDetail;
import com.web.entity.Province;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface InvoiceDetailRepository extends JpaRepository<InvoiceDetail, Long> {

    @Query("select sum(d.quantity) from InvoiceDetail d where d.product.id = ?1")
    public Double SumProduct(Long productId);
}
