package com.web.controller.user;

import com.web.entity.User;
import com.web.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AllViewUserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @RequestMapping(value = {"/","/home","index"}, method = RequestMethod.GET)
    public String getHomePage() {
        return "user/index.html";
    }

    @RequestMapping(value = {"/account"}, method = RequestMethod.GET)
    public String account() {
        return "user/account.html";
    }

    @RequestMapping(value = {"/blog"}, method = RequestMethod.GET)
    public String blog() {
        return "user/blog.html";
    }

    @RequestMapping(value = {"/cart"}, method = RequestMethod.GET)
    public String cart() {
        return "user/cart.html";
    }

    @RequestMapping(value = {"/chinhsach"}, method = RequestMethod.GET)
    public String chinhsach() {
        return "user/chinhsach.html";
    }

    @RequestMapping(value = {"/chitietbaiviet"}, method = RequestMethod.GET)
    public String chitietbaiviet() {
        return "user/chitietbaiviet.html";
    }

    @RequestMapping(value = {"/confirm"}, method = RequestMethod.GET)
    public String confirm() {
        return "user/confirm.html";
    }

    @RequestMapping(value = {"/detail"}, method = RequestMethod.GET)
    public String detail() {
        return "user/detail.html";
    }

    @RequestMapping(value = {"/login"}, method = RequestMethod.GET)
    public String login() {
        return "user/login.html";
    }

    @RequestMapping(value = {"/product"}, method = RequestMethod.GET)
    public String product() {
        return "user/product.html";
    }

    @RequestMapping(value = {"/shop"}, method = RequestMethod.GET)
    public String shop() {
        return "user/shop.html";
    }

    @RequestMapping(value = {"/chat"}, method = RequestMethod.GET)
    public String getViewChat(){
        return "user/chat";
    }






    @RequestMapping(value = "/keyactive", method = RequestMethod.GET)
    public String finishRegis(@RequestParam("key") String key){
        User user = userRepository.getUserByActivationKey(key).get();
        user.setActivation_key(null);
        user.setActived(1);
        userRepository.save(user);
        return "redirect:/";
    }
}
