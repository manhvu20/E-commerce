package com.web.service;

import com.web.dto.SearchDto;
import com.web.entity.Product;
import com.web.entity.ProductVoucherProduct;
import com.web.repository.ProductVoucherProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private ProductVoucherProductRepository productVoucherProductRepository;


    public List<Product> searchProduct(SearchDto searchDto){
        String sql = "SELECT p.* from product p INNER join product_category pc on pc.product_id = p.id\n" +
                "inner join stall s on s.id = p.stall_id inner join wards w on w.id = s.wards_id\n" +
                "inner join districts d on d.id = w.districts_id where ";
        if(searchDto.getSmall() == null){
            searchDto.setSmall(0D);
        }
        if(searchDto.getLarge() == null){
            searchDto.setLarge(100000000000D);
        }
        if(searchDto.getDmId().size() > 0){
            for(int i=0; i<searchDto.getDmId().size(); i++){
                if(i == 0){
                    sql += " (pc.category_id = ? ";
                }
                else {
                    sql += " or pc.category_id = ? ";
                }
                if(i == searchDto.getDmId().size() - 1){
                    sql += " ) and ";
                }
            }
        }
        for(int i=0; i<searchDto.getTinhs().size(); i++){
            if(i == 0){
                sql += " (d.province_id = ? ";
            }
            else {
                sql += " or d.province_id = ? ";
            }
            if(i == searchDto.getTinhs().size() - 1){
                sql += " ) and ";
            }
        }
        sql += " p.price >= ? and p.price <= ? and p.status_product = 1 and p.deleted = 0 and p.status_product = 1 group by p.id order by p.price "+searchDto.getSortPrice();
        int sizes = searchDto.getDmId().size() + searchDto.getTinhs().size() + 2;
        Object[] obj = new Object[sizes];
        int index = searchDto.getDmId().size();
        for(int i=0; i<searchDto.getDmId().size(); i++){
            obj[i] = searchDto.getDmId().get(i);
        }
        for(int i=0; i<searchDto.getTinhs().size(); i++){
            obj[index] = searchDto.getTinhs().get(i);
            ++index;
        }
        obj[index] = searchDto.getSmall();
        obj[index+1] = searchDto.getLarge();
        System.out.println("===================================");
        System.out.println(sql);
        System.out.println(obj.length);
        System.out.println("===================================");
        List<Product> list = jdbcTemplate.query(
                sql, obj,
                (rs, rowNum) -> new Product(rs.getLong("id")));
        return list;
    }
}
