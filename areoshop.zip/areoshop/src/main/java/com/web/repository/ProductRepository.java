package com.web.repository;

import com.web.entity.Product;
import com.web.entity.Province;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    @Query("select p from Product p where p.stall.user.id = ?1 and p.name like ?2 order by p.id desc ")
    public List<Product> findByUser(Long userId, String search);

    @Query("select p from Product p where p.stall.user.id = ?1 and p.statusProduct.id = ?2 and p.name like ?3 order by p.id desc ")
    public List<Product> findByUserAndStatusProduct(Long userId, Long statusPro, String search);

    @Query("select p from Product p inner join p.productCategories pc where p.stall.user.id = ?1 and p.name like ?2 and pc.category.id = ?3 order by p.id desc ")
    public List<Product> findByUserAndCategory(Long userId, String search, Long categoryId);

    @Query("select p from Product p inner join p.productCategories pc where p.stall.user.id = ?1 and p.statusProduct.id = ?2 and p.name like ?3 and pc.category.id = ?4 order by p.id desc ")
    public List<Product> findByUserAndStatusProductAndCategory(Long userId, Long statusPro, String search, Long categoryid);


    @Query("select p from Product p where p.deleted = 0 and p.statusProduct.id = 1 order by p.id desc ")
    public Page<Product> sanPhamMoi(Pageable pageable);

    @Query("select count(p.id) from Product p where p.stall.id = ?1 and p.statusProduct.id = 1")
    public Long tongSpTrongShop(Long idStall);

    @Query("select count(p.id) from Product p where p.stall.id = ?1")
    public Long tongSpTrongShopSaler(Long idStall);

    @Query("select count(p.id) from Product p where p.stall.id = ?1 and p.statusProduct.id = 3")
    public Long tongSpViPhamTrongShop(Long idStall);

    @Query("select count(p.id) from Product p where p.statusProduct.id = 3")
    public Long tongSpViPhamAdmin();

    @Query(value = "SELECT p.* from product p INNER JOIN product_category pc on pc.product_id = p.id where pc.category_id = ?1 and p.status_product = 1 GROUP BY p.id", nativeQuery = true)
    public List<Product> findByCategory(Long categoryId);

    @Query("select p from Product p where p.name like ?1 and p.statusProduct.id = 1 and p.deleted = 0")
    public List<Product> findByName(String param);

    @Query("select p from Product p where p.name like ?1 and p.deleted = 0")
    public List<Product> findByNameAdmin(String param);

    @Query(value = "SELECT p.* from product p INNER JOIN product_category pc on pc.product_id = p.id where pc.category_id = ?1 and p.name like ?2 GROUP BY p.id", nativeQuery = true)
    public List<Product> sanPhamByDanhMuc(Long categoryId, String search);

    @Query("select p from Product p inner join p.productCategories pc where p.statusProduct.id = ?1 and p.name like ?2 and pc.category.id = ?3 GROUP BY p.id ")
    public List<Product> sanPhamByDanhMucAndTrangThai(Long statusPro, String search, Long categoryid);

    @Query("select p from Product p where p.statusProduct.id = ?1 and p.name like ?2 order by p.id desc ")
    public List<Product> sanPhamByTrangThai(Long idstatus, String search);

    @Query(value = "select p.* from product p where p.stall_id = ?1 and p.status_product = 1 order by p.price asc", nativeQuery = true)
    public List<Product> findByShopAsc(Long idshop);

    @Query(value = "select p.* from product p where p.stall_id = ?1 and p.status_product = 1  order by p.price desc", nativeQuery = true)
    public List<Product> findByShopDesc(Long idshop);

    @Query(value = "select pc.product from ProductCategory pc where pc.product.stall.id = ?1 and pc.product.statusProduct.id = 1  and pc.category.id = ?2  order by pc.product.price desc")
    public List<Product> findByShopAndDanhmucDesc(Long idshop,Long iddm);

    @Query(value = "select pc.product from ProductCategory pc where pc.product.stall.id = ?1 and pc.product.statusProduct.id = 1  and pc.category.id = ?2  order by pc.product.price asc")
    public List<Product> findByShopAndDanhmucAsc(Long idshop,Long iddm);
}
