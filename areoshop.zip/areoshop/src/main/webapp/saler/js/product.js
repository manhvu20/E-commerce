var token = localStorage.getItem("token");


async function clickChonLoaiSp(e, idstatus){
    var listcn = document.getElementById("ulloaidonhang").children;
    for(j=0; j<listcn.length; j++){
        listcn[j].classList.remove("activechon");
    }
    e.classList.add("activechon");
    loadMyProduct(idstatus,"");
}
const listFile = [];

function loadInit() {
    $('input#choosefile').change(function () {
        var files = $(this)[0].files;
    });
    document.querySelector('#choosefile').addEventListener("change", previewImages);
    function previewImages() {
        var files = $(this)[0].files;
        for (i = 0; i < files.length; i++) {
            listFile.push(files[i]);
        }

        var preview = document.querySelector('#preview');

        // if (this.files) {
        //     [].forEach.call(this.files, readAndPreview);
        // }
        for (i = 0; i < files.length; i++) {
            readAndPreview(files[i]);
        }
        function readAndPreview(file) {

            // if (!/\.(jpe?g|png|gif)$/i.test(file.name)) {
            //     return alert(file.name + " is not an image");
            // }

            var reader = new FileReader(file);

            reader.addEventListener("load", function () {
                document.getElementById("chon-anhs").className = 'col-sm-4';
                document.getElementById("chon-anhs").style.height = '100px';
                document.getElementById("chon-anhs").style.marginTop = '5px';
                document.getElementById("choose-image").style.height = '120px';
                document.getElementById("numimage").innerHTML = '';
                document.getElementById("camera").style.fontSize = '20px';
                document.getElementById("camera").style.marginTop = '40px';
                document.getElementById("camera").className = 'fas fa-plus';
                document.getElementById("choose-image").style.width = '90%';

                var div = document.createElement('div');
                div.className = 'col-md-4';
                div.style.height = '120px';
                div.marginTop = '100px';
                preview.appendChild(div);

                var img = document.createElement('img');
                img.src = this.result;
                img.style.height = '85px';
                img.style.width = '90%';
                img.className = 'image-upload';
                img.style.marginTop = '5px';
                div.appendChild(img);

                var button = document.createElement('button');
                button.style.height = '30px';
                button.style.width = '90%';
                button.innerHTML = 'xóa'
                button.className = 'btn btn-warning';
                div.appendChild(button);
                
                button.addEventListener("click", function () {
                    div.remove();
                    console.log(listFile.length)
                    for(i=0; i<listFile.length; i++){
                        if(listFile[i] === file){
                            listFile.splice(i, 1);
                        }
                    }
                    console.log(listFile.length)
                });
            });

            reader.readAsDataURL(file);

        }

    }

}


async function loadAllCategory() {
    var url = 'http://localhost:8080/api/public/allcategory';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var list = await response.json();
    var main = '<option value="-1">Tất cả ngành hàng</option>';
    for (i = 0; i < list.length; i++) {
        main += `<option value="${list[i].id}">${list[i].name}</option>`
    }
    document.getElementById("listcatesearch").innerHTML = main
}

async function loadAllCategoryAdd() {
    var url = 'http://localhost:8080/api/public/allcategory';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var list = await response.json();
    var main = '';
    for (i = 0; i < list.length; i++) {
        main += `<option value="${list[i].id}">${list[i].name}</option>`
    }
    document.getElementById("danhmuc").innerHTML = main
}


async function loadAllStatusProduct() {
    var url = 'http://localhost:8080/api/public/statusproduct';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var list = await response.json();
    var main = '<li onclick="clickChonLoaiSp(this,-1)" class="chonloaihang activechon">Tất cả</li>';
    for (i = 0; i < list.length; i++) {
        main += `<li onclick="clickChonLoaiSp(this,${list[i].id})" class="chonloaihang">${list[i].name}</li>`
    }
    document.getElementById("ulloaidonhang").innerHTML = main
}

var idst = - 1
async function loadMyProduct(idstatus, search) {
    idst = idstatus;
    var url = 'http://localhost:8080/api/saler/Myproduct?statuspro='+idstatus+'&search='+search;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var list = await response.json();
    var main = '';
    for (i = 0; i < list.length; i++) {
        var xembl = `<p onclick="binhLuanSp(${list[i].id})" data-bs-toggle="modal" data-bs-target="#modalbinhluan" class="poiter">Xem đánh giá</p>`
        var hethangs = ``
        var vippham = '';
        if(list[i].statusProduct.id == 1){
            hethangs = `<a onclick="hetHang(${list[i].id})" class="poiter">Hết hàng</a><br><br>`
        }
        if(list[i].statusProduct.id == 2){
            hethangs = `<a onclick="hetHang(${list[i].id})" class="poiter">Còn hàng</a><br><br>`
        }
        if(list[i].statusProduct.id == 3){
            vippham = `<p onclick="hienViPham(${list[i].id})" data-bs-toggle="modal" data-bs-target="#lydovp" class="poiter">Lý do vi phạm</p>`
        }
        var dmuc = ''
        for(j=0; j<list[i].productCategories.length; j++){
            dmuc += list[i].productCategories[j].category.name +"<br>"
        }
        main += `<tr id="trsanpham${list[i].id}">
                    <td>${list[i].id}</td>
                    <td><img src="${list[i].banner}" style="width: 100px;"></td>
                    <td>${list[i].name}</td>
                    <td>${formatmoney(list[i].price)}</td>
                    <td>${list[i].quantity}</td>
                    <td><strong>${list[i].weight}</strong> kg/1sp</td>
                    <td>${list[i].doanhSo}</td>
                    <td>${dmuc}</td>
                    <td>
                        <a href="addproduct?id=${list[i].id}" class="poiter">Cập nhật</a><br>
                        ${hethangs}
                        ${vippham}
                        <p onclick="deleteProduct(${list[i].id})" class="poiter" style="color:red">xóa</p>
                    </td>
                    <td>${xembl}</td>
                </tr>`
    }
    document.getElementById("listproduct").innerHTML = main
    document.getElementById("soluongsp").innerHTML = list.length
}

async function loadMyProductSearch() {
    var search = document.getElementById("searchparam").value
    var category = document.getElementById("listcatesearch").value
    var url = 'http://localhost:8080/api/saler/myProductSearch?statuspro='+idst+'&search='+search+'&category='+category;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var list = await response.json();
    var main = '';
    for (i = 0; i < list.length; i++) {
        var xembl = `<p data-bs-toggle="modal" data-bs-target="#modalbinhluan" class="poiter">Xem đánh giá</p>`
        // if(list[i].statusProduct.id == 1 || list[i].statusProduct.id == 4){
        //     xembl = ''
        // }
        var dmuc = ''
        for(j=0; j<list[i].productCategories.length; j++){
            dmuc += list[i].productCategories[j].category.name +"<br>"
        }
        main += `<tr id="trsanpham${list[i].id}">
                    <td>${list[i].id}</td>
                    <td><img src="${list[i].banner}" style="width: 100px;"></td>
                    <td>${list[i].name}</td>
                    <td>${formatmoney(list[i].price)}</td>
                    <td>${list[i].quantity}</td>
                    <td>${list[i].doanhSo}</td>
                    <td>${dmuc}</td>
                    <td>
                        <a href="addproduct?id=${list[i].id}" class="poiter">Cập nhật</a><br><br>
                        <p onclick="deleteProduct(${list[i].id})" class="poiter" style="color:red">xóa</p>
                    </td>
                    <td>${xembl}</td>
                </tr>`
    }
    document.getElementById("listproduct").innerHTML = main
    document.getElementById("soluongsp").innerHTML = list.length
}

var bannerproduct = '';

async function saveProduct() {
    document.getElementById("loading").style.display = 'block'
    var id = window.location.search.split('=')[1];

    var url = 'http://localhost:8080/api/saler/addProduct';
    var tensp = document.getElementById("tensp").value
    var price = document.getElementById("price").value
    var soluong = document.getElementById("soluong").value
    var weight = document.getElementById("weight").value
    var danhmuc = $("#danhmuc").val();
    var description = tinyMCE.get('editor').getContent()

    const filePath = document.getElementById('imagebanner')
    const formData = new FormData()
    formData.append("file", filePath.files[0])
    var urlUpload = 'http://localhost:8080/api/public/upload';
    const res = await fetch(urlUpload, { 
        method: 'POST', 
        headers: new Headers({
        }),
        body: formData
    });
    if(res.status < 300){
        bannerproduct = await res.text();
    }

    var product = {
        "id": id,
        "name": tensp,
        "price":price,
        "quantity":soluong,
        "weight":weight,
        "banner":bannerproduct,
        "description":description,
        "listIdDm":danhmuc
    }

    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(product)
    });
    var result = await response.json();
    console.log(result)
    if (response.status < 300) {
        var urladdImage = 'http://localhost:8080/api/all/addImageproduct';
        var urlUpload = 'http://localhost:8080/api/public/upload';
    
        for(i=0; i<listFile.length; i++){
            const formData = new FormData()
            formData.append("file", listFile[i])
            const res = await fetch(urlUpload, { 
                     method: 'POST', 
                      headers: new Headers({
                     }),
                     body: formData
                   });
            var linkbanners = await res.text();
            
            var imgProduct = {
                "linkImage":linkbanners,
                "product":{
                    "id":result.id
                }
            }
            const response = await fetch(urladdImage, {
                method: 'POST',
                headers: new Headers({
                    'Authorization': 'Bearer ' + token,
                    'Content-Type': 'application/json'
                }),
                body: JSON.stringify(imgProduct)
            });
        }
        swal({
            title: "Thông báo", 
            text: "thêm/sửa sản phẩm thành công!", 
            type: "success"
          },
        function(){ 
            document.getElementById("loading").style.display = 'none'
            window.location.replace('product')
        });
    }
    else {
        swal({
            title: "Thông báo", 
            text: "thêm/sửa sản phẩm thất bại", 
            type: "error"
          },
        function(){ 
            document.getElementById("loading").style.display = 'none'
            window.location.reload();
        });
    }
}

async function loadAProduct() {
    var id = window.location.search.split('=')[1];
    if(id != null){
        var url = 'http://localhost:8080/api/public/productByID?id='+id;
        const response = await fetch(url, {
            method: 'GET',
            headers: new Headers({
            })
        });
        var product = await response.json();
        document.getElementById("tensp").value = product.name
        document.getElementById("price").value = product.price
        document.getElementById("soluong").value = product.quantity
        document.getElementById("weight").value = product.weight
        document.getElementById("anhendathem").src = product.banner
        document.getElementById("anhnendiv").style.display = 'block'
        bannerproduct = product.banner


        var listImage = product.imageProducts;
        var maini = ''
        for(i=0; i<listImage.length; i++){
            maini +='<div class="col-md-4" id="divimgs'+listImage[i].id+'">'+
                        '<img style="width: 100%;" src="'+listImage[i].linkImage+'" class="image-upload">'+
                        '<button onclick="deleteImage('+listImage[i].id+')" class="btn btn-danger form-control">Xóa ảnh</button>'+
                    '</div>'
        }
        document.getElementById("anhdathem").innerHTML += maini
        var dms = [];
        for(i=0; i<product.productCategories.length; i++){
            dms.push(product.productCategories[i].category.id)
        }
        console.log(dms)
        $("#danhmuc").val(dms);

        await new Promise(r => setTimeout(r, 500));
        tinyMCE.get('editor').setContent(product.description)
    }
    else{
        document.getElementById("anhdathem").innerHTML = ''
    }
}

async function deleteImage(id) {
    var checkss = confirm("bạn muốn xóa ảnh này?");
    if(checkss){
        var url = 'http://localhost:8080/api/all/deleteImageProduct?id='+id;
        const response = await fetch(url, {
            method: 'DELETE',
            headers: new Headers({
                'Authorization': 'Bearer ' + token
            })
        });
        if(response.status < 300){
            swal({
                title: "Thông báo", 
                text: "xóa ảnh sản phẩm thành công!", 
                type: "success"
              },
            function(){ 
                document.getElementById("divimgs"+id).style.display = 'none'
            });
        }
        else{
            swal({
                title: "Thông báo", 
                text: "xóa ảnh sản phẩm thất bại!", 
                type: "error"
              },
            function(){ 
            });
        }
    }
}

async function deleteProduct(id) {
    var checkss = confirm("bạn muốn xóa sản phẩm này?");
    if(checkss){
        var url = 'http://localhost:8080/api/saler/deleteProduct?id='+id;
        const response = await fetch(url, {
            method: 'DELETE',
            headers: new Headers({
                'Authorization': 'Bearer ' + token
            })
        });
        if(response.status < 300){
            swal({
                title: "Thông báo", 
                text: "xóa sản phẩm thành công!", 
                type: "success"
              },
            function(){ 
                document.getElementById("trsanpham"+id).style.display = 'none'
            });
        }
        else{
            swal({
                title: "Thông báo", 
                text: "xóa sản phẩm thất bại!", 
                type: "error"
              },
            function(){ 
            });
        }
    }
}


async function hetHang(id) {
    var url = 'http://localhost:8080/api/saler/setSanPhamHetHang?id=' + id;
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({
            title: "Thông báo", 
            text: "Thành công!", 
            type: "success"
          },
        function(){ 
            window.location.reload();
        });
    }
}


async function hienViPham(id){
    var url = 'http://localhost:8080/api/public/productByID?id='+id;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var product = await response.json();
    document.getElementById("noidungfeedback").innerHTML = product.feedBackByAdmin;
}


async function binhLuanSp(id){
    var url = 'http://localhost:8080/api/public/comments?id='+id ;
    const resp = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var list = await resp.json();
    console.log(list)
    var mains = ''
    for(i=0; i<list.length; i++){
        mains += `<div class="col-md-12">
                    <div class="comment-user">
                        <img src="https://cdn-icons-png.flaticon.com/512/552/552721.png">
                        <div class="content-comment">
                            <div class="top-comment-user">
                                <p class="user-comment">${list[i].user.fullname}</p>
                                <p class="time-comment"><i class="fa fa-clock"></i>${list[i].createdDate}</p>
                                <i onclick="deleteComment(${list[i].id})" class="fa fa-trash xoabl"></i>
                            </div>
                            <p class="contentcmt">${list[i].content}</p>
                        </div>
                    </div>
                </div>`
    }
    document.getElementById("listbinhluan").innerHTML = mains
}

async function deleteComment(id){
    var url = 'http://localhost:8080/api/saler/deletcommentssaler?id='+id;
    const response = await fetch(url, {
        method: 'DELETE',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({title: "Thông báo", text: "đã xóa bình luận của bạn!", type: "success"},
        function(){ 
            $('#modalbinhluan').modal('hide');
        });
    }
    else {
        swal({title: "Thông báo", text: "không thể xóa bình luận!",type: "error"},
        function(){ });
    }
}
