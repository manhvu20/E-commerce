package com.web.rest;

import com.web.dto.InvoiceDto;
import com.web.dto.InvoiceRequest;
import com.web.dto.ShippingDto;
import com.web.entity.*;
import com.web.repository.*;
import com.web.service.MailService;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.relational.core.sql.In;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class InvoiceRest {

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private StatusInvoiceRepository statusInvoiceRepository;

    @Autowired
    private AddressUserRepository addressUserRepository;

    @Autowired
    private InvoiceDetailRepository invoiceDetailRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ShipperRepository shipperRepository;

    @Autowired
    private VoucherCustomerRepository voucherCustomerRepository;

    @Autowired
    private ProductVoucherProductRepository productVoucherProductRepository;

    @Autowired
    private VoucherProductRepository voucherProductRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private StallRepository stallRepository;

    @Autowired
    private MailService mailService;


    @PostMapping("/user/taoDonHang")
    public void taoDonHang(@RequestBody InvoiceRequest invoiceRequest,
                           @RequestParam("iddiachi") Long idDiaChi){
        User user = userService.getUserWithAuthority();
        List<InvoiceDto> invoiceDtos = invoiceRequest.getInvoiceDtos();
        List<VoucherCustomer> listCustomer = new ArrayList<>();
        List<ProductVoucherProduct> listVoucherPro = new ArrayList<>();


        Set<Long> dsStall = new HashSet<>();
        Set<Long> dssp = new HashSet<>();
        for(InvoiceDto i : invoiceDtos){
            dsStall.add(i.getProduct().getStall().getId());
            dssp.add(i.getProduct().getId());
        }
        for(Long l : dsStall){
            List<VoucherCustomer> vou = voucherCustomerRepository.findByStallDangDienRaConLai(l, new Date(System.currentTimeMillis()));
            if(vou.size() > 0){
                if(vou.get(vou.size() - 1).getQuantityPurchased() <= invoiceRepository.findByUserAndStall(user.getId(), l).size()){
                    listCustomer.add(vou.get(vou.size() - 1));
                }
            }
        }

        for(Long l : dssp){
            List<ProductVoucherProduct> ds = productVoucherProductRepository.findBySanPham(l, new Date(System.currentTimeMillis()));
            if(ds.size() > 0){
                listVoucherPro.add(ds.get(ds.size() - 1));
            }
        }

        List<List<InvoiceDto>> listpro = new ArrayList<>();
        for(InvoiceDto i : invoiceDtos){
            boolean check = true;
            for(List<InvoiceDto> l : listpro){
                if(l.get(0).getProduct().getStall().getId() == i.getProduct().getStall().getId()){
                    l.add(i);
                    check = false;
                }
            }
            if (check == true){
                List<InvoiceDto> l = new ArrayList<>();
                l.add(i);
                listpro.add(l);
            }
        }
        AddressUser addressUser = addressUserRepository.findById(idDiaChi).get();
        for(List<InvoiceDto> l : listpro){
            Invoice invoice = new Invoice();
            invoice.setFullname(addressUser.getUser().getFullname());
            invoice.setAddress(addressUser.getStreetName()+", "+addressUser.getWards().getName()+", "+addressUser.getWards().getDistricts().getName()+", "+addressUser.getWards().getDistricts().getProvince().getName());
            invoice.setPhone(addressUser.getUser().getPhone());
            invoice.setStatusInvoice(statusInvoiceRepository.findById(1L).get());
            invoice.setAddressUser(addressUserRepository.findById(idDiaChi).get());
            invoice.setCreatedDate(new Date(System.currentTimeMillis()));
            invoice.setStall(l.get(0).getProduct().getStall());
            invoice.setTotalAmount(0D);
            for(ShippingDto s :invoiceRequest.getShippingDtos()){
                if(s.getStaffId() == invoice.getStall().getId()){
                    invoice.setShipCost(s.getShipCost());
                }
            }
            for(VoucherCustomer v : listCustomer){
                if(v.getStall().getId() == invoice.getStall().getId()){
                    invoice.setVoucherCustomer(v);
                }
            }

            for(InvoiceDto i : l){
                for(ProductVoucherProduct v : listVoucherPro){
                    if(v.getProduct().getId() == i.getProduct().getId()){
                        Double tong = invoice.getTotalAmount() +
                                (i.getProduct().getPrice() * i.getSoLuong() - i.getProduct().getPrice() * i.getSoLuong() * v.getVoucherProduct().getDiscount()/100);
                        invoice.setTotalAmount(tong);
                        i.setCheck(true);
                    }
                }
            }
            for(InvoiceDto i : l){
                if(i.getCheck() == false){
                    Double tong = invoice.getTotalAmount() +
                            (i.getProduct().getPrice() * i.getSoLuong());
                    invoice.setTotalAmount(tong);
                }
            }
            if(invoice.getVoucherCustomer() != null){
                invoice.setTotalAmount(invoice.getTotalAmount() - invoice.getTotalAmount() * invoice.getVoucherCustomer().getDiscount()/100);
            }
            Invoice result = invoiceRepository.save(invoice);
            for(VoucherCustomer v : listCustomer){
                v.setNumUsed(v.getNumUsed() + 1);
                voucherCustomerRepository.save(v);
            }

            for(InvoiceDto i : l){
                InvoiceDetail invoiceDetail = new InvoiceDetail();
                for(ProductVoucherProduct v : listVoucherPro){
                    if(v.getProduct().getId() == i.getProduct().getId()){
                        invoiceDetail.setProductVoucherProduct(v);
                    }
                }
                invoiceDetail.setInvoice(result);
                invoiceDetail.setProduct(i.getProduct());
                invoiceDetail.setPrice(i.getProduct().getPrice());
                invoiceDetail.setQuantity(i.getSoLuong());
                invoiceDetailRepository.save(invoiceDetail);
                i.getProduct().setQuantity(i.getProduct().getQuantity() - i.getSoLuong());
                i.getProduct().setDoanhSo(i.getProduct().getDoanhSo() + i.getSoLuong());
                productRepository.save(i.getProduct());
                Cart c = cartRepository.gioHangBySanPham(user.getId(), i.getProduct().getId());
                cartRepository.deleteById(c.getId());
            }
            for(ProductVoucherProduct v : listVoucherPro){
                v.getVoucherProduct().setNumUsed(v.getVoucherProduct().getNumUsed() + 1);
                voucherProductRepository.save(v.getVoucherProduct());
            }
        }
    }

    @GetMapping("/user/donHangCuaToi")
    public List<Invoice> donHangCuaToi(@RequestParam(value = "idtrangthai", required = false) Long id,
                                       @RequestParam(value = "search", required = false) String tensp){
        List<Invoice> list = null;
        if (tensp == null){
            tensp = "";
        }
        if(id == null){
            list = invoiceRepository.donHangCuaToi(userService.getUserWithAuthority().getId(), "%"+tensp+"%");
        }
        else{
            list = invoiceRepository.donHangCuaToiByTrangThai(userService.getUserWithAuthority().getId(), id);
        }
        return list;
    }

    @GetMapping("/saler/donHangCuaShop")
    public List<Invoice> donHangCuaShop(@RequestParam(value = "start", required = false) Date start,
                                        @RequestParam(value = "end", required = false) Date end,
                                        @RequestParam(value = "idtrangthaidh", required = false) Long idtrangthaidh){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        if(start == null || end == null){
            start = Date.valueOf("2000-01-01");
            end = Date.valueOf("2100-01-01");
        }
        List<Invoice> list = null;
        if(idtrangthaidh == null){
            list = invoiceRepository.findByStall(stall.getId(), start, end);
        }
        if (idtrangthaidh != null){
            list = invoiceRepository.findByStallAndTrangThai(stall.getId(), start, end, idtrangthaidh);
        }
        return list;
    }

    @GetMapping("/saler/capNhatDonHang")
    public void capNhatDonHang(@RequestParam(value = "iddonhang") Long iddonhang,
                               @RequestParam(value = "idtrangthaidh") Long idtrangthaidh){
        Invoice invoice = invoiceRepository.findById(iddonhang).get();
        StatusInvoice statusInvoice = statusInvoiceRepository.findById(idtrangthaidh).get();
        invoice.setStatusInvoice(statusInvoice);
        invoice.setUpdateAt(new Date(System.currentTimeMillis()));
        invoice.setUpdateTime(new Time(System.currentTimeMillis()));
        invoiceRepository.save(invoice);
    }

    @PostMapping("/user/huyDonHang")
    public Integer huyDonHang(@RequestParam(value = "iddonhang") Long iddonhang){
        Invoice invoice = invoiceRepository.findById(iddonhang).get();
        if(invoice.getStatusInvoice().getId() > 1){
            return 1;
        }
        StatusInvoice statusInvoice = statusInvoiceRepository.findById(4L).get();
        invoice.setStatusInvoice(statusInvoice);
        invoice.setUpdateAt(new Date(System.currentTimeMillis()));
        invoice.setUpdateTime(new Time(System.currentTimeMillis()));
        invoiceRepository.save(invoice);
        List<InvoiceDetail> list = invoice.getInvoiceDetails();
        for(InvoiceDetail i : list){
            Product p= i.getProduct();
            p.setQuantity(p.getQuantity() + i.getQuantity());
            p.setDoanhSo(p.getDoanhSo() - i.getQuantity());
            productRepository.save(p);
        }
        return 0;
    }

    @GetMapping("/saler/chitietDh")
    public Invoice findById(@RequestParam("id") Long id){
        return invoiceRepository.findById(id).get();
    }

    @GetMapping("/shipper/chitietDh")
    public Invoice findByIdSp(@RequestParam("id") Long id){
        return invoiceRepository.findById(id).get();
    }

    @PostMapping("/saler/update-invoice-shipper")
    public void updateShipper(@RequestParam Long id, @RequestParam Long shipperId){
        Invoice invoice = invoiceRepository.findById(id).get();
        Shipper shipper = shipperRepository.findById(shipperId).get();
        invoice.setShipper(shipper);
        invoice.setShipperConfirm(false);
        invoiceRepository.save(invoice);
        mailService.sendEmail(shipper.getUser().getUsername(),"Bạn có một đơn giao mới",
                "Đơn giao mới của bạn mã là "+invoice.getId(),
                false, true);
    }

    @GetMapping("/shipper/donHangCuaShip")
    public List<Invoice> donHangCuaShip(@RequestParam(value = "start", required = false) Date start,
                                        @RequestParam(value = "end", required = false) Date end,
                                        @RequestParam(value = "idtrangthaidh", required = false) Long idtrangthaidh){
        User user = userService.getUserWithAuthority();
        Shipper shipper = shipperRepository.findByUser(user.getId());
        if(start == null || end == null){
            start = Date.valueOf("2000-01-01");
            end = Date.valueOf("2100-01-01");
        }
        List<Invoice> list = null;
        if(idtrangthaidh == null){
            list = invoiceRepository.findByShip(shipper.getId(), start, end);
        }
        if (idtrangthaidh != null){
            list = invoiceRepository.findByShipAndTrangThai(shipper.getId(), start, end, idtrangthaidh);
        }
        return list;
    }


    @GetMapping("/shipper/capNhatDonHang")
    public void capNhatDonHangByShip(@RequestParam(value = "iddonhang") Long iddonhang,
                               @RequestParam(value = "idtrangthaidh") Long idtrangthaidh){
        Invoice invoice = invoiceRepository.findById(iddonhang).get();
        StatusInvoice statusInvoice = statusInvoiceRepository.findById(idtrangthaidh).get();
        invoice.setStatusInvoice(statusInvoice);
        invoice.setUpdateAt(new Date(System.currentTimeMillis()));
        invoice.setUpdateTime(new Time(System.currentTimeMillis()));
        invoiceRepository.save(invoice);
    }


    @PostMapping("/shipper/confirm-ship")
    public void confirm(@RequestParam Long id){
        Invoice invoice = invoiceRepository.findById(id).get();
        if(invoice.getShipperConfirm() == null){
            invoice.setShipperConfirm(true);
        }
        else{
            if(invoice.getShipperConfirm() == false){
                invoice.setShipperConfirm(true);
            }
            else{
                invoice.setShipperConfirm(false);
            }
        }
        invoiceRepository.save(invoice);
        String tt = " đã được chấp nhận";
        if(invoice.getShipperConfirm() == false){
            tt = " đã bị từ chối giao";
        }
        mailService.sendEmail(invoice.getStall().getEmail(),"Cập nhật xác nhận đơn giao",
                "Đơn giao #"+invoice.getId() +tt+" bởi shipper",
                false, true);
    }

}
