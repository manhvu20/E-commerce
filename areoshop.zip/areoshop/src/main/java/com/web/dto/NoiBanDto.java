package com.web.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigInteger;

@Getter
@Setter
public class NoiBanDto {

    private BigInteger id;

    private String name;

    private BigInteger soLuongSp;
}
