var listcart = localStorage.getItem("cartareo");
var token = localStorage.getItem("token");

async function themGioHang(){
    await checkroleUser();
    var id = window.location.search.split('=')[1];
    var url = 'http://localhost:8080/api/user/addCart?id='+id;
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if(response.status < 300){
        swal({title: "Thông báo", text: "thêm giỏ hàng thành công!", type: "success"},
            function(){
                window.location.reload()
            });
    }
}

var listcarts = null;

async function gioHangCuaToi(){
    var search = document.getElementById("searchcart").value
    var url = 'http://localhost:8080/api/user/gioHangCuaToi?search='+search;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var list = await response.json();
    console.log(list)
    listcarts = list;
    var main = ``;
    var tongTien = 0;
    for(i=0; i<list.length; i++){
        var dms = list[i].product.productCategories
        var dm = ''
        for(j=0; j<dms.length; j++){
            dm += `<a href="product?category=${dms[j].category.id}">${dms[j].category.name}</a>, `
        }
        // tongTien  = Number(tongTien) + Number(list[i].product.price * list[i].quantity);
        var giatien = `<p class="pricecsd">${formatmoney(list[i].product.price)}</p>`
        if(list[i].product.giamGia != null){
            giatien = `<p class="pricecsd">${formatmoney(list[i].product.price - list[i].product.price * list[i].product.giamGia/100)}</p>`+
                `<p class="pricecsd gachgiacu">${formatmoney(list[i].product.price)}</p>
                        <p style="color:#000" class="pricecsd">(- ${list[i].product.giamGia})%</p>`
            tongTien = Number(tongTien) + Number(list[i].product.price * list[i].quantity - list[i].product.price * list[i].quantity * list[i].product.giamGia/100);

        }
        else{
            tongTien = Number(tongTien) + Number(list[i].product.price * list[i].quantity);
        }
        main += `<div class="row singordercsd">
                    <div class="col-1">
                        <label class="checkbox-custom">
                            <input id="chongh${list[i].id}" onclick="themDaChon(${list[i].id})" value="${list[i].id}" type="checkbox" class="chongiohang">
                            <span class="checkmark-checkbox chonhetcustom"></span>
                        </label>
                    </div>
                    <div class="col-2">
                        <img src="${list[i].product.banner}" class="imgcsd">
                    </div>
                    <div class="col-4">
                        <p class="tenspcsd"><a href="detail?id=${list[i].product.id}">${list[i].product.name}</a></p>
                        <p class="danhmuccsd">Danh mục: ${dm}</p>
                        <p class="danhmuccsd">Shop: <span>${list[i].product.stall.name}</span></p>
                    </div>
                    <div class="col-2">
                        <div class="range-price">
                            <button onclick="capNhatSoLuong(${list[i].id}, -1)">-</button><input value="${list[i].quantity}" type="number"><button onclick="capNhatSoLuong(${list[i].id}, 1)">+</button>
                        </div>
                    </div>
                    <div class="col-2">
                       ${giatien}
                    </div>
                    <div class="col-1">
                        <i onclick="xoaGioHang(${list[i].id})" class="fa fa-times iconxoasp"></i>
                    </div>
                </div>`
    }
    document.getElementById("gioHangCuaToi").innerHTML = main;
    document.getElementById("tongtiengiohang").innerHTML = formatmoney(tongTien);
}

async function capNhatSoLuong(id, sl){
    var url = 'http://localhost:8080/api/user/capNhatSoLuong?id='+id+'&soLuong='+sl;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    gioHangCuaToi();
}

async function xoaGioHang(id){
    var url = 'http://localhost:8080/api/user/xoaGioHang?id='+id;
    const response = await fetch(url, {
        method: 'DELETE',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    gioHangCuaToi();
}

var listdachon = [];

function themDaChon(id){
    for(i=0; i<listdachon.length; i++){
        if(listdachon[i] == id){
            listdachon.splice(i,1);
            if(listdachon.length == 0){
                document.getElementById("btndathang").style.display = 'none';
            }
            console.log(listdachon)
            setTongTien();
            return;
        }
    }
    listdachon.push(id);
    console.log(listdachon)
    setTongTien();
    document.getElementById("btndathang").style.display = '';
}

function setTongTien(){
    var tongTien = 0;
    var tongSp = 0;
    for(i=0; i<listdachon.length; i++){
        for(j=0; j<listcarts.length; j++){
            if(listdachon[i] == listcarts[j].id){
                tongTien = Number(tongTien) + Number(listcarts[j].product.price * listcarts[j].quantity);
                tongSp = Number(tongSp) + Number(listcarts[j].quantity);
            }
        }
    }
    document.getElementById("pricepre").innerHTML = formatmoney(tongTien);
    document.getElementById("tongsp").innerHTML = tongSp;
}

function chonTatCa(){
    listdachon = [];
    var idsd = document.getElementById("chontatcainput")
    if(idsd.checked == false){
        for(i=0; i<listcarts.length; i++){
            document.getElementById("chongh"+listcarts[i].id).checked = false;
        }
        document.getElementById("btndathang").style.display = 'none';
        document.getElementById("pricepre").innerHTML = formatmoney(0);
        document.getElementById("tongsp").innerHTML = 0;
        return;
    }
    var tongTien = 0;
    var tongSp = 0;
    for(i=0; i<listcarts.length; i++){
        if(listcarts[i].product.giamGia != null){
            tongTien = Number(tongTien) + Number(listcarts[i].product.price * listcarts[i].quantity - listcarts[i].product.price * listcarts[i].quantity * listcarts[i].product.giamGia/100);

        }
        else{
            tongTien = Number(tongTien) + Number(listcarts[i].product.price * listcarts[i].quantity);
        }
        tongSp = Number( tongSp) + Number(listcarts[i].quantity);
        listdachon.push(listcarts[i].id);
        document.getElementById("chongh"+listcarts[i].id).checked = true;
    }
    document.getElementById("pricepre").innerHTML = formatmoney(tongTien);
    document.getElementById("tongsp").innerHTML = tongSp;
    document.getElementById("btndathang").style.display = '';
}

var listspdachon = [];
function chuyenTrangXacNhan(){
    for(i=0; i<listdachon.length; i++){
        for(j=0; j<listcarts.length; j++){
            if(listdachon[i] == listcarts[j].id){
                listspdachon.push(listcarts[j])
            }
        }
    }
    window.localStorage.setItem('cartdachon', JSON.stringify(listspdachon));
    window.location.href= "confirm"
}