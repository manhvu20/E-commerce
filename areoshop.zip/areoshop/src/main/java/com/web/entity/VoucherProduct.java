package com.web.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "voucher_product")
@Getter
@Setter
public class VoucherProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    private String code;

    private String name;

    private Float discount;

    private Date startDate;

    private Date endDate;

    private Integer maxNumber;

    private Integer numUsed;

    @ManyToOne
    @JoinColumn(name = "stall_id")
    private Stall stall;

    @OneToMany(mappedBy = "voucherProduct", cascade = CascadeType.REMOVE)
//    @JsonManagedReference
    @JsonIgnore
    private List<ProductVoucherProduct> productVoucherProducts = new ArrayList<>();
}
