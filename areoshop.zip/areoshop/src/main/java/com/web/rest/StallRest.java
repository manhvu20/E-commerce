package com.web.rest;

import com.web.entity.Stall;
import com.web.entity.User;
import com.web.repository.StallRepository;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class StallRest {

    @Autowired
    private StallRepository stallRepository;

    @Autowired
    private UserService userService;

    @GetMapping("/saler/mystall")
    public Stall findByUser(){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        return stall;
    }

    @PostMapping("/saler/updateMyStall")
    public void updateStall(@RequestBody Stall stall){
        User user = userService.getUserWithAuthority();
        Stall result = stallRepository.findByUser(user.getId());
        result.setName(stall.getName());
        result.setPhone(stall.getPhone());
        result.setEmail(stall.getEmail());
        result.setImageBanner(stall.getImageBanner());
        stallRepository.save(result);
    }

    @PostMapping("/saler/updateAddressStall")
    public void updateAddressStall(@RequestBody Stall stall){
        User user = userService.getUserWithAuthority();
        Stall result = stallRepository.findByUser(user.getId());
        result.setFullname(stall.getFullname());
        result.setSdtLienHe(stall.getSdtLienHe());
        result.setWards(stall.getWards());
        result.setStressA(stall.getStressA());
        stallRepository.save(result);
    }

    @GetMapping("/admin/tatCaShop")
    public List<Stall> tatCaShop(){
        return stallRepository.findAll();
    }

    @GetMapping("/public/shopById")
    public Stall findById(@RequestParam("id") Long id){
        return stallRepository.findById(id).get();
    }
}
