async function loadAllCategory() {
    var url = 'http://localhost:8080/api/public/allcategory';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var list = await response.json();
    var main = '';
    for (i = 0; i < list.length; i++) {
        main += `<div class="singledm">
                    <a style="text-decoration: none;" href="product?category=${list[i].id}"><div class="divdsm"><img src="${list[i].linkImage}"></div>
                    <p style="text-align:center;">${list[i].name}</p></a>
                </div>`
    }
    document.getElementById("listdmindex").innerHTML = main
}


async function loadDanhMucTimKiem() {
    var url = 'http://localhost:8080/api/public/allcategorySoLuong';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var list = await response.json();
    console.log(list)
    var main = '';
    for (i = 0; i < list.length; i++) {
        main += ` <label class="checkbox-custom">${list[i].name} (${list[i].soLuongSp})
                    <input value="${list[i].id}" type="checkbox" class="danhmuctk">
                    <span class="checkmark-checkbox"></span>
                </label>`
    }
    document.getElementById("listdmfilter").innerHTML = main
}

var listNoiBan = [];
async function loadDiaChiTimKiem() {
    var url = 'http://localhost:8080/api/public/tatCaNoiBan';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var list = await response.json();
    listNoiBan = list;
    console.log(list)
    var main = '';
    for (i = 0; i < list.length; i++) {
        if(i<6){
            main += ` <label class="checkbox-custom">${list[i].name} (${list[i].soLuongSp})
                        <input value="${list[i].id}" type="checkbox" class="noiban">
                        <span class="checkmark-checkbox"></span>
                    </label>` 
        }
    }
    document.getElementById("listDiaChifilter").innerHTML = main
}

function moRongNoiBan(){
    var list = listNoiBan;
    var main = '';
    for (i = 0; i < list.length; i++) {
        main += ` <label class="checkbox-custom">${list[i].name} (${list[i].soLuongSp})
                    <input value="${list[i].id}" type="checkbox" class="noiban">
                    <span class="checkmark-checkbox"></span>
                </label>` 
    }
    document.getElementById("listDiaChifilter").innerHTML = main
    document.getElementById("morongnoiban").innerHTML = `<i onclick="thuHepNoiBan()" class="fa fa-minus poiter" style="margin-left: 15px;"></i>`
}

function thuHepNoiBan(){
    var list = listNoiBan;
    var main = '';
    for (i = 0; i < list.length; i++) {
        if(i<6){
            main += ` <label class="checkbox-custom">${list[i].name} (${list[i].soLuongSp})
                        <input value="${list[i].id}" type="checkbox" class="noiban">
                        <span class="checkmark-checkbox"></span>
                    </label>` 
        }
    }
    document.getElementById("listDiaChifilter").innerHTML = main
    document.getElementById("morongnoiban").innerHTML = `<i onclick="moRongNoiBan()" class="fa fa-plus poiter" style="margin-left: 15px;"></i>`
}