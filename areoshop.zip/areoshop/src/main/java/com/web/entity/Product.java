package com.web.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "product")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    private String name;

    private Double price;

    private Date createdDate;

    private Time createTime;

    private String banner;

    private Integer quantity;

    private String description;

    private Float discount;

    private Integer deleted;

    private String feedBackByAdmin;

    private Integer doanhSo;

    private Float weight;

    @Transient
    private Float giamGia;

    @ManyToOne
    @JoinColumn(name = "status_product")
    private StatusProduct statusProduct;

    @ManyToOne
    @JoinColumn(name = "stall_id")
    private Stall stall;

    @OneToMany(mappedBy = "product", cascade = CascadeType.REMOVE)
    @JsonManagedReference
    private List<ImageProduct> imageProducts = new ArrayList<>();

    @OneToMany(mappedBy = "product", cascade = CascadeType.REMOVE)
    @JsonManagedReference
    private List<ProductCategory> productCategories = new ArrayList<>();

    @Transient
    private List<Long> listIdDm = new ArrayList<>();

    @Transient
    private List<String> listLinkImage = new ArrayList<>();

    public Product(Long id) {
        this.id = id;
    }
}
