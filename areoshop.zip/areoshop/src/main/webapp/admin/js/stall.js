var token = localStorage.getItem("token");

async function loadTatCaShop() {
    $('#example').DataTable().destroy();
    var url = 'http://localhost:8080/api/admin/tatCaShop';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
        })
    });
    var list = await response.json();
    var main = '';
    for (i = 0; i < list.length; i++) {
        var locks = ``;
        if(list[i].user.actived == 0){
            locks = `<a onclick="lockOrUnlock(${list[i].user.id},0)" class="btn btn-danger"><i class="fa fa-unlock"></i> mở khóa</a>`
        }
        else{
            locks = `<a onclick="lockOrUnlock(${list[i].user.id},1)" class="btn btn-primary"><i class="fa fa-lock"></i> khóa</a>`
        }
        main += `<tr>
                    <td>${list[i].id}</td>
                    <td><img src="${list[i].imageBanner}" style="width: 100px;"></td>
                    <td>${list[i].name}</td>
                    <td>${list[i].phone}<br>${list[i].sdtLienHe}</td>
                    <td>${list[i].email}</td>
                    <td>${list[i].stressA}</td>
                    <td>${list[i].user.username}</td>
                    <td>${locks}</td>
                </tr>`
    }
    document.getElementById("listshop").innerHTML = main
    $('#example').DataTable();
}

async function lockOrUnlock(id, type) {
    var str = 'Bạn chắc chắn muốn khóa shop này ?';
    if(type == 0){
        str = 'Bạn chắc chắn muốn mở khóa shop này ?';
    }
    var con = confirm(str);
    if(con){
        var url = 'http://localhost:8080/api/admin/activeUser?id=' + id;
        const response = await fetch(url, {
            method: 'POST',
            headers: new Headers({
                'Authorization': 'Bearer ' + token
            })
        });
        if (response.status < 300) {
            var mess = '';
            if(type == 1){
                mess = 'Khóa thành công'
            }
            else{
                mess = 'Mở khóa thành công'
            }
            swal({
                title: "Thông báo", 
                text: mess, 
                type: "success"
              },
            function(){ 
                window.location.reload();
            });
        }
        else {
            swal({
                title: "Thông báo", 
                text: "hành động thất bại", 
                type: "error"
              },
            function(){ 
                window.location.reload();
            });
        }
    }
}