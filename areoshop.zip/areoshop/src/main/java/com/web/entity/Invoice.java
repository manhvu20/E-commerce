package com.web.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "invoice")
@Getter
@Setter
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    private Date createdDate;

    private Date updateAt;

    private Time updateTime;

    private Double totalAmount;

    private String fullname;

    private String phone;

    private String address;

    private Double shipCost;

    private Boolean shipperConfirm = false;

    @ManyToOne
    private Shipper shipper;

    @ManyToOne
    @JoinColumn(name = "status_invoice_id")
    private StatusInvoice statusInvoice;

    @ManyToOne
    @JoinColumn(name = "stall_id")
    private Stall stall;

    @ManyToOne
    @JoinColumn(name = "address_user_id")
    private AddressUser addressUser;

    @ManyToOne
    @JoinColumn(name = "voucherCustomer_id")
    private VoucherCustomer voucherCustomer;

    @OneToMany(mappedBy = "invoice", cascade = CascadeType.REMOVE)
    @JsonManagedReference
    private List<InvoiceDetail> invoiceDetails = new ArrayList<>();
}
