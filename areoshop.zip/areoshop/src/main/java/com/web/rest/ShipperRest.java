package com.web.rest;

import com.web.entity.Shipper;
import com.web.entity.User;
import com.web.entity.Wards;
import com.web.repository.ShipperRepository;
import com.web.repository.WardsRepository;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class ShipperRest {

    @Autowired
    private UserService userService;

    @Autowired
    private ShipperRepository shipperRepository;

    @Autowired
    private WardsRepository wardsRepository;

    @GetMapping("/shipper/myaccount")
    public ResponseEntity<?> findByUser(){
        User user = userService.getUserWithAuthority();
        Shipper shipper = shipperRepository.findByUser(user.getId());
        return new ResponseEntity<>(shipper, HttpStatus.OK);
    }

    @PostMapping("/shipper/update-address")
    public void updateAddress(@RequestParam Long wardId, @RequestParam(required = false) String detail){
        Wards wards = wardsRepository.findById(wardId).get();
        User user = userService.getUserWithAuthority();
        Shipper shipper = shipperRepository.findByUser(user.getId());
        shipper.setWards(wards);
        shipper.setAddressDetail(detail);
        shipperRepository.save(shipper);
    }

    @GetMapping("/all/get-all-shipper")
    public ResponseEntity<?> getShipper(@RequestParam(required = false) Long wardId){
        List<Shipper> shipper = null;
        if(wardId == null){
            shipper = shipperRepository.findAll();
        }
        else{
            shipper = shipperRepository.findByWard(wardId);
        }
        return new ResponseEntity<>(shipper, HttpStatus.OK);
    }
}
