package com.web.rest;
import com.web.entity.Chatting;
import com.web.entity.Stall;
import com.web.entity.User;
import com.web.repository.ChatRepository;
import com.web.repository.StallRepository;
import com.web.repository.UserRepository;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.*;

@RestController
@RequestMapping("/api/chat")
@CrossOrigin
public class ChatRest {

    @Autowired
    private ChatRepository chatRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StallRepository stallRepository;

    @Autowired
    private UserService userUtils;

    @GetMapping("/user/my-chat")
    public ResponseEntity<?> myChat(){
        List<Chatting> result = chatRepository.myChat(userUtils.getUserWithAuthority().getId());
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @GetMapping("/saler/my-chat")
    public ResponseEntity<?> myChatByStall(){
        List<Chatting> result = chatRepository.myChat(userUtils.getUserWithAuthority().getId());
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @GetMapping("/user/getAllUserChat")
    public ResponseEntity<?> getAllUserChat(@RequestParam(value = "search", required = false) String search){
        if(search == null){
            search = "";
        }
        search = "%"+search +"%";
        Set<User> list = userRepository.getAllUserChat(userUtils.getUserWithAuthority().getId(), search);
        List<Stall> stalls = new ArrayList<>();
        for(User u : list){
            stalls.add(stallRepository.findByUser(u.getId()));
        }
        return new ResponseEntity<>(stalls, HttpStatus.OK);
    }

    @GetMapping("/saler/getAllUserChat")
    public ResponseEntity<?> getAllUserChatByStaff(@RequestParam(value = "search", required = false) String search){
        if(search == null){
            search = "";
        }
        search = "%"+search +"%";
        User user = userUtils.getUserWithAuthority();
        System.out.println("user id chat: "+user.getId());
        Set<User> list = userRepository.getAllUserChatByStaff(user.getId(), search);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @GetMapping("/user/getListChat")
    public List<Chatting> getListChat(@RequestParam("idreciver") Long idreciver){
        return chatRepository.findByUser(userUtils.getUserWithAuthority().getId(), idreciver);
    }

    @GetMapping("/saler/getListChat")
    public List<Chatting> getListChatByStall(@RequestParam("idreciver") Long idreciver){
        return chatRepository.findByUser(userUtils.getUserWithAuthority().getId(), idreciver);
    }


}
