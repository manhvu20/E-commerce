package com.web.rest;

import com.web.dto.VoucherProductDto;
import com.web.entity.*;
import com.web.repository.ProductVoucherProductRepository;
import com.web.repository.StallRepository;
import com.web.repository.VoucherProductRepository;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class VoucherProductRest {

    @Autowired
    private VoucherProductRepository voucherProductRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private StallRepository stallRepository;

    @Autowired
    private ProductVoucherProductRepository productVoucherProductRepository;

    @PostMapping("/saler/addVoucherProduct")
    public void save(@RequestBody VoucherProductDto voucherProductDto){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        VoucherProduct voucherProduct = voucherProductDto.getVoucherProduct();
        voucherProduct.setStall(stall);
        if(voucherProduct.getId() == null){
            voucherProduct.setNumUsed(0);
        }
        else{
            VoucherProduct v = voucherProductRepository.findById(voucherProduct.getId()).get();
            voucherProduct.setNumUsed(v.getNumUsed());
        }
        VoucherProduct result = voucherProductRepository.save(voucherProduct);
        List<ProductVoucherProduct> list = new ArrayList<>();
        for(Long id: voucherProductDto.getProductIds()){
            Product product = new Product();
            product.setId(id);
            ProductVoucherProduct pvp = new ProductVoucherProduct();
            pvp.setProduct(product);
            pvp.setVoucherProduct(result);
            list.add(pvp);
        }
        productVoucherProductRepository.deleteByVoucherProductId(result.getId());
        productVoucherProductRepository.saveAll(list);
    }

    @GetMapping("/public/voucherProductByID")
    public VoucherProduct findById(@RequestParam("id") Long id){
        VoucherProduct v = voucherProductRepository.findById(id).get();
        return v;
    }

    @GetMapping("/saler/myVoucherProduct")
    public List<VoucherProduct> findByStall(){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        List<VoucherProduct> list = voucherProductRepository.findByStall(stall.getId());
        return list;
    }

    @GetMapping("/saler/myVoucherProductAndType")
    public List<VoucherProduct> findByStallAndType(@RequestParam("type") Integer type){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        List<VoucherProduct> list = null;
        if(type == 1){
            list = voucherProductRepository.findByStallDangDienRa(stall.getId(), new Date(System.currentTimeMillis()));
        }
        else if(type == 2){
            list = voucherProductRepository.findByStallSapDienRa(stall.getId(), new Date(System.currentTimeMillis()));
        }
        else if(type == 3){
            list = voucherProductRepository.findByStallDaKetThuc(stall.getId(), new Date(System.currentTimeMillis()));
        }
        else if(type == 0){
            list = voucherProductRepository.findByStall(stall.getId());
        }
        return list;
    }

    @DeleteMapping("/saler/deleteVoucherProduct")
    public void delete(@RequestParam("id") Long id){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        VoucherProduct v = voucherProductRepository.findById(id).get();
        if(v.getStall().getId() != stall.getId()){
            return;
        }
        voucherProductRepository.deleteById(id);
    }
}
