package com.web.repository;

import com.web.entity.StatusInvoice;
import com.web.entity.StatusProduct;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatusInvoiceRepository extends JpaRepository<StatusInvoice, Long> {
}
