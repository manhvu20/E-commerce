var token = localStorage.getItem("token");

async function loadMyStall() {
    var url = 'http://localhost:8080/api/saler/mystall';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var stall = await response.json();
    console.log(stall)
    document.getElementById("tenshop").value = stall.name
    document.getElementById("sdtstall").value = stall.phone
    document.getElementById("emailstall").value = stall.email
    document.getElementById("imgshop").src = stall.imageBanner
    imagebanner = stall.imageBanner

    if(stall.wards == null){
        document.getElementById("overindc").innerHTML = stall.name
        document.getElementById("diachishoop").innerHTML = 'hãy thêm địa chỉ của bạn'
    }
    else{
        document.getElementById("diachishoop").innerHTML = stall.stressA+", "+ stall.wards.name+", "+stall.wards.districts.name+", "+stall.wards.districts.province.name;
    }
    if(stall.sdtLienHe == null || stall.sdtLienHe == ""){
        document.getElementById("sdtlhshop").innerHTML = stall.phone
    }
    else{
        document.getElementById("sdtlhshop").innerHTML = stall.sdtLienHe
    }
}


async function checkMyShop() {
    var url = 'http://localhost:8080/api/saler/mystall';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var stall = await response.json();
    if(stall.name == null || stall.name == "" ||
    stall.phone == null || stall.phone == "" ||
    stall.email == null || stall.email == ""){
        swal({
            title: "Thông báo", 
            text: "hãy cập nhật thông tin shop của bạn!", 
            type: "success"
          },
        function(){ 
            window.location.replace('account')
            return;
        });
    }
    else if(stall.wards == null){
        swal({
            title: "Thông báo", 
            text: "hãy cập nhật địa chỉ shop của bạn!", 
            type: "success"
          },
        function(){ 
            window.location.replace('account')
            return;
        });
    }
}

var imagebanner = ''
async function updateStall() {
    const filePath = document.getElementById('chonfile')
    const formData = new FormData()
    formData.append("file", filePath.files[0])
    var urlUpload = 'http://localhost:8080/api/public/upload';
    const resp = await fetch(urlUpload, { 
             method: 'POST', 
              headers: new Headers({
             }),
             body: formData
           });
    var imagebanner = await resp.text();
    if(resp.status > 300){
        imagebanner = "";
    }

    var tenshop= document.getElementById("tenshop").value
    var sdtstall= document.getElementById("sdtstall").value
    var emailstall= document.getElementById("emailstall").value
    var stall = {
        "name":tenshop,
        "phone":sdtstall,
        "email":emailstall,
        "imageBanner":imagebanner
    }
    var url = 'http://localhost:8080/api/saler/updateMyStall';
    const res = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(stall)
    });
    if(res.status < 300){
        swal({
            title: "Thông báo", 
            text: "Cập nhật thÔng tin shop thành công!", 
            type: "success"
        },
        function(){ 
            window.location.reload()
        });
    }
    if(res.status > 300){
        swal({
            title: "Thông báo", 
            text: "thất bại!", 
            type: "error"
            },
        function(){ 
        });
    } 
}

async function updateAddressStall() {
    var fullname = document.getElementById("fullname").value
    var sdtLienHe = document.getElementById("sdtLienHe").value 
    var stressA = document.getElementById("stressA").value
    var xa = document.getElementById("xa").value;
    var stall = {
        "fullname":fullname,
        "sdtLienHe":sdtLienHe,
        "stressA":stressA,
        "wards":{
            "id":xa
        }
    }
    var url = 'http://localhost:8080/api/saler/updateAddressStall';
    const res = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(stall)
    });
    if(res.status < 300){
        swal({
            title: "Thông báo", 
            text: "Cập nhật thÔng tin địa chỉ thành công!", 
            type: "success"
        },
        function(){ 
            window.location.reload()
        });
    }
    if(res.status > 300){
        swal({
            title: "Thông báo", 
            text: "thất bại!", 
            type: "error"
            },
        function(){ 
        });
    } 
}


async function loadMyStallClick() {
    var url = 'http://localhost:8080/api/saler/mystall';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var stall = await response.json();
    console.log(stall)
    document.getElementById("fullname").value = stall.fullname
    document.getElementById("sdtLienHe").value = stall.sdtLienHe
    document.getElementById("stressA").value = stall.stressA
    if(stall.wards != null){
        document.getElementById("tinh").value = stall.wards.districts.province.id
        var id =  document.getElementById("tinh").value

        var urladd = 'http://localhost:8080/api/public/districts?id='+id;
        const response = await fetch(urladd, {
        method: 'GET',
        headers: new Headers({
        })
        });
        var list = await response.json();
        var main = ''
        for(i=0; i<list.length; i++){
            main += `<option value="${list[i].id}">${list[i].name}</option>`
        }
        document.getElementById("huyen").innerHTML = main
        document.getElementById("huyen").value = stall.wards.districts.id

        var urladd = 'http://localhost:8080/api/public/wards?id='+stall.wards.districts.id;
        const res = await fetch(urladd, {
            method: 'GET',
            headers: new Headers({
            })
        });
        var list = await res.json();
        var main = ''
        for(i=0; i<list.length; i++){
            main += `<option value="${list[i].id}">${list[i].name}</option>`
        }
        document.getElementById("xa").innerHTML = main
        document.getElementById("xa").value = stall.wards.id
    }

}

async function changePassword() {
    var token = localStorage.getItem("token");
    var oldpass = document.getElementById("oldpass").value
    var newpass = document.getElementById("newpass").value
    var renewpass = document.getElementById("renewpass").value
    var url = 'http://localhost:8080/api/all/changePassword?old='+oldpass+"&new="+newpass;
    if(oldpass == "" || newpass== "" || renewpass ==""){
        alert("dữ liệu không được để trống");
        return;
    }
    if(newpass != renewpass){
        alert("mật khẩu mới không trùng khớp");
        return;
    }
    
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({
            title: "Thông báo", 
            text: "cập nhật mật khẩu thành công, hãy đăng nhập lại", 
            type: "success"
          },
        function(){ 
            window.location.reload()
        });
    }
    else {
        swal({
            title: "Thông báo", 
            text: "cập nhật mật khẩun thất bại, mật khẩu không chính xác", 
            type: "error"
          },
        function(){ });
    }
}

function moChonFile(){
    document.getElementById('chonfile').click();
}

async function uploadAnh() {
    const filePath = document.getElementById('imagebanner')
    const formData = new FormData()
    formData.append("file", filePath.files[0])
    var urlUpload = 'http://localhost:8080/api/public/upload';
    const res = await fetch(urlUpload, { 
             method: 'POST', 
              headers: new Headers({
             }),
             body: formData
           });
    var linkbanner = await res.text();
    if(res.status > 300){
        linkbanner = null;
    }
}