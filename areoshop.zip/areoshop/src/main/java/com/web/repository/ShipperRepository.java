package com.web.repository;

import com.web.entity.Shipper;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ShipperRepository extends JpaRepository<Shipper, Long> {

    @Query("select s from Shipper s where s.user.id = ?1")
    Shipper findByUser(Long userId);

    @Query("select s from Shipper s where s.wards.id = ?1")
    List<Shipper> findByWard(Long wardId);
}
