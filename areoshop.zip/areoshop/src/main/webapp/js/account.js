function moTaiKhoan(){
    document.getElementById("thongtintk").style.display = ""
    document.getElementById("thongtindonhang").style.display = "none"
    document.getElementById("thongtinTheodoi").style.display = "none"

    document.getElementById("litk").classList.add("active")
    document.getElementById("lidonhang").classList.remove("active")
    document.getElementById("litheodoi").classList.remove("active")
}
function moDonHang(){
    document.getElementById("thongtintk").style.display = "none"
    document.getElementById("thongtindonhang").style.display = ""
    document.getElementById("thongtinTheodoi").style.display = "none"

    document.getElementById("lidonhang").classList.add("active")
    document.getElementById("litk").classList.remove("active")
    document.getElementById("litheodoi").classList.remove("active")
}
function moTheoDoi(){
    document.getElementById("thongtintk").style.display = "none"
    document.getElementById("thongtindonhang").style.display = "none"
    document.getElementById("thongtinTheodoi").style.display = ""

    document.getElementById("litheodoi").classList.add("active")
    document.getElementById("lidonhang").classList.remove("active")
    document.getElementById("litk").classList.remove("active")
}

async function checkEmailExis() {
    var usernameregis = document.getElementById("usernameregis").value
    var url = 'http://localhost:8080/api/public/checkUserExist?email='+usernameregis;
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
        })
    });
    var check = await response.text();
    console.log(check)
    if(check == 'true'){
        document.getElementById("checkemail").style.display = 'block'
        document.getElementById("btndangky").disabled = true
    }
    else{
        document.getElementById("checkemail").style.display = 'none';
        document.getElementById("btndangky").disabled = false
    }
}

async function regis() {
    var url = 'http://localhost:8080/api/register'
    var usernameregis = document.getElementById("usernameregis").value
    var password = document.getElementById("passwordregis").value
    var repassword = document.getElementById("repasswordregis").value
    var roles = document.getElementById("roles").value
    var user = {
        "username": usernameregis,
        "password": password,
        "authorities": [
            roles
        ]
    }
    if(password != repassword){
        alert("Mật khẩu không trùng khớp")
        return;
    }
    if(password === "" || repassword === ""){
        alert("mật khẩu không được để trống!")
        return;
    }
    const res = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(user)
    });
    var result = await res.text();
    console.log(result)
    if (result === '2') {
        alert("email đã tồn tại")
    }
    else if (result === '0') {
        swal({
            title: "Thông báo", 
            text: "đăng ký thành công! hãy check email của bạn!", 
            type: "success"
          },
        function(){ 
            window.location.reload();
        });
    }
}

async function login() {
    var url = 'http://localhost:8080/api/authenticate'
    var username = document.getElementById("username").value
    var password = document.getElementById("password").value
    var user = {
        "username": username,
        "password": password
    }
    console.log(user)
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(user)
    });
    var token = await response.text(); 

    
    if(response.status > 300){
        toastr.warning("tài khoản hoặc mật khẩu không chính xác");
    }
    if(response.status < 300){

        window.localStorage.setItem('token', token);
       
        var urlAccount = 'http://localhost:8080/api/userlogged';
        const res = await fetch(urlAccount, {
            method: 'POST',
            headers: new Headers({
                'Authorization': 'Bearer '+token, 
                'Content-Type': 'application/json'
            })
        });

        var account = await res.json();
        window.localStorage.setItem('username', account.username);
        window.localStorage.setItem('user', JSON.stringify(account));
        console.log(account)
        var check = 0;
        for(i=0; i<account.authorities.length; i++){
            if(account.authorities[i].name === 'ROLE_ADMIN'){
                check = 1;
                localStorage.setItem("roleweb","ROLE_ADMIN")
            }
            if(account.authorities[i].name === 'ROLE_SALER'){
                check = 2;
                localStorage.setItem("roleweb","ROLE_SALER")
            }
            if(account.authorities[i].name === 'ROLE_USER'){
                check = 0;
                localStorage.setItem("roleweb","ROLE_USER")
            }
            if(account.authorities[i].name === 'ROLE_SHIPPER'){
                check = 3;
                localStorage.setItem("roleweb","ROLE_SHIPPER")
            }
        }
        if(check === 0){
            window.location.replace('index')
        }
        if(check === 1){
            window.location.replace('admin/index')
        }
        if(check === 2){
            window.location.replace('saler/account')
        }
        if(check === 3){
            window.location.replace('shipper/account')
        }
    }
}

var token = localStorage.getItem("token");

async function loadUser() {
    if(token == null){
        alert("bạn chưa đăng nhập")
        window.location.replace("login")
    }
    var url = 'http://localhost:8080/api/userlogged';
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var user = await response.json();
    console.log(user)
    document.getElementById("fullname").value = user.fullname
    document.getElementById("phone").value = user.phone
}

async function changeUser() {
    var token = localStorage.getItem("token");
    var url = 'http://localhost:8080/api/user/updateinfor';
    var fullname = document.getElementById("fullname").value
    var phone = document.getElementById("phone").value
    if(fullname == "" || phone== ""){
        alert("dữ liệu không được để trống");
        return;
    }
    var userDto = {
        "fullname":fullname,
        "phone":phone
    }
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(userDto)
    });
    if (response.status < 300) {
        swal({
            title: "Thông báo", 
            text: "cập nhật thông tin tài khoản thành công!", 
            type: "success"
          },
        function(){ 
            loadUser();
        });
    }
    else {
        swal({
            title: "Thông báo", 
            text: "cập nhật thông tin tài khoản thất bại", 
            type: "error"
          },
        function(){ });
    }
}


async function changePassword() {
    var token = localStorage.getItem("token");
    var oldpass = document.getElementById("oldpass").value
    var newpass = document.getElementById("newpass").value
    var renewpass = document.getElementById("renewpass").value
    var url = 'http://localhost:8080/api/all/changePassword?old='+oldpass+"&new="+newpass;
    if(newpass != renewpass){
        alert("mật khẩu mới không trùng khớp");
        return;
    }
    
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({
            title: "Thông báo", 
            text: "cập nhật mật khẩu thành công, hãy đăng nhập lại", 
            type: "success"
          },
        function(){ 
            window.location.reload()
        });
    }
    else {
        swal({
            title: "Thông báo", 
            text: "cập nhật mật khẩun thất bại, mật khẩu không chính xác", 
            type: "error"
          },
        function(){ });
    }
}


async function forgotpass(){
    var url = 'http://localhost:8080/api/resetpass'
    var email = document.getElementById("email").value
    const res = await fetch(url, {
        method: 'POST',
        headers: new Headers({
        }),
        body:email
    });
    if(res.status > 300){
        swal({
            title: "Thông báo", 
            text: "Không tìm thấy tài khoản hoặc tài khoản chưa được kích hoạt sau khi đăng ký", 
            type: "warning"
          },
        function(){ 
            window.location.reload();
        });
    }
    else{
        swal({
            title: "Thông báo", 
            text: "mật khẩu mới đã được gửi về email của bạn", 
            type: "success"
          },
        function(){ 
            window.location.reload();
        });
    }
}


function handleCredentialResponse(response) {
    console.log(response);
    console.log(response.credential);
    sendLoginRequestToBackend(response.credential);
}

async function sendLoginRequestToBackend(accessToken) {
    var response = await fetch('http://localhost:8080/api/login-goole', {
        method: 'POST',
        headers: {
            'Content-Type': 'text/plain'
        },
        body: accessToken
    })
    var token = await response.text();
    if (response.status < 300) {
        localStorage.setItem("token", JSON.stringify(token));
        var urlAccount = 'http://localhost:8080/api/userlogged';
        const res = await fetch(urlAccount, {
            method: 'POST',
            headers: new Headers({
                'Authorization': 'Bearer '+token,
                'Content-Type': 'application/json'
            })
        });

        var account = await res.json();
        window.localStorage.setItem('username', account.username);
        window.localStorage.setItem('user', JSON.stringify(account));
        var check = 0;
        for(i=0; i<account.authorities.length; i++){
            if(account.authorities[i].name === 'ROLE_ADMIN'){
                check = 1;
                localStorage.setItem("roleweb","ROLE_ADMIN")
            }
            if(account.authorities[i].name === 'ROLE_SALER'){
                check = 2;
                localStorage.setItem("roleweb","ROLE_SALER")
            }
            if(account.authorities[i].name === 'ROLE_USER'){
                check = 0;
                localStorage.setItem("roleweb","ROLE_USER")
            }
            if(account.authorities[i].name === 'ROLE_SHIPPER'){
                check = 3;
                localStorage.setItem("roleweb","ROLE_SHIPPER")
            }
        }
        if(check === 0){
            window.location.replace('index')
        }
        if(check === 1){
            window.location.replace('admin/index')
        }
        if(check === 2){
            window.location.replace('saler/account')
        }
        if(check === 3){
            window.location.replace('shipper/account')
        }
    }
    if (response.status == 417) {
        toastr.warning(result.defaultMessage);
    }
}
