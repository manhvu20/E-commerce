package com.web.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "stall")
@Getter
@Setter
public class Stall {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    private String name;

    private String phone;

    private String email;

    private String imageBanner;

    private String description;

    private Boolean actived;

    private String fullname;

    private String sdtLienHe;

    private String stressA;

    @ManyToOne
    @JoinColumn(name = "wards_id")
    private Wards wards;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
}
