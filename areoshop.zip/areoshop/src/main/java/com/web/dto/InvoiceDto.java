package com.web.dto;

import com.web.entity.Product;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InvoiceDto {

    private Product product;

    private Integer soLuong;

    private Boolean check = false;
}
