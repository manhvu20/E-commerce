package com.web.repository;

import com.web.entity.Province;
import com.web.entity.VoucherProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.sql.Date;
import java.util.List;

public interface VoucherProductRepository extends JpaRepository<VoucherProduct, Long> {

    @Query("select v from VoucherProduct v where v.stall.id = ?1")
    public List<VoucherProduct> findByStall(Long stallId);

    @Query("select v from VoucherProduct v where v.stall.id = ?1 and v.startDate <= ?2 and v.endDate >= ?2")
    public List<VoucherProduct> findByStallDangDienRa(Long stallId, Date date);

    @Query("select v from VoucherProduct v where v.stall.id = ?1 and v.startDate > ?2")
    public List<VoucherProduct> findByStallSapDienRa(Long stallId, Date date);

    @Query("select v from VoucherProduct v where v.stall.id = ?1 and v.endDate < ?2")
    public List<VoucherProduct> findByStallDaKetThuc(Long stallId, Date date);
}
