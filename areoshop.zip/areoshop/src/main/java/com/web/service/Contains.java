package com.web.service;

public class Contains {
    public static final String ROLE_ADMIN = "ROLE_ADMIN";
    public static final String ROLE_USER = "ROLE_USER";
    public static final String ROLE_SALER = "ROLE_SALER";
    public static final String ROLE_SHIPPER = "ROLE_SHIPPER";



    public static final Long idDangChoXacNhan = 1L;
    public static final Long dangGiao = 2L;
    public static final Long daNhan = 3L;
    public static final Long donHuy = 4L;
    public static final Long traHang = 5L;
    public static final Long khongNhan = 6L;
}
