package com.web.repository;

import com.web.entity.AddressUser;
import com.web.entity.Blog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AddressUserRepository extends JpaRepository<com.web.entity.AddressUser, Long> {

    @Query(value = "select a from AddressUser a where a.user.id = ?1")
    public List<AddressUser> findByUserId(Long userId);
}
