var token = localStorage.getItem("token");

async function kiemTraThongTin() {
    if(token == null){
        alert("bạn chưa đăng nhập")
        window.location.replace("login")
    }
    var url = 'http://localhost:8080/api/userlogged';
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var user = await response.json();
    if(user.fullname == null || user.fullname == "" || user.phone == null || user.phone == ""){
        swal({
            title: "Thông báo", 
            text: "Hãy cập nhật thông tin cá nhân của bạn!", 
            type: "warning"
          },
        function(){ 
            window.location.replace('account');
        });
    }
    var url = 'http://localhost:8080/api/user/addressUser';
    const res = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var list = await res.json();
    if(list.length < 1){
        swal({
            title: "Thông báo", 
            text: "Hãy cập thêm địa chỉ nhận hàng!", 
            type: "warning"
          },
        function(){ 
            window.location.replace('account');
        });
    }
}


async function showSanPham(){
	var list = JSON.parse(localStorage.getItem("cartdachon"));
	var main = '';
    var tongTien = 0;
	for(i=0; i<list.length; i++){
        tongTien = Number(tongTien) + Number(list[i].product.price * list[i].quantity);
		main += 
        `<div class="row singordercsd">
            <div class="col-2">
                <img src="${list[i].product.banner}" class="imgcsd">
            </div>
            <div class="col-4">
                <p class="tenspcsd"><a href="detail?id=${list[i].product.id}">${list[i].product.name}
                <span class="tenshopphu">(${list[i].product.stall.name})</span>
                </a></p>
                
            </div>
            <div class="col-1">
            ${list[i].quantity}
            </div>
            <div class="col-2">
                <p class="pricecsd">${formatmoney(list[i].product.price)}</p>
            </div>
            <div class="col-1" id="phantram${list[i].product.id}">
                
            </div>
            <div class="col-2">
                <p class="pricecsd" id="thanhtien${list[i].product.id}">${formatmoney(list[i].quantity * list[i].product.price)}</p>
            </div>
        </div>`
	}

	document.getElementById("listspxacnhan").innerHTML = main;
	document.getElementById("tongdha").innerHTML = formatmoney(tongTien);

    var listss = [];
    for(i=0; i<list.length; i++){
        listss.push(list[i].product.id);
	}
    var url = 'http://localhost:8080/api/public/voucherSpDangDienRa';
    const res = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(listss)
    });
    var listvoucher = await res.json();
    for(i=0; i<listvoucher.length; i++){
        document.getElementById("phantram"+listvoucher[i].product.id).innerHTML = listvoucher[i].voucherProduct.discount +"%";
    }


    
    var liststall = []
    for(i=0; i<list.length; i++){
        var checks = false;
        for(j=0; j<liststall.length; j++){
            if(liststall[j] == list[i].product.stall.id){
                checks = true;
            }
        }
        if(checks == false){
            liststall.push(list[i].product.stall.id)
        }
    }
    
    var url = 'http://localhost:8080/api/user/voucherCustomerDangDienRa';
    const resp = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(liststall)
    });
    var listcustomer = await resp.json();
    var ma = '';
    for(i=0; i<listcustomer.length; i++){
        ma += `<li><span class="tenshopvc">${listcustomer[i].stall.name}</span> ${listcustomer[i].name}: giảm giá ${listcustomer[i].discount}% cho toàn bộ đơn hàng của shop </li>`
    }
    document.getElementById("dsvoucustomer").innerHTML = ma;

    tongTien = 0;
    for(i=0; i<list.length; i++){
        for(j=0; j<listvoucher.length; j++){
            if(list[i].product.id == listvoucher[j].product.id){
                var thanht = list[i].quantity * list[i].product.price - (list[i].quantity * list[i].product.price * listvoucher[j].voucherProduct.discount /100);
                document.getElementById("thanhtien"+listvoucher[j].product.id).innerHTML = formatmoney(thanht);  
                tongTien = Number(tongTien) + Number(thanht);
                if(listcustomer.length == 0){
                    list.splice(i,1);
                }
            }
        }
    }
    for(i=0; i<list.length; i++){
        var thanht = list[i].quantity * list[i].product.price;
        tongTien = Number(tongTien) + Number(thanht);
    }

    if(listcustomer.length == 0){
        document.getElementById("tongdha").innerHTML = formatmoney(tongTien);
        tongTienDh = tongTien;
        return;
    }

    tongTien = 0;
    for(i=0; i<list.length; i++){
        for(j=0; j<listvoucher.length; j++){
            if(list[i].product.id == listvoucher[j].product.id){
                var thanht = list[i].quantity * list[i].product.price - (list[i].quantity * list[i].product.price * listvoucher[j].voucherProduct.discount /100);
                for(k=0; k<listcustomer.length; k++){
                    if(listcustomer[k].stall.id == list[i].product.stall.id){
                        thanht = Number(thanht) - Number(thanht)*listcustomer[k].discount/100;
                    }
                }
                tongTien = Number(tongTien) + thanht;
                list.splice(i,1);
                // --i;
            }
        }
    }
    console.log(tongTien)
    console.log(list)
    for(i=0; i<list.length; i++){
        var checs = false;
        for(j=0; j<listcustomer.length; j++){
            if(listcustomer[j].stall.id == list[i].product.stall.id){
                checs = true;
            }
        }
        if(checs == true){
            for(k=0; k<listcustomer.length; k++){
                if(list[i].product.stall.id == listcustomer[k].stall.id){
                     var thanht = (list[i].quantity * list[i].product.price) - (list[i].quantity * list[i].product.price * listcustomer[k].discount /100);
                     tongTien = Number(tongTien) + thanht;
                }     
             }
        }
        else{
            var thanht = list[i].quantity * list[i].product.price
            tongTien = Number(tongTien) + thanht;
        }
    }

    document.getElementById("tongdha").innerHTML = formatmoney(tongTien);
    tongTienDh = tongTien;


    for(var i=0; i<list.length; i++){
        var checked = false;
        for(var j=0; j< listShop.length; j++){
            if(list[i].product.stall.id == listShop[j].id){
                checked = true;
            }
        }
        if(checked == false){
            listShop.push(list[i].product.stall)
        }
    }

}


async function thongTinNguoiDung() {
    if(token == null){
        alert("bạn chưa đăng nhập")
        window.location.replace("login")
    }
    var url = 'http://localhost:8080/api/userlogged';
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var user = await response.json();
    document.getElementById("thongtinnhan").innerHTML = user.fullname+" ("+user.phone+")";
    var url = 'http://localhost:8080/api/user/addressUser';
    const res = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var list = await res.json();
    var dcdau = list[0];
    iddiachinhan = list[0].id;
    document.getElementById("diachinhan").innerHTML = dcdau.streetName + ", " +dcdau.wards.name + ", " +dcdau.wards.districts.name + ", " +dcdau.wards.districts.province.name

    var mains = ''
    for(i=0; i<list.length; i++){
        var dc = list[i];
        var diachis = dc.streetName + ", " +dc.wards.name + ", " +dc.wards.districts.name + ", " +dc.wards.districts.province.name
        var ch = `checked="checked"`;
        if(i != 0){
            ch = '';
        }
        mains += 
        `<label class="radio-custom">Địa chỉ: ${diachis}
            <input onclick="chonDiaChi(${list[i].id})" type="radio" name="radio" ${ch}>
            <span class="checkmark"></span>
        </label>`
    }
    document.getElementById("listdcnhanhang").innerHTML = mains;

    var province = await loadTinh(dcdau.wards.districts.province.name)
    console.log(province)

    var district = await loadHuyen(dcdau.wards.districts.name, province.ProvinceID);
    console.log(district)

    var ward = await loadXa(dcdau.wards.name, district.DistrictID);
    console.log(ward)

    var listShop = getListShop();
    console.log(listShop)
    var main = ``
    for(var i=0; i<listShop.length; i++){
        var provinceshop = await loadTinh(listShop[i].staff.wards.districts.province.name)
        var districtshop = await loadHuyen(listShop[i].staff.wards.districts.name, provinceshop.ProvinceID);
        var wardshop = await loadXa(listShop[i].staff.wards.name, districtshop.DistrictID);
        var weight = Math.ceil(listShop[i].weight);
        var url = '/api/shipping/tinh-phi?fromDistrictId='+district.DistrictID+'&fromWardCode='+ward.WardCode+'&toDistrictId='+districtshop.DistrictID+'&toWardCode='+wardshop.WardCode+'&weight='+weight
        const res = await fetch(url, {});
        var result = await res.json();
        var obj = {
            "shipCost":result.data.total,
            "staffId":listShop[i].staff.id
        }
        phiShip.push(obj);
        main += `<tr>
                     <td>${listShop[i].staff.name}</td>
                     <td>${listShop[i].weight} kg</td>
                     <td>${formatmoney(result.data.total)}</td>
                 </tr>`
    }
    document.getElementById("listship").innerHTML = main
}


var phiShip = [];

async function loadTinh(tentinh){
    var respon = await fetch('http://localhost:8080/api/shipping/public/province', {});
    var provinces = await respon.json();
    var province = null;
    for(var i=0; i< provinces.data.length; i++){
        if(tentinh.toLowerCase().includes(provinces.data[i].ProvinceName.toLowerCase())){
            province = provinces.data[i];
        }
    }
    return province
}
async function loadHuyen(tenhuyen, ProvinceID){
    var respon = await fetch('http://localhost:8080/api/shipping/public/district?provinceId='+ProvinceID, {});
    var districts = await respon.json();
    var district = null;
    for(var i=0; i< districts.data.length; i++){
        if(tenhuyen.toLowerCase().includes(districts.data[i].DistrictName.toLowerCase())){
            district = districts.data[i];
        }
    }
    return district
}

async function loadXa(tenxa, DistrictID){
    var respon = await fetch('http://localhost:8080/api/shipping/public/wards?districtId='+DistrictID, {});
    var wards = await respon.json();
    var ward = null;
    for(var i=0; i< wards.data.length; i++){
        if(tenxa.toLowerCase().includes(wards.data[i].WardName.toLowerCase())){
            ward = wards.data[i];
        }
    }
    return ward
}

function getListShop(){
    var listShop = [];
    var list = JSON.parse(localStorage.getItem("cartdachon"));
    for(var i=0; i<list.length; i++){
        var checked = false;
        var khoiluong = list[i].quantity * list[i].product.weight;
        for(var j=0; j< listShop.length; j++){
            if(list[i].product.stall.id == listShop[j].staff.id){
                checked = true;
                listShop[j].weight = Number(listShop[j].weight) + Number(khoiluong)
            }
        }
        if(checked == false){
            var obj = {
                "weight":khoiluong,
                "staff":list[i].product.stall
            }
            listShop.push(obj)
        }
    }
    return listShop
}


var iddiachinhan;
var tongTienDh;
async function chonDiaChi(id) {
    var url = 'http://localhost:8080/api/user/addressUserById?id='+id;
    const resp = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var dc = await resp.json();
    iddiachinhan = dc.id;
    document.getElementById("diachinhan").innerHTML = dc.streetName + ", " +dc.wards.name + ", " +dc.wards.districts.name + ", " +dc.wards.districts.province.name
}

async function taoDonHang() {
    var url = 'http://localhost:8080/api/user/taoDonHang?iddiachi='+iddiachinhan;
    var list = JSON.parse(localStorage.getItem("cartdachon"));
    for(i=0; i<list.length; i++){
        if(list[i].quantity > list[i].product.quantity){
            alert("sản phẩm "+list[i].product.name+" không đủ số lượng ("+list[i].product.quantity+")");
            return;
        }
    }
    var listsp = [];
    for(i=0; i<list.length; i++){
        var pro = {
            "product":list[i].product,
            "soLuong":list[i].quantity
        }
        listsp.push(pro);
    }
    var payload = {
        "invoiceDtos":listsp,
        "shippingDtos":phiShip
    }
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(payload)
    });
    if (response.status < 300) {
        swal({
            title: "Thông báo", 
            text: "Tạo đơn hàng thành công!", 
            type: "success"
          },
        function(){ 
            window.location.replace('account')
        });
    }
    else {
        swal({
            title: "Thông báo", 
            text: "Tạo đơn hàng thất bại", 
            type: "error"
          },
        function(){ 
        });
    }
}


async function donHangCuaToi() {
    var idtrang = document.getElementById("ulloaidonhang").value;
    var tensp = document.getElementById("tensp").value;

    var url = 'http://localhost:8080/api/user/donHangCuaToi?search='+tensp;
    if(idtrang != -1){
        url = 'http://localhost:8080/api/user/donHangCuaToi?search='+tensp+'&idtrangthai='+idtrang;
    }
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var list = await response.json();
    console.log(list)
    var main = '';
    for(i=0; i<list.length; i++){
        var ct = ''
        for(j=0; j<list[i].invoiceDetails.length; j++){
            var tongtien = 0;
            var chi = list[i].invoiceDetails[j];
            tongtien = Number(tongtien) + Number(chi.quantity * chi.price)
            var giamgia = '';
            var giacu = '';
            if(chi.productVoucherProduct != null){
                tongtien = Number(tongtien) - tongtien * chi.productVoucherProduct.voucherProduct.discount /100;
                giamgia = "(-"+chi.productVoucherProduct.voucherProduct.discount +'%)';
                giacu = `<p class="pricecsd giacux">${formatmoney(chi.price * chi.quantity)}</p>`;
            }
            var dms = chi.product.productCategories;
            var danhmuc = ''
            for(k=0; k<dms.length; k++){
                danhmuc += `<span>${dms[k].category.name}</span>, `
            }
            ct += `<div class="row singordercsd">
                        <div class="col-2">
                            <img src="${chi.product.banner}" class="imgcsd">
                        </div>
                        <div class="col-7">
                            <p class="tenspcsd"><a href="detail?id=${chi.product.id}">${chi.product.name}</a></p>
                            <p class="danhmuccsd">Danh mục: ${danhmuc}</p>
                            <p class="soluongcsd">Số lượng: <span>${chi.quantity}</span></p>
                        </div>
                        <div class="col-3">
                            ${giacu}
                            <p class="pricecsd">${formatmoney(tongtien)} <span class="ggsanpham">${giamgia}</span></p>
                        </div>
                </div>`
        }
        var ngayCapNhat = ''
        if(list[i].updateAt != null && list[i].updateTime != null){
            ngayCapNhat = `<span class="tgupdate">(${list[i].updateTime}, ${list[i].updateAt})</span>`
        }
        main += 
        `<div class="row ordersingle">
        <div class="col-8 thongtinshoporder">
            <p class="tenshopcsd">${list[i].stall.name}</p>
            <button class="btnchatcsd">Chat</button>
            <button class="btnxemshopcsd">Xem shop</button>
            <button class="btnxemshopcsd idbntshop">ID Đơn hàng: <span>#${list[i].id}</span></button>
        </div>
        <div class="col-4">
            <p class="trangthaidhcsd">${list[i].statusInvoice.name} ${ngayCapNhat}</p>
        </div><hr>
        <div class="row" id="listdetailorder">
            ${ct}
        </div>
        <div class="col-12" style="display: flex;">
            <button onclick="huyDonHang(${list[i].id})" class="btn btn-danger btnhuydon">Hủy đơn</button>
            <p class="pricethanhtien">Thanh toán: <span>${formatmoney(list[i].totalAmount)}</span> + Phí ship <span>${formatmoney(list[i].shipCost)}</span></p>
        </div>
    </div>`
    }
    document.getElementById("listmyorder").innerHTML = main;
}

async function loadTrangThaiDonHang() {
    var url = 'http://localhost:8080/api/public/trangThaiDonHang';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({})
    });
    var list = await response.json();
    var main = '<option value="-1">Tất cả đơn hàng</option>'
    for(i=0; i<list.length; i++){
        main += `<option value="${list[i].id}">${list[i].name}</option>`
    }
    document.getElementById("ulloaidonhang").innerHTML = main
}


async function huyDonHang(id) {
    var cons = confirm("Bạn chắc chắn muốn hủy đơn này?")
    if(cons){
        var url = 'http://localhost:8080/api/user/huyDonHang?iddonhang=' + id;
        const response = await fetch(url, {
            method: 'POST',
            headers: new Headers({
                'Authorization': 'Bearer ' + token
            })
        });
        var ok = await response.text();
        if (ok == 0) {
            swal({
                title: "Thông báo", 
                text: "Hủy đơn hàng thành công!", 
                type: "success"
              },
            function(){ 
                window.location.reload();
            });
        }
        if (ok == 1) {
            swal({
                title: "Thông báo", 
                text: "Đơn hàng không được phép hủy", 
                type: "warning"
              },
            function(){ 
                window.location.reload();
            });
        }
    }
    
}