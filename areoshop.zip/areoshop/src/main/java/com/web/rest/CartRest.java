package com.web.rest;

import com.web.entity.Blog;
import com.web.entity.Cart;
import com.web.entity.Product;
import com.web.entity.ProductVoucherProduct;
import com.web.repository.BlogRepository;
import com.web.repository.CartRepository;
import com.web.repository.ProductVoucherProductRepository;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class CartRest {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private ProductVoucherProductRepository productVoucherProductRepository;

    @PostMapping("/user/addCart")
    public void save(@RequestParam("id") Long productId){
        Cart cart = new Cart();
        Product product = new Product();
        product.setId(productId);
        cart.setProduct(product);
        cart.setUser(userService.getUserWithAuthority());
        cart.setQuantity(1);
        cartRepository.save(cart);
    }

    @GetMapping("/user/gioHangCuaToi")
    public List<Cart> findAll(@RequestParam("search") String search){
        List<Cart> list = cartRepository.gioHangCuaToi(userService.getUserWithAuthority().getId(), "%"+search+"%");
        for(Cart p : list){
            List<ProductVoucherProduct> l = productVoucherProductRepository.findBySanPham(p.getProduct().getId(), new Date(System.currentTimeMillis()));
            if(l.size() >0){
                p.getProduct().setGiamGia(l.get(l.size() - 1).getVoucherProduct().getDiscount());
            }
        }
        return list;
    }

    @DeleteMapping("/user/xoaGioHang")
    public void deleteCategory(@RequestParam("id") Long id){
        cartRepository.deleteById(id);
    }

    @GetMapping("/user/capNhatSoLuong")
    public void capNhatSoLuong(@RequestParam("id") Long id, @RequestParam("soLuong") Integer soLuong){
        Cart cart = cartRepository.findById(id).get();
        cart.setQuantity(cart.getQuantity() + soLuong);
        if(cart.getQuantity() > cart.getProduct().getQuantity()){
            return;
        }
        if(cart.getQuantity() < 1){
            cartRepository.deleteById(id);
            return;
        }
        cartRepository.save(cart);
    }
}
