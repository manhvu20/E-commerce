package com.web.rest;

import com.web.entity.Stall;
import com.web.entity.StatusInvoice;
import com.web.entity.User;
import com.web.repository.*;
import com.web.service.Contains;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class ThongKeRest {

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private StallRepository stallRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StatusInvoiceRepository statusInvoiceRepository;

    @GetMapping("/saler/doanhthu")
    public List<Double> doanhThu(@RequestParam("nam") Integer nam){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        List<Double> list = new ArrayList<>();
        for(int i=1; i< 13; i++){
            Double tong = invoiceRepository.tinhDoanhThu(i, nam, stall.getId());
            if (tong == null){
                tong = 0D;
            }
            list.add(tong);
        }
        return list;
    }

    @GetMapping("/admin/doanhthuall")
    public List<Double> doanhthuall(@RequestParam("nam") Integer nam){
        List<Double> list = new ArrayList<>();
        for(int i=1; i< 13; i++){
            Double tong = invoiceRepository.tinhDoanhThuAdmin(i, nam);
            if (tong == null){
                tong = 0D;
            }
            list.add(tong);
        }
        return list;
    }

    @GetMapping("/saler/donDangChoGiao")
    public Double donDangChoGiao(){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        return invoiceRepository.donDangChoGiao(stall.getId());
    }

    @GetMapping("/saler/doanhThuThangNay")
    public Double doanhThuThangNay(){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        Date date = new Date(System.currentTimeMillis());
        String[] str = date.toString().split("-");
        Integer year = Integer.valueOf(str[0]);
        Integer month = Integer.valueOf(str[1]);
        return invoiceRepository.tinhDoanhThu(month, year,stall.getId());
    }

    @GetMapping("/saler/soLuongSp")
    public Long soLuongSp(){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        return productRepository.tongSpTrongShopSaler(stall.getId());
    }

    @GetMapping("/saler/tongDonHangTrongShop")
    public Long tongDonHangTrongShop(){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        return invoiceRepository.tongDonHangTrongShop(stall.getId());
    }

    @GetMapping("/saler/soDonHomNay")
    public Long soDonHomNay(){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        return invoiceRepository.soDonHomNay(stall.getId(), new Date(System.currentTimeMillis()));
    }

    @GetMapping("/saler/soLuongSpViPham")
    public Long soLuongSpViPham(){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        return productRepository.tongSpViPhamTrongShop(stall.getId());
    }


    // ===================== admin =============================
    @GetMapping("/admin/soLuongSpViPhamAdmin")
    public Long soLuongSpViPhamAdmin(){
        return productRepository.tongSpViPhamAdmin();
    }

    @GetMapping("/admin/soLuongSpAdmin")
    public Long soLuongSpAdmin(){
        return productRepository.count();
    }

    @GetMapping("/admin/soLuongTaiKhoan")
    public Long soLuongTaiKhoan(){
        return userRepository.count();
    }

    @GetMapping("/admin/soLuongShop")
    public Long soLuongShop(){
        return stallRepository.count();
    }

    @GetMapping("/admin/doanhThuThangNayAdmin")
    public Double doanhThuThangNayAdmin(){
        Date date = new Date(System.currentTimeMillis());
        String[] str = date.toString().split("-");
        Integer year = Integer.valueOf(str[0]);
        Integer month = Integer.valueOf(str[1]);
        return invoiceRepository.tinhDoanhThuAdmin(month, year);
    }

    @GetMapping("/admin/soDonHomNayAdmin")
    public Long soDonHomNayAdmin(){
        return invoiceRepository.soDonHomNayAdmin(new Date(System.currentTimeMillis()));
    }

    @GetMapping("/saler/thong-ke-tong-quat")
    public ResponseEntity<?> thongKeTongQuat(){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        Map<String, String> map = new HashMap<>();

        Long soDonTrongNgay = invoiceRepository.soDonHomNay(stall.getId(), new Date(System.currentTimeMillis()));
        map.put("soDonTrongNgay", soDonTrongNgay.toString());

        Long soDonTuanNay = invoiceRepository.soDonTuanNay(stall.getId());
        map.put("soDonTuanNay", soDonTuanNay.toString());

        Long soDonThangNay = invoiceRepository.soDonThangNay(stall.getId());
        map.put("soDonThangNay", soDonThangNay.toString());

        Double doanhThuNgay = invoiceRepository.doanhThuHomNayTheoTrangThai(stall.getId(), Contains.daNhan);
        if(doanhThuNgay == null) doanhThuNgay = 0D;
        map.put("doanhThuNgay", doanhThuNgay.toString());

        Double doanhThuTuanNay = invoiceRepository.doanhThuTuanNay(stall.getId(), Contains.daNhan);
        if(doanhThuTuanNay == null) doanhThuTuanNay = 0D;
        map.put("doanhThuTuanNay", doanhThuTuanNay.toString());

        Double doanhThuThangNay = invoiceRepository.doanhThuThangNay(stall.getId(), Contains.daNhan);
        if(doanhThuThangNay == null) doanhThuThangNay = 0D;
        map.put("doanhThuThangNay", doanhThuThangNay.toString());

        Long soDonHoanThanh = invoiceRepository.soDonTheoTrangThai(stall.getId(), Contains.daNhan);
        map.put("soDonHoanThanh", soDonHoanThanh.toString());

        Long soDonHuy = invoiceRepository.soDonTheoTrangThai(stall.getId(), Contains.donHuy);
        map.put("soDonHuy", soDonHuy.toString());

        Long soDonKhongNhan = invoiceRepository.soDonTheoTrangThai(stall.getId(), Contains.khongNhan);
        map.put("soDonKhongNhan", soDonKhongNhan.toString());

        return new ResponseEntity<>(map,HttpStatus.OK);
    }



    @GetMapping("/admin/thong-ke-tong-quat")
    public ResponseEntity<?> thongKeTongQuatAdmin(){
        Map<String, String> map = new HashMap<>();

        Long soDonTrongNgay = invoiceRepository.soDonHomNay(new Date(System.currentTimeMillis()));
        map.put("soDonTrongNgay", soDonTrongNgay.toString());

        Long soDonTuanNay = invoiceRepository.soDonTuanNay();
        map.put("soDonTuanNay", soDonTuanNay.toString());

        Long soDonThangNay = invoiceRepository.soDonThangNay();
        map.put("soDonThangNay", soDonThangNay.toString());

        Double doanhThuNgay = invoiceRepository.doanhThuHomNayTheoTrangThai(Contains.daNhan);
        if(doanhThuNgay == null) doanhThuNgay = 0D;
        map.put("doanhThuNgay", doanhThuNgay.toString());

        Double doanhThuTuanNay = invoiceRepository.doanhThuTuanNay(Contains.daNhan);
        if(doanhThuTuanNay == null) doanhThuTuanNay = 0D;
        map.put("doanhThuTuanNay", doanhThuTuanNay.toString());

        Double doanhThuThangNay = invoiceRepository.doanhThuThangNay(Contains.daNhan);
        if(doanhThuThangNay == null) doanhThuThangNay = 0D;
        map.put("doanhThuThangNay", doanhThuThangNay.toString());

        Long soDonHoanThanh = invoiceRepository.soDonTheoTrangThai(Contains.daNhan);
        map.put("soDonHoanThanh", soDonHoanThanh.toString());

        Long soDonHuy = invoiceRepository.soDonTheoTrangThai(Contains.donHuy);
        map.put("soDonHuy", soDonHuy.toString());

        Long soDonKhongNhan = invoiceRepository.soDonTheoTrangThai(Contains.khongNhan);
        map.put("soDonKhongNhan", soDonKhongNhan.toString());

        return new ResponseEntity<>(map,HttpStatus.OK);
    }
}
