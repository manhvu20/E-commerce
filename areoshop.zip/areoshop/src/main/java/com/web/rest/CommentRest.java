package com.web.rest;
import com.web.entity.Comment;
import com.web.entity.User;
import com.web.repository.CommentRepository;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class CommentRest {
    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private UserService userService;

    @PostMapping("/user/saveCommnet")
    public void save(@RequestBody Comment comment){
        User user = userService.getUserWithAuthority();
        comment.setUser(user);
        comment.setCreatedDate(new Date(System.currentTimeMillis()));
        comment.setCreatedTime(new Time(System.currentTimeMillis()));
        commentRepository.save(comment);
    }

    @GetMapping("/public/comments")
    public List<Comment> findByPro(@RequestParam("id") Long id){
        List<Comment> list = commentRepository.findByProId(id);
        try {
            User user = userService.getUserWithAuthority();
            for(Comment c : list){
                if(c.getUser().getId() == user.getId()){
                    c.setMyComment(1);
                }
            }
        }
        catch (Exception e){
            return list;
        }
        return list;
    }

    @DeleteMapping("/user/deletcomments")
    public void delete(@RequestParam("id") Long id){
        commentRepository.deleteById(id);
    }

    @DeleteMapping("/saler/deletcommentssaler")
    public void deleteBySaler(@RequestParam("id") Long id){
        commentRepository.deleteById(id);
    }

    @GetMapping("/public/soLuongCommentShop")
    public Long soLuongCommentShop(@RequestParam("id") Long idshop){
        return commentRepository.soLuongCommentShop(idshop);
    }
}
