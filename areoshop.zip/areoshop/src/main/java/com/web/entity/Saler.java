package com.web.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "saler")
@Getter
@Setter
public class Saler {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    private String avatar;

    private String phone;

    private String fullname;

    private String email;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
}
