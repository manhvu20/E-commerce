var size = 8;
async function loadBlogMoiNhat(page) {
    var url = 'http://localhost:8080/api/public/allbloguser?size='+size+'&page='+page;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var listpro = await response.json();
    console.log(listpro)
    var list = listpro.content;
    var totalPage = listpro.totalPages 
    var totalElements = listpro.totalElements
    var main = '';
    for (i = 0; i < list.length; i++) {
        main += ` <div class="col-sm-3 singleproduct">
                    <div class="noidungsp">
                    <a href="chitietbaiviet?id=${list[i].id}"><img class="imgsingleproduct" src="${list[i].imageBanner}"></a>
                        <div class="thongtinsp">
                            <h4 class="tensp"><a href="chitietbaiviet?id=${list[i].id}">${list[i].title}</a></h4>
                            <p class="dabanps">Ngày đăng <i class="fa fa-calendar"></i>: <span class="daban">2023-12-01</span></p>
                            <p class="diachisp">Người đăng <i class="fa fa-user"></i>: Admin</p>
                        </div>
                    </div>
                </div>`
    }
    document.getElementById("listblog").innerHTML = main

    var mainpage = ''
    for(i=1; i<= totalPage; i++){
        mainpage += '<li onclick="loadSanPhamMoi('+(Number(i)-1)+')" class="page-item"><a class="page-link" href="#listblog">'+i+'</a></li>'
    }
    document.getElementById("listpageblog").innerHTML = mainpage
}


async function chiTietBaiViet() {
    var id = window.location.search.split('=')[1];
    if(id != null){
        var url = 'http://localhost:8080/api/public/blogById?id='+id;
        const response = await fetch(url, {
            method: 'GET',
            headers: new Headers({
            })
        });
        var blog = await response.json();
        document.getElementById("tieudebv").innerText = blog.title
        document.getElementById("noiDungbv").innerHTML = blog.content

    }
}
