package com.web.rest;

import com.web.dto.VoucherProductDto;
import com.web.entity.*;
import com.web.repository.*;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class VoucherCustomerRest {

    @Autowired
    private VoucherCustomerRepository voucherCustomerRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private StallRepository stallRepository;

    @Autowired
    private InvoiceRepository invoiceRepository;

    @PostMapping("/saler/addVoucherCustomer")
    public void save(@RequestBody VoucherCustomer voucherCustomer){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        voucherCustomer.setStall(stall);
        if(voucherCustomer.getId() == null){
            voucherCustomer.setNumUsed(0);
        }
        else{
            VoucherCustomer v = voucherCustomerRepository.findById(voucherCustomer.getId()).get();
            voucherCustomer.setNumUsed(v.getNumUsed());
        }
        voucherCustomerRepository.save(voucherCustomer);
    }

    @GetMapping("/public/voucherCustomerByID")
    public VoucherCustomer findById(@RequestParam("id") Long id){
        VoucherCustomer v = voucherCustomerRepository.findById(id).get();
        return v;
    }

    @GetMapping("/saler/myVoucherCustomerAndType")
    public List<VoucherCustomer> findByStallAndType(@RequestParam("type") Integer type){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        List<VoucherCustomer> list = null;
        if(type == 1){
            list = voucherCustomerRepository.findByStallDangDienRa(stall.getId(), new Date(System.currentTimeMillis()));
        }
        else if(type == 2){
            list = voucherCustomerRepository.findByStallSapDienRa(stall.getId(), new Date(System.currentTimeMillis()));
        }
        else if(type == 3){
            list = voucherCustomerRepository.findByStallDaKetThuc(stall.getId(), new Date(System.currentTimeMillis()));
        }
        else if(type == 0){
            list = voucherCustomerRepository.findByStall(stall.getId());
        }
        return list;
    }

    @DeleteMapping("/saler/deleteVoucherCustomer")
    public void delete(@RequestParam("id") Long id){
        User user = userService.getUserWithAuthority();
        Stall stall = stallRepository.findByUser(user.getId());
        VoucherCustomer v = voucherCustomerRepository.findById(id).get();
        if(v.getStall().getId() != stall.getId()){
            return;
        }
        voucherCustomerRepository.deleteById(id);
    }

    @PostMapping("/user/voucherCustomerDangDienRa")
    public List<VoucherCustomer> findByUser(@RequestBody List<Long> dsStall){
        User user = userService.getUserWithAuthority();
        List<VoucherCustomer> list = new ArrayList<>();
        for(Long l : dsStall){
            List<VoucherCustomer> vou = voucherCustomerRepository.findByStallDangDienRaConLai(l, new Date(System.currentTimeMillis()));
            if(vou.size() > 0){
                if(vou.get(vou.size() - 1).getQuantityPurchased() <= invoiceRepository.findByUserAndStall(user.getId(), l).size()){
                    list.add(vou.get(vou.size() - 1));
                }
            }
        }
        return list;
    }
}
