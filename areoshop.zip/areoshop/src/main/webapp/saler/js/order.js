var token = localStorage.getItem("token");

async function clickChonLoaiOrder(e, idtt){
    idtrangthai = idtt;
    var listcn = document.getElementById("ulloaidonhang").children;
    for(j=0; j<listcn.length; j++){
        listcn[j].classList.remove("activechon");
    }
    e.classList.add("activechon");
    donHangCuaShop();
}

async function loadTrangThaiDonHang() {
    var url = 'http://localhost:8080/api/public/trangThaiDonHang';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({})
    });
    var list = await response.json();
    var main = '<li onclick="clickChonLoaiOrder(this,-1)" class="chonloaihang activechon">Tất cả</li>'
    var mainsd = '';
    for(i=0; i<list.length; i++){
        main += `<li onclick="clickChonLoaiOrder(this,${list[i].id})" class="chonloaihang">${list[i].name}</li>`;
        mainsd += `<option value="${list[i].id}">${list[i].name}</option>`
    }
    document.getElementById("ulloaidonhang").innerHTML = main
    document.getElementById("listtrangthai").innerHTML = mainsd
}

var idtrangthai = -1;
async function donHangCuaShop() {
    var start = document.getElementById("start").value
    var end = document.getElementById("end").value
    var url = 'http://localhost:8080/api/saler/donHangCuaShop';
    if(start != "" && end != ""){
        url = 'http://localhost:8080/api/saler/donHangCuaShop?start='+start+'&end='+end;
    }
    if(idtrangthai != -1){
        url = 'http://localhost:8080/api/saler/donHangCuaShop?idtrangthaidh='+idtrangthai;
    }
    if(idtrangthai != -1 && start != "" && end != ""){
        url = 'http://localhost:8080/api/saler/donHangCuaShop?start='+start+'&end='+end+'&idtrangthaidh='+idtrangthai;
    }
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var list = await response.json();
    var main = ''
    for(i=0; i<list.length; i++){
        var ship = '';
        if(list[i].shipper != null){
            ship += list[i].shipper.user.fullname
            if(list[i].shipper.wards != null){
                ship += '<br>Địa chỉ: '+list[i].shipper.addressDetail+', '+list[i].shipper.wards.name+', '+list[i].shipper.wards.districts.name+', '+list[i].shipper.wards.districts.province.name
                ship += '<br>Số điện thoại: '+list[i].shipper.user.phone
                ship += '<br>Email: '+list[i].shipper.user.username
            }
            if(list[i].shipperConfirm == true){
                ship += `<br><span class="green-text"><i class="fa fa-check"></i> Đã xác nhận</span>`
            }
        }
        main += `<tr>
                    <td>${list[i].id}</td>
                    <td>${list[i].fullname}</td>
                    <td>${list[i].phone}</td>
                    <td>${list[i].address}</td>
                    <td>${list[i].createdDate}</td>
                    <td>${formatmoney(list[i].totalAmount)}</td>
                    <td>${formatmoney(list[i].shipCost)}</td>
                    <td>${list[i].statusInvoice.name}</td>
                    <td><span class="small-text">${ship}</span></td>
                    <td>
<!--                        <p onclick="loadTrangThaiHienTai(${list[i].statusInvoice.id},${list[i].id} )" data-bs-toggle="modal" data-bs-target="#modaltrangthai" class="poiter">Cập nhật đơn hàng</p>-->
                        <p onclick="chiTietDonHang(${list[i].id})" data-bs-toggle="modal" data-bs-target="#chitietdonhang" class="poiter">Chi tiết đơn hàng</p>
                        ${list[i].shipperConfirm == null || list[i].shipperConfirm == false || list[i].shipper == null?
                        `<button onclick="setDonHangShip(${list[i].id})" data-bs-toggle="modal" data-bs-target="#modelshipper" class="btn btn-danger"><i class="fa fa-users"></i></button>`:''}
                    </td>
                </tr>`
    }
    document.getElementById("listorder").innerHTML = main;
    document.getElementById("soluongdh").innerHTML = list.length;
}

async function chiTietDonHang(iddonhang) {
    var url = 'http://localhost:8080/api/saler/chitietDh?id='+iddonhang;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var order = await response.json();
    var list = order.invoiceDetails;
    var main = ''
    for(i=0; i<list.length; i++){
        var giamgia = '0%';
        var tongtien = list[i].price * list[i].quantity;
        if(list[i].productVoucherProduct != null){
            giamgia = list[i].productVoucherProduct.voucherProduct.discount +'%';
            tongtien = Number(tongtien) - tongtien * list[i].productVoucherProduct.voucherProduct.discount / 100;
        }
        main += `<div class="row singordercsd">
        <div class="col-2"><img src="${list[i].product.banner}" class="imgcsd"></div>
        <div class="col-4"><p class="tenspcsd"><a href="../detail?id=${list[i].product.id}">${list[i].product.name}</a></p></div>
        <div class="col-1">${list[i].quantity}</div>
        <div class="col-2"><p class="pricecsd">${formatmoney(list[i].price)}</p></div>
        <div class="col-1"><p class="pricecsd">${giamgia}</p></div>
        <div class="col-2"><p class="pricecsd">${formatmoney(tongtien)}</p></div>
    </div><br>`;
    }
    document.getElementById("listchitietdh").innerHTML = main
}

function loadTrangThaiHienTai(idstatus, iddh){
    document.getElementById("iddonhangs").value = iddh
    document.getElementById("listtrangthai").value = idstatus
}

async function capNhatTrangThai() {
    var iddh = document.getElementById("iddonhangs").value
    var idtrangthaidh = document.getElementById("listtrangthai").value
    var url = 'http://localhost:8080/api/saler/capNhatDonHang?iddonhang=' + iddh+'&idtrangthaidh='+idtrangthaidh;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({
            title: "Thông báo", 
            text: "Thành công", 
            type: "success"
          },
        function(){ 
            window.location.reload();
        });
    }
    else {
        swal({
            title: "Thông báo", 
            text: "hành động thất bại", 
            type: "error"
          },
        function(){ 
        });
    }
}

function setDonHangShip(id){
    document.getElementById("donhangship").value = id
}

async function listShipper(check) {
    var xa = document.getElementById("xa").value
    var url = 'http://localhost:8080/api/all/get-all-shipper';
    if(check != null){
        url += "?wardId="+xa
    }
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var list = await response.json();
    var main = ''
    for(i=0; i<list.length; i++){
        main += `<tr>
                    <td>${list[i].user.fullname}</td>
                    <td>${list[i].user.phone}</td>
                    <td>${list[i].addressDetail} 
                    ${list[i].wards == null?'':', '+list[i].wards.name+', '+list[i].wards.districts.name+', '+list[i].wards.districts.province.name}</td>
                    <td>
                    <button onclick="capNhatShipper(${list[i].id})" class="btn btn-primary">Chọn</button>
                    </td>
                </tr>`
    }
    document.getElementById("listshipper").innerHTML = main;
}

async function capNhatShipper(idshipper){
    var con = confirm("Xác nhận chọn shipper này?");
    if(con == false){
        return;
    }
    var donhangship = document.getElementById("donhangship").value;
    var url = 'http://localhost:8080/api/saler/update-invoice-shipper?id=' + donhangship+'&shipperId='+idshipper;
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({
                title: "Thông báo",
                text: "Thành công",
                type: "success"
            },
            function(){
                donHangCuaShop();
            });
    }
    else {
        swal({
                title: "Thông báo",
                text: "hành động thất bại",
                type: "error"
            },
            function(){
            });
    }
}