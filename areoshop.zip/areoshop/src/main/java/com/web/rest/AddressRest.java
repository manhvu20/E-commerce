package com.web.rest;
import com.web.dto.CategoryDto;
import com.web.dto.NoiBanDto;
import com.web.entity.Districts;
import com.web.entity.Province;
import com.web.entity.Wards;
import com.web.repository.DistrictsRepository;
import com.web.repository.ProvinceRepository;
import com.web.repository.WardsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class AddressRest {

    @Autowired
    private ProvinceRepository provinceRepository;

    @Autowired
    private DistrictsRepository districtsRepository;

    @Autowired
    private WardsRepository wardsRepository;

    @GetMapping("/public/province")
    public List<Province> findAllProvince(){
        return provinceRepository.findAll();
    }

    @GetMapping("/public/districts")
    public List<Districts> getTownByProvinceId(@RequestParam("id") Long id){
        return districtsRepository.findByProvin(id);
    }

    @GetMapping("/public/wards")
    public List<Wards> getVillageByTownId(@RequestParam("id") Long id){
        return wardsRepository.findByDis(id);
    }


    @GetMapping("/public/tatCaNoiBan")
    public List<NoiBanDto> noiBan(){
        List<NoiBanDto> list = new ArrayList<>();
        List<Object[]> obj = provinceRepository.tinhSoLuongSpTinh();
        for(Object[] o : obj){
            NoiBanDto c = new NoiBanDto();
            c.setId((BigInteger) o[0]);
            c.setName((String) o[1]);
            c.setSoLuongSp((BigInteger) o[2]);
            list.add(c);
        }
        return list;
    }
}
