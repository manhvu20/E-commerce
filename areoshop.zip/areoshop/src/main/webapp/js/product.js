var size = 8;

var token = localStorage.getItem("token");

async function loadSanPhamMoi(page) {
    var url = 'http://localhost:8080/api/public/sanPhamMoi?size='+size+'&page='+page;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var listpro = await response.json();
    console.log(listpro)
    var list = listpro.content;
    var totalPage = listpro.totalPages
    var main = '';
    for (i = 0; i < list.length; i++) {
        var tinhs = ''
        if(list[i].stall.wards != null){
            tinhs = list[i].stall.wards.districts.province.name
        }
        var giamgia = '<span class="giamgiasp">&ThinSpace;</span>'
        var gachGiaCu =''
        var giaMoi = formatmoney(list[i].price);
        if(list[i].giamGia != null){
            gachGiaCu = 'gachgiacu'
            giaMoi =  formatmoney(list[i].price - list[i].price*list[i].giamGia/100);
            giamgia = `<span class="giamgiasp">(-${list[i].giamGia}%)  <span class="gachgiacu">${formatmoney(list[i].price)} </span></span>`
        }
        main += `<div class="col-sm-2 singleproduct">
                    <a href="detail?id=${list[i].id}"><div class="noidungsp">
                        <img class="imgsingleproduct" src="${list[i].banner}">
                        <div class="thongtinsp">
                            <h4 class="tensp"><a href="detail?id=${list[i].id}">${list[i].name}</a></h4>
                            <p class="pricesp">${giaMoi} </p>
                            <p class="dabanps">Đã bán: <span class="daban">${list[i].doanhSo}</span></p><br>
                            ${giamgia}
                            <p class="diachisp">${tinhs}</p>
                        </div>
                    </div></a>
                </div>`
    }
    document.getElementById("listspbanchay").innerHTML = main

    var mainpage = ''
    for(i=1; i<= totalPage; i++){
        mainpage += '<li onclick="loadSanPhamMoi('+(Number(i)-1)+')" class="page-item"><a class="page-link" href="#listspbanchay">'+i+'</a></li>'
    }
    document.getElementById("listpage").innerHTML = mainpage
}

async function chitietsp() {
    if(token == null){
        document.getElementById("mycomment").style.display = 'none'
    }
    var id = window.location.search.split('=')[1];
    var url = 'http://localhost:8080/api/public/productByID?id='+id;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var pro = await response.json();
    console.log(pro)
    document.getElementById("detailten").innerHTML = pro.name
    document.getElementById("pricedetail").innerHTML = formatmoney(pro.price)
    document.getElementById("dabandetail").innerHTML = pro.doanhSo
    document.getElementById("spdetailimg").src = pro.banner
    document.getElementById("descriptionsp").innerHTML = pro.description
    document.getElementById("motasp").innerHTML = pro.description
    document.getElementById("motasp").innerHTML = pro.description
    document.getElementById("ngaythanhlap").innerHTML = pro.stall.user.createdDate
    document.getElementById("soluongsp").innerHTML = pro.stall.user.createdDate

    if(pro.giamGia != null){
        document.getElementById("pricedetail").innerHTML
            = formatmoney(pro.price - pro.price*pro.giamGia/100)
            +`<br><p class="giacuchitiet">${formatmoney(pro.price)}<span class="giamgiachitiet"> (-${pro.giamGia}%)</span></p>`
    }

    var listimage = pro.imageProducts;
    var main = `<img src="${pro.banner}" class="anhphu">`
    for(i=0; i<listimage.length; i++){
        main += `<img src="${listimage[i].linkImage}" class="anhphu">`
    }
    document.getElementById("listanhphu").innerHTML = main

    var url = 'http://localhost:8080/api/public/tongSpTrongShop?id='+pro.stall.id;
    const res = await fetch(url, {method: 'GET',headers: new Headers({})});
    var tongsp = await res.text();
    document.getElementById("soluongsp").innerHTML = tongsp

    var li = pro.productCategories;
    var mains = ''
    for(i=0; i<li.length; i++){
        mains += `<a class="danhmucdetail" href="product?category=${li[i].category.id}">${li[i].category.name}</a>`
    }
    document.getElementById("listdanhmuc").innerHTML = mains


    var shop = pro.stall
    document.getElementById("tenshop").innerHTML = shop.name
    document.getElementById("bannershop").src = shop.imageBanner
    document.getElementById("ngaythanhlap").innerHTML = shop.user.createdDate
    document.getElementById("btnxemshop").onclick = function(){
        window.location.href = 'shop?id='+pro.stall.id
    }

}

async function locSanPham() {
    var small = document.getElementById("small").value;
    var large = document.getElementById("large").value;
    var sapxepgia = document.getElementById("sapxepgia").value;
    if(small == ""){
        small = 0;
    }
    if(large == ""){
        large = 10000000000;
    }
    var listdm = []
    var listtinh = []
    var lists = document.getElementsByClassName("danhmuctk");
    for (i = 0; i < lists.length; i++) {
        if (lists[i].checked == true) {
            listdm.push(lists[i].value);
        }
    }
    lists = document.getElementsByClassName("noiban");
    for (i = 0; i < lists.length; i++) {
        if (lists[i].checked == true) {
            listtinh.push(lists[i].value);
        }
    }
    console.log(listdm)
    console.log(listtinh)
    var search = {
        "dmId":listdm,
        "tinhs":listtinh,
        "small":small,
        "large":large,
        "sortPrice":sapxepgia
    }

    var url = 'http://localhost:8080/api/public/searchProduct';
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({'Content-Type': 'application/json'}),
        body: JSON.stringify(search)
    });
    var list = await response.json();
    console.log(list)
    var main = '';
    for (i = 0; i < list.length; i++) {
        var tinhs = ''
        if(list[i].stall.wards != null){
            tinhs = list[i].stall.wards.districts.province.name
        }
        var giamgia = '<span class="giamgiasp">&ThinSpace;</span>'
        var gachGiaCu =''
        var giaMoi = formatmoney(list[i].price);
        if(list[i].giamGia != null){
            gachGiaCu = 'gachgiacu'
            giaMoi =  formatmoney(list[i].price - list[i].price*list[i].giamGia/100);
            giamgia = `<span class="giamgiasp">(-${list[i].giamGia}%)  <span class="gachgiacu">${formatmoney(list[i].price)} </span></span>`
        }
        main += `<div class="col-sm-3 singleproduct">
                    <a href="detail?id=${list[i].id}"><div class="noidungsp">
                        <img class="imgsingleproduct" src="${list[i].banner}">
                        <div class="thongtinsp">
                            <h4 class="tensp"><a href="detail?id=${list[i].id}">${list[i].name}</a></h4>
                            <p class="pricesp">${giaMoi} </p>
                            <p class="dabanps">Đã bán: <span class="daban">${list[i].doanhSo}</span></p><br>
                            ${giamgia}
                            <p class="diachisp">${tinhs}</p>
                        </div>
                    </div></a>
                </div>`
    }
    document.getElementById("listspsearch").innerHTML = main
}


async function searchSanPham() {
    var uls = new URL(document.URL)
    var category = uls.searchParams.get("category");
    var search = uls.searchParams.get("search");
    if(category == null && search == null){
        locSanPham();
        return;
    }
    var url = 'http://localhost:8080/api/public/timKiemSanPham';
    if(category != null){
        url += '?category='+category
    }
    if(search != null){
        url += '?search='+search
        document.getElementById("tukhoatinkiem").innerHTML = ' " '+search+' "'
    }
    const response = await fetch(url, {
        method: 'GET',
    });
    var list = await response.json();
    console.log(list)
    var main = '';
    for (i = 0; i < list.length; i++) {
        var tinhs = ''
        if(list[i].stall.wards != null){
            tinhs = list[i].stall.wards.districts.province.name
        }
        var giamgia = '<span class="giamgiasp">&ThinSpace;</span>'
        var gachGiaCu =''
        var giaMoi = formatmoney(list[i].price);
        if(list[i].giamGia != null){
            gachGiaCu = 'gachgiacu'
            giaMoi =  formatmoney(list[i].price - list[i].price*list[i].giamGia/100);
            giamgia = `<span class="giamgiasp">(-${list[i].giamGia}%)  <span class="gachgiacu">${formatmoney(list[i].price)} </span></span>`
        }
        main += `<div class="col-sm-3 singleproduct">
                    <a href="detail?id=${list[i].id}"><div class="noidungsp">
                        <img class="imgsingleproduct" src="${list[i].banner}">
                        <div class="thongtinsp">
                            <h4 class="tensp"><a href="detail?id=${list[i].id}">${list[i].name}</a></h4>
                            <p class="pricesp">${giaMoi} </p>
                            <p class="dabanps">Đã bán: <span class="daban">${list[i].doanhSo}</span></p><br>
                            ${giamgia}
                            <p class="diachisp">${tinhs}</p>
                        </div>
                    </div></a>
                </div>`
    }
    document.getElementById("listspsearch").innerHTML = main
}


