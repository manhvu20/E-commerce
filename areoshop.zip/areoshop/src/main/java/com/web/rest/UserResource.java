package com.web.rest;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.web.dto.CustomUserDetails;
import com.web.dto.UserDto;
import com.web.entity.User;
import com.web.exception.MessageException;
import com.web.jwt.JwtTokenProvider;
import com.web.repository.UserRepository;
import com.web.service.GoogleOAuth2Service;
import com.web.service.MailService;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Date;
import java.sql.Time;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class UserResource {

    private final UserRepository userRepository;

    private final JwtTokenProvider jwtTokenProvider;

    private final UserService userService;

    private final MailService mailService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private GoogleOAuth2Service googleOAuth2Service;

    public UserResource(UserRepository userRepository, JwtTokenProvider jwtTokenProvider, UserService userService, MailService mailService) {
        this.userRepository = userRepository;
        this.jwtTokenProvider = jwtTokenProvider;
        this.userService = userService;
        this.mailService = mailService;
    }
    @PostMapping("/authenticate")
    public ResponseEntity<String> authenticate(@RequestBody User user) throws URISyntaxException {
        Optional<User> users = userService.findByUsernameAndPassword(user.getUsername(), user.getPassword());
        System.out.println(users);
        if(users.isPresent() == false){
            return ResponseEntity.status(401)
                    .body(null);
        }
        CustomUserDetails customUserDetails = new CustomUserDetails(users.get());
        String token = jwtTokenProvider.generateToken(customUserDetails);
        return ResponseEntity
                .created(new URI("/api/authen/" ))
                .body(token);
    }

    @PostMapping("/login-goole")
    public ResponseEntity<?> loginWithGoogle(@RequestBody String credential) throws Exception {
        GoogleIdToken.Payload payload = googleOAuth2Service.verifyToken(credential);
        if(payload == null){
            throw new MessageException("Đăng nhập thất bại");
        }
        String jwt = userService.loginWithGoogle(payload);
        return new ResponseEntity(jwt, HttpStatus.OK);
    }

    @PostMapping("/register")
    public ResponseEntity<Integer> save(@RequestBody User user) throws URISyntaxException {
        if(userRepository.findByUsername(user.getUsername()).isPresent() == true){
            HttpHeaders headers = new HttpHeaders();
            return ResponseEntity.status(500).headers(headers)
                    .body(2);
        }
        User result = userService.save(user);
        mailService.sendEmail(user.getUsername(), "Kích hoạt tài khoản website areo","click vào link bên dưới để xác thực tài khoản:<br> http://localhost:8080/keyactive?key="+result.getActivation_key(),false, true);
        System.out.println(result);
        return ResponseEntity
                .created(new URI("/api/save/" + result.getId()))
                .body(0);
    }

    @PostMapping("/public/checkUserExist")
    public Boolean checkUserExist(@RequestParam("email") String email){
        if(userRepository.countUserByUserName(email) > 0){
            return true;
        }
        return false;
    }

    @PostMapping("/userlogged")
    public User getUserLogged(){
        return userService.getUserWithAuthority();
    }


    @PostMapping("/admin/activeUser")
    public void activeOrUnactiveUser(@RequestParam("id") Long id){
        User user = userRepository.findById(id).get();
        if(user.getActived() == 1){
            user.setActived(0);
        }
        else{
            user.setActived(1);
        }
        userRepository.save(user);
    }

    @PostMapping("/resetpass")
    public ResponseEntity<String> forgotpass(@RequestBody String email) throws URISyntaxException {
        Optional<User> user = userRepository.findByUsernameLogin(email);
        if(user.isPresent() == false){
            return ResponseEntity.status(500)
                    .body("this email not exist");
        }
        else{
            String newPass = userService.randomPass();
            User users = user.get();
            users.setPassword(passwordEncoder.encode(newPass));
            userRepository.save(users);
            mailService.sendEmail(email,"Đặt lại mật khẩu website area","Mật khẩu mới của bạn là: "+newPass,false, false);
        }
        return ResponseEntity.status(200)
                .body("check your email");
    }

    @GetMapping("/public/findUserNotDtoById")
    public User findUserById(@RequestParam("id") Long id) {
        return userRepository.findById(id).get();
    }


    @PostMapping("/all/changePassword")
    public void changePassword(@RequestParam("old") String oldPass, @RequestParam("new") String newPass) throws Exception {
        User user = userService.getUserWithAuthority();
        if(passwordEncoder.matches(oldPass, user.getPassword())){
            user.setPassword(passwordEncoder.encode(newPass));
        }
        else{
            throw new Exception("password khong dung");
        }
        userRepository.save(user);
    }

    @PostMapping("/user/updateinfor")
    public void updateInfor(@RequestBody UserDto userDto){
        User user = userService.getUserWithAuthority();
        user.setFullname(userDto.getFullname());
        user.setPhone(userDto.getPhone());
        userRepository.save(user);
    }

    @PostMapping("/shipper/updateinfor")
    public void updateInforByShipper(@RequestBody UserDto userDto){
        User user = userService.getUserWithAuthority();
        user.setFullname(userDto.getFullname());
        user.setPhone(userDto.getPhone());
        userRepository.save(user);
    }

    @PostMapping("/admin/addAdmin")
    public ResponseEntity<Integer> addAdmin(@RequestBody User user) throws URISyntaxException {
        if(userRepository.countUserByUserName(user.getUsername()) > 0){
            HttpHeaders headers = new HttpHeaders();
            headers.add("username already exist ", user.getUsername());
            return ResponseEntity.status(300).headers(headers)
                    .body(1);
        }
        user.setActived(1);
        user.setCreatedDate(new Date(System.currentTimeMillis()));
        user.setCreatedTime(new Time(System.currentTimeMillis()));
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        User result = userRepository.save(user);
        System.out.println(result);
        return ResponseEntity
                .created(new URI("/api/save/" + result.getId()))
                .body(0);
    }

    @GetMapping("/admin/getUserByRole")
    public List<User> getUserNotAdmin(@RequestParam(value = "role", required = false) String role) {
        if(role == null){
            return userRepository.findAll();
        }
        return userRepository.getUserByRole(role);
    }


    @GetMapping("/admin/checkroleAdmin")
    public void checkroleAdmin(){
        System.out.println("admin role");
    }

    @GetMapping("/user/checkroleUser")
    public void checkroleUser(){
        System.out.println("user role");
    }

    @GetMapping("/saler/checkroleSaler")
    public void checkroleSaler(){
        System.out.println("user role");
    }

    @GetMapping("/shipper/checkroleShipper")
    public void checkroleShipper(){
        System.out.println("user role");
    }
}
