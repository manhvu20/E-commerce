package com.web.repository;

import com.web.entity.Category;
import com.web.entity.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.sql.Date;
import java.util.List;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {

    @Query("SELECT distinct i from Invoice i inner join i.invoiceDetails de where i.addressUser.user.id = ?1 and de.product.name like ?2 order by i.id desc")
    public List<Invoice> donHangCuaToi(Long userId, String search);

    @Query("SELECT distinct i from Invoice i where i.addressUser.user.id = ?1 and i.statusInvoice.id = ?2 order by i.id desc ")
    public List<Invoice> donHangCuaToiByTrangThai(Long userId, Long trangThai);

    @Query("select i from Invoice i where i.stall.id = ?2 and i.addressUser.user.id = ?1")
    public List<Invoice> findByUserAndStall(Long userId, Long stallId);

    @Query("select i from Invoice i where i.stall.id = ?1 and i.createdDate >= ?2 and i.createdDate <= ?3")
    public List<Invoice> findByStall(Long stallId, Date start, Date end);

    @Query("select i from Invoice i where i.shipper.id = ?1 and i.createdDate >= ?2 and i.createdDate <= ?3")
    public List<Invoice> findByShip(Long shipId, Date start, Date end);


    @Query("select i from Invoice i where i.stall.id = ?1 and i.createdDate >= ?2 and i.createdDate <= ?3 and i.statusInvoice.id = ?4")
    public List<Invoice> findByStallAndTrangThai(Long stallId, Date start, Date end, Long idTrangThai);

    @Query("select i from Invoice i where i.shipper.id = ?1 and i.createdDate >= ?2 and i.createdDate <= ?3 and i.statusInvoice.id = ?4")
    public List<Invoice> findByShipAndTrangThai(Long shipId, Date start, Date end, Long idTrangThai);

    @Query(value = "select SUM(i.total_amount) from invoice i where Month(i.created_date) = ?1 and YEAR(i.created_date) = ?2" +
            " and i.stall_id = ?3 and i.status_invoice_id = 3",nativeQuery = true)
    public Double tinhDoanhThu(Integer thang, Integer nam, Long stallId);


    @Query(value = "select SUM(i.total_amount) from invoice i where Month(i.created_date) = ?1 and YEAR(i.created_date) = ?2" +
            " and i.status_invoice_id = 3",nativeQuery = true)
    public Double tinhDoanhThuAdmin(Integer thang, Integer nam);

    @Query("select count (i.id) from Invoice i where i.statusInvoice.id = 1 and i.stall.id =?1")
    public Double donDangChoGiao(Long stallId);


    @Query("select count(i.id) from Invoice i where i.stall.id = ?1")
    public Long tongDonHangTrongShop(Long idStall);

    @Query("select count(i.id) from Invoice i where i.stall.id = ?1 and i.createdDate = ?2")
    public Long soDonHomNay(Long idStall, Date date);

    @Query("select count(i.id) from Invoice i where i.createdDate = ?1")
    public Long soDonHomNay(Date date);

    @Query("select sum(i.totalAmount) from Invoice i where i.stall.id = ?1 and i.createdDate = current_date and i.statusInvoice.id = ?2")
    public Double doanhThuHomNayTheoTrangThai(Long idStall, Long idTrangThai);

    @Query("select sum(i.totalAmount) from Invoice i where i.createdDate = current_date and i.statusInvoice.id = ?1")
    public Double doanhThuHomNayTheoTrangThai( Long idTrangThai);

    @Query("select count(i.id) from Invoice i where  i.createdDate = ?1")
    public Long soDonHomNayAdmin(Date date);

    @Query(value = "SELECT count(i.id) \n" +
            "FROM invoice i\n" +
            "WHERE (created_date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()) and i.stall_id = ?1", nativeQuery = true)
    public Long soDonTuanNay(Long stallId);

    @Query(value = "SELECT count(i.id) \n" +
            "FROM invoice i\n" +
            "WHERE (created_date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE())", nativeQuery = true)
    public Long soDonTuanNay();

    @Query(value = "SELECT sum(i.total_amount) \n" +
            "FROM invoice i\n" +
            "WHERE (created_date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()) and i.stall_id = ?1 and i.status_invoice_id = ?2", nativeQuery = true)
    public Double doanhThuTuanNay(Long stallId, Long idTrangThai);

    @Query(value = "SELECT sum(i.total_amount) \n" +
            "FROM invoice i\n" +
            "WHERE (created_date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()) and i.status_invoice_id = ?1", nativeQuery = true)
    public Double doanhThuTuanNay( Long idTrangThai);

    @Query("select count(i.id) from Invoice i where month(i.createdDate) = month(current_date) and " +
            "year(i.createdDate) = year(current_date) and i.stall.id = ?1")
    public Long soDonThangNay(Long stallId);

    @Query("select count(i.id) from Invoice i where month(i.createdDate) = month(current_date) and " +
            "year(i.createdDate) = year(current_date)")
    public Long soDonThangNay();

    @Query("select sum(i.totalAmount) from Invoice i where month(i.createdDate) = month(current_date) and " +
            "year(i.createdDate) = year(current_date) and i.stall.id = ?1 and i.statusInvoice.id = ?2")
    public Double doanhThuThangNay(Long stallId, Long idTrangThai);

    @Query("select sum(i.totalAmount) from Invoice i where month(i.createdDate) = month(current_date) and " +
            "year(i.createdDate) = year(current_date) and i.statusInvoice.id = ?1")
    public Double doanhThuThangNay(Long idTrangThai);

    @Query("select count(i.id) from Invoice i where i.stall.id = ?1 and i.createdDate = current_date and i.statusInvoice.id = ?2")
    public Long soDonTheoTrangThai(Long idStall, Long idTrangThai);

    @Query("select count(i.id) from Invoice i where i.createdDate = current_date and i.statusInvoice.id = ?1")
    public Long soDonTheoTrangThai(Long idTrangThai);
}
