package com.web.repository;

import com.web.entity.ImageProduct;
import com.web.entity.Province;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImageProductRepository extends JpaRepository<ImageProduct, Long> {
}
