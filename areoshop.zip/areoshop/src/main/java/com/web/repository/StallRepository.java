package com.web.repository;

import com.web.entity.Stall;
import com.web.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface StallRepository extends JpaRepository<Stall,Long> {

    @Query("select s from Stall s where s.user.id = ?1")
    public Stall findByUser(Long userId);
}
