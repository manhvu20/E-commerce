package com.web.controller.saler;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AllViewSalerController {

    @RequestMapping(value = {"/saler/account"}, method = RequestMethod.GET)
    public String account() {
        return "saler/account.html";
    }

    @RequestMapping(value = {"/saler/addproduct"}, method = RequestMethod.GET)
    public String addproduct() {
        return "saler/addproduct.html";
    }

    @RequestMapping(value = {"/saler/index"}, method = RequestMethod.GET)
    public String index() {
        return "saler/index.html";
    }

    @RequestMapping(value = {"/saler/inforshop"}, method = RequestMethod.GET)
    public String inforshop() {
        return "saler/inforshop.html";
    }

    @RequestMapping(value = {"/saler/khuyenmai"}, method = RequestMethod.GET)
    public String khuyenmai() {
        return "saler/khuyenmai.html";
    }

    @RequestMapping(value = {"/saler/order"}, method = RequestMethod.GET)
    public String order() {
        return "saler/order.html";
    }

    @RequestMapping(value = {"/saler/product"}, method = RequestMethod.GET)
    public String product() {
        return "saler/product.html";
    }

    @RequestMapping(value = {"/saler/wallet"}, method = RequestMethod.GET)
    public String wallet() {
        return "saler/wallet.html";
    }

    @RequestMapping(value = {"/saler/chat"}, method = RequestMethod.GET)
    public String getViewChat(){
        return "saler/chat";
    }
}
