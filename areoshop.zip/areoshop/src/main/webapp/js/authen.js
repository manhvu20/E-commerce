function openLogin(){
    document.getElementById("loginform").style.display = ""
    document.getElementById("regisform").style.display = "none"
    document.getElementById("forgotform").style.display = "none"
}
function openRegis(){
    document.getElementById("loginform").style.display = "none"
    document.getElementById("regisform").style.display = "block"
}
function openQuenpass(){
    document.getElementById("loginform").style.display = "none"
    document.getElementById("forgotform").style.display = "block"
}