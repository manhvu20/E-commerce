package com.web.repository;

import com.web.entity.Category;
import com.web.entity.Province;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface CategoryRepository extends JpaRepository<Category, Long> {

    @Query("select c from Category c where c.deleted = 0 order by c.id desc ")
    public List<Category> findAllDesc();

    @Query("select c from Category c where c.deleted = 0 and c.id = ?1")
    public Optional<Category> findById(Long id);

    @Query(value = "SELECT c.id, c.name, c.link_image, (SELECT COUNT(pc.id) from product_category pc where pc.category_id = c.id) as soluong\n" +
            "from category c where c.deleted = 0 or c.deleted is null ORDER by soluong desc;", nativeQuery = true)
    public List<Object[]> tatCaDanhMuc();

    @Query(value = "SELECT c.* from product_category pc \n" +
            "INNER join product p on p.id = pc.product_id\n" +
            "INNER JOIN category c on c.id = pc.category_id\n" +
            "where p.stall_id = 1\n" +
            "group by c.id", nativeQuery = true)
    public List<Category> danhMucCuaShop(Long idshop);
}
