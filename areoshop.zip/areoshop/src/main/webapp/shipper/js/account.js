
async function changePassword() {
    var token = localStorage.getItem("token");
    var oldpass = document.getElementById("oldpass").value
    var newpass = document.getElementById("newpass").value
    var renewpass = document.getElementById("renewpass").value
    var url = 'http://localhost:8080/api/all/changePassword?old='+oldpass+"&new="+newpass;
    if(oldpass == "" || newpass== "" || renewpass ==""){
        alert("dữ liệu không được để trống");
        return;
    }
    if(newpass != renewpass){
        alert("mật khẩu mới không trùng khớp");
        return;
    }

    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({
                title: "Thông báo",
                text: "cập nhật mật khẩu thành công, hãy đăng nhập lại",
                type: "success"
            },
            function(){
                window.location.reload()
            });
    }
    else {
        swal({
                title: "Thông báo",
                text: "cập nhật mật khẩun thất bại, mật khẩu không chính xác",
                type: "error"
            },
            function(){ });
    }
}

async function loadUser(){
    var urlAccount = 'http://localhost:8080/api/shipper/myaccount';
    const res = await fetch(urlAccount, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer '+token,
            'Content-Type': 'application/json'
        })
    });
    var shipper = await res.json();
    console.log(shipper)
    document.getElementById("fullnameship").value = shipper.user.fullname
    document.getElementById("phone").value = shipper.user.phone
    document.getElementById("emailstall").value = shipper.user.username
    document.getElementById("stressA").value = shipper.addressDetail
    if(shipper.wards != null){
        document.getElementById("diachishoop").innerHTML = shipper.addressDetail+", "+shipper.wards.name+", "+shipper.wards.districts.name+", "+shipper.wards.districts.province.name
        document.getElementById("tinh").value = shipper.wards.districts.province.id
        await loadTown(shipper.wards.districts.province.id);
        document.getElementById("huyen").value = shipper.wards.districts.id
        await loadWard(shipper.wards.districts.id);
        document.getElementById("xa").value = shipper.wards.id

    }
}


async function changeUser() {
    var token = localStorage.getItem("token");
    var url = 'http://localhost:8080/api/shipper/updateinfor';
    var fullname = document.getElementById("fullnameship").value
    var phone = document.getElementById("phone").value
    if(fullname == "" || phone== ""){
        alert("dữ liệu không được để trống");
        return;
    }
    var userDto = {
        "fullname":fullname,
        "phone":phone
    }
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(userDto)
    });
    if (response.status < 300) {
        swal({
                title: "Thông báo",
                text: "cập nhật thông tin tài khoản thành công!",
                type: "success"
            },
            function(){
                loadUser();
            });
    }
    else {
        swal({
                title: "Thông báo",
                text: "cập nhật thông tin tài khoản thất bại",
                type: "error"
            },
            function(){ });
    }
}


async function changeAddress() {
    var token = localStorage.getItem("token");
    var stressA = document.getElementById("stressA").value
    var xa = document.getElementById("xa").value
    var url = 'http://localhost:8080/api/shipper/update-address?wardId='+xa+'&detail='+stressA;
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({
                title: "Thông báo",
                text: "cập nhật thông tin địa chỉ thành công!",
                type: "success"
            },
            function(){
                window.location.reload();
            });
    }
    else {
        swal({
                title: "Thông báo",
                text: "cập nhật thông tin địa chỉ thất bại",
                type: "error"
            },
            function(){ });
    }
}