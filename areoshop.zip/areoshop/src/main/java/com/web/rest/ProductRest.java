package com.web.rest;
import com.web.dto.SearchDto;
import com.web.entity.*;
import com.web.repository.*;
import com.web.service.Contains;
import com.web.service.ProductService;
import com.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class ProductRest {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private StallRepository stallRepository;

    @Autowired
    private StatusProductRepository statusProductRepository;

    @Autowired
    private InvoiceDetailRepository invoiceDetailRepository;

    @Autowired
    private ProductCategoryRepository productCategoryRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductVoucherProductRepository productVoucherProductRepository;

    @GetMapping("/saler/Myproduct")
    public List<Product> findAll(@RequestParam(value = "statuspro") Long statuspro,@RequestParam(value = "search", required = false) String search){
        List<Product> list = null;
        if(statusProductRepository.findById(statuspro).isPresent() == false){
            list = productRepository.findByUser(userService.getUserWithAuthority().getId(),"%"+search+"%");
        }
        else{
            list = productRepository.findByUserAndStatusProduct(userService.getUserWithAuthority().getId(), statuspro,"%"+search+"%");
        }
        return list;
    }

    @GetMapping("/saler/myProductSearch")
    public List<Product> myProductSearch(@RequestParam(value = "statuspro") Long statuspro,
                                         @RequestParam("search") String search,
                                         @RequestParam("category") Long category){
        List<Product> list = null;
        User user = userService.getUserWithAuthority();
        if(statusProductRepository.findById(statuspro).isPresent() == false){
            if(categoryRepository.findById(category).isPresent() == false){
                list = productRepository.findByUser(user.getId(),"%"+search+"%");
            }
            else{
                list = productRepository.findByUserAndCategory(user.getId(),"%"+search+"%",category);
            }
        }
        else{
            if(categoryRepository.findById(category).isPresent() == false){
                list = productRepository.findByUserAndStatusProduct(user.getId(), statuspro,"%"+search+"%");
            }
            else{
                list = productRepository.findByUserAndStatusProductAndCategory(user.getId(), statuspro,"%"+search+"%", category);
            }
        }
        return list;
    }

    @PostMapping("/saler/addProduct")
    public Product save(@RequestBody Product product){
        product.setDeleted(0);
        if(product.getId() == null){
            StatusProduct statusProduct = statusProductRepository.findById(Contains.idDangChoXacNhan).get();
            product.setStatusProduct(statusProduct);
            product.setCreatedDate(new Date(System.currentTimeMillis()));
            product.setCreateTime(new Time(System.currentTimeMillis()));
            product.setDoanhSo(0);
            Stall stall = stallRepository.findByUser(userService.getUserWithAuthority().getId());
            product.setStall(stall);
        }
        else{
            productCategoryRepository.deleteByProductId(product.getId());
            Product pro = productRepository.findById(product.getId()).get();
            product.setStatusProduct(pro.getStatusProduct());
            product.setCreateTime(pro.getCreateTime());
            product.setCreatedDate(pro.getCreatedDate());
            product.setStall(pro.getStall());
            product.setDoanhSo(pro.getDoanhSo());
        }
        Product result = productRepository.save(product);
        for(Long i: product.getListIdDm()){
            ProductCategory p = new ProductCategory();
            p.setProduct(new Product());
            p.setCategory(new Category());
            p.getProduct().setId(result.getId());
            p.getCategory().setId(i);
            productCategoryRepository.save(p);
        }
        return result;
    }

    @GetMapping("/public/productByID")
    public Product findById(@RequestParam("id") Long id){
        Product pro = productRepository.findById(id).get();
        List<ProductVoucherProduct> list = productVoucherProductRepository.findBySanPham(pro.getId(), new Date(System.currentTimeMillis()));
        if(list.size() >0){
            pro.setGiamGia(list.get(list.size() - 1).getVoucherProduct().getDiscount());
        }
        return pro;
    }

    @DeleteMapping("/saler/deleteProduct")
    public void deleteProduct(@RequestParam("id") Long id) throws Exception {
        Product p = productRepository.findById(id).get();
        if(p.getStall().getUser().getId() != userService.getUserWithAuthority().getId()){
            throw new Exception("");
        }
        try {
            productRepository.deleteById(id);
        }
        catch (Exception e){
            p.setDeleted(1);
            productRepository.save(p);
        }
    }

    @GetMapping("/public/sanPhamMoi")
    public Page<Product> sanPhamMoi(Pageable pageable){
        Page<Product> page = productRepository.sanPhamMoi(pageable);
        for(Product p : page.getContent()){
            List<ProductVoucherProduct> list = productVoucherProductRepository.findBySanPham(p.getId(), new Date(System.currentTimeMillis()));
            if(list.size() >0){
                p.setGiamGia(list.get(list.size() - 1).getVoucherProduct().getDiscount());
            }
        }
        return page;
    }

    @GetMapping("/public/tongSpTrongShop")
    public Long tongSpTrongShop(@RequestParam("id") Long idStall){
        return productRepository.tongSpTrongShop(idStall);
    }

    @PostMapping("/public/searchProduct")
    public List<Product> search(@RequestBody SearchDto searchDto, Pageable pageable){
        List<Product> list = productService.searchProduct(searchDto);
        List<Product> listre = new ArrayList<>();
        for(Product p : list){
            listre.add(productRepository.findById(p.getId()).get());
        }
        for(Product p : listre){
            List<ProductVoucherProduct> l = productVoucherProductRepository.findBySanPham(p.getId(), new Date(System.currentTimeMillis()));
            if(l.size() >0){
                p.setGiamGia(l.get(l.size() - 1).getVoucherProduct().getDiscount());
            }
        }
        return listre;
    }

    @GetMapping("/public/timKiemSanPham")
    public List<Product> searchSp(@RequestParam(value = "category", required = false) Long category,
                                  @RequestParam(value = "search", required = false) String search){
        List<Product> list = null;
        if(category != null){
            list = productRepository.findByCategory(category);
        }
        if(search != null){
            list = productRepository.findByName("%"+search+"%");
        }
        for(Product p : list){
            List<ProductVoucherProduct> l = productVoucherProductRepository.findBySanPham(p.getId(), new Date(System.currentTimeMillis()));
            if(l.size() >0){
                p.setGiamGia(l.get(l.size() - 1).getVoucherProduct().getDiscount());
            }
        }
        return list;
    }

    @GetMapping("/admin/sanPhamAdmin")
    public List<Product> sanPhamAdmin(@RequestParam(value = "idtrangthai", required = false) Long trangThai,
                                        @RequestParam(value = "iddanhmuc", required = false) Long idDanhMuc,
                                      @RequestParam("search") String search){
        List<Product> list = null;
        if(trangThai != null && idDanhMuc != null){
            list = productRepository.sanPhamByDanhMucAndTrangThai(trangThai,"%"+search+"%",idDanhMuc);
            return list;
        }
        if(idDanhMuc != null){
            list = productRepository.sanPhamByDanhMuc(idDanhMuc, "%"+search+"%");
        }
        if(trangThai != null){
            list = productRepository.sanPhamByTrangThai(trangThai, "%"+search+"%");
        }
        if(idDanhMuc == null && trangThai == null){
            list = productRepository.findByNameAdmin("%"+search+"%");
        }
        return list;
    }

    @PostMapping("/admin/setSanPhamViPham")
    public void viPham(@RequestParam(value = "id") Long id, @RequestParam("noidung") String noiDung){
        Product product = productRepository.findById(id).get();
        if(product.getStatusProduct().getId() == 1){
            StatusProduct statusProduct = statusProductRepository.findById(3L).get();
            product.setStatusProduct(statusProduct);
            product.setFeedBackByAdmin(noiDung);
            productRepository.save(product);
            return;
        }
        if(product.getStatusProduct().getId() == 3){
            StatusProduct statusProduct = statusProductRepository.findById(1L).get();
            product.setStatusProduct(statusProduct);
            product.setFeedBackByAdmin("");
            productRepository.save(product);
            return;
        }
    }

    @PostMapping("/saler/setSanPhamHetHang")
    public void hetHang(@RequestParam(value = "id") Long id){
        Product product = productRepository.findById(id).get();
        if(product.getStatusProduct().getId() == 1){
            StatusProduct statusProduct = statusProductRepository.findById(2L).get();
            product.setStatusProduct(statusProduct);
            productRepository.save(product);
            return;
        }
        if(product.getStatusProduct().getId() == 2){
            StatusProduct statusProduct = statusProductRepository.findById(1L).get();
            product.setStatusProduct(statusProduct);
            productRepository.save(product);
            return;
        }
    }

    @GetMapping("/public/soLuongSpCuaShop")
    public Long soLuongSpCuaShop(@RequestParam("id") Long idshop){
        return productRepository.tongSpTrongShop(idshop);
    }

    @GetMapping("/public/sanPhamCuaShop")
    public List<Product> findByShop(@RequestParam("id") Long idshop,
                                    @RequestParam("orderBy") String orderBy,
                                    @RequestParam(value="iddanhmuc",required = false)  Long iddanhmuc){
        if(iddanhmuc == null){
            if(orderBy.equalsIgnoreCase("asc")){
                return productRepository.findByShopAsc(idshop);
            }
            else{
                return productRepository.findByShopDesc(idshop);
            }
        }
        else{
            if(orderBy.equalsIgnoreCase("desc")){
                return productRepository.findByShopAndDanhmucDesc(idshop, iddanhmuc);
            }
            else{
                return productRepository.findByShopAndDanhmucAsc(idshop, iddanhmuc);
            }
        }
    }
}
