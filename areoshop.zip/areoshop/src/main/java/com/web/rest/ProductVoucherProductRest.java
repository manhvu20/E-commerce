package com.web.rest;

import com.web.entity.ProductVoucherProduct;
import com.web.repository.ProductVoucherProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class ProductVoucherProductRest {

    @Autowired
    private ProductVoucherProductRepository productVoucherProductRepository;

    @GetMapping("/public/voucherProByVoucher")
    public List<ProductVoucherProduct> findByVoucher(@RequestParam("id") Long voucherId){
        return productVoucherProductRepository.findByVoucher(voucherId);
    }

    @PostMapping("/public/voucherSpDangDienRa")
    public List<ProductVoucherProduct> voucherSpDangDienRa(@RequestBody List<Long> dssp){
        List<ProductVoucherProduct> list = new ArrayList<>();
        for(Long l : dssp){
            List<ProductVoucherProduct> ds = productVoucherProductRepository.findBySanPham(l, new Date(System.currentTimeMillis()));
            if(ds.size() > 0){
                list.add(ds.get(ds.size() - 1));
            }
        }
        return list;
    }
}
