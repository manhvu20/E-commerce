var token = localStorage.getItem("token");

async function loadAddressUser() {
    var url = 'http://localhost:8080/api/user/addressUser';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var list = await response.json();
    var main = ''
    for(i=0; i<list.length; i++){
        main += `<tr>
                    <td>${list[i].streetName}</td>
                    <td>${list[i].wards.name}</td>
                    <td>${list[i].wards.districts.name}</td>
                    <td>${list[i].wards.districts.province.name}</td>
                    <td><button onclick="loadDiaChi(${list[i].id})" data-bs-toggle="modal" data-bs-target="#modaldiachi" class="btn btn-success"><i class="fa fa-edit"></i> Cập nhật</button></td>
                    <td><button onclick="deleteAddUser(${list[i].id})" class="btn btn-danger"><i class="fa fa-trash"></i> Xóa</button></td>
                </tr>`
    }
    document.getElementById("listAdd").innerHTML = main
}


async function themDiaChi() {
    var url = 'http://localhost:8080/api/user/addAddressUser';
    var id = document.getElementById("idadduser").value
    var tenduong = document.getElementById("tenduongu").value
    var wards = document.getElementById("xa").value
    var addUser = {
        "id":id,
        "streetName":tenduong,
        "wards":{
            "id":wards
        }
    }

    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(addUser)
    });
    if(response.status < 300){
        swal({
                title: "Thông báo",
                text: "thêm/sửa địa chỉ nhận hàng thành công!",
                type: "success"
            },
            function(){
                loadAddressUser();
                document.getElementById("idadduser").value = ""
                document.getElementById("tenduongu").value = ""
            });
    }
}


async function loadDiaChi(id) {
    var url = 'http://localhost:8080/api/user/addressUserById?id='+id;
    const resp = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var add = await resp.json();
    document.getElementById("tenduongu").value = add.streetName
    document.getElementById("idadduser").value = add.id
    document.getElementById("tinh").value = add.wards.districts.province.id

    var id =  document.getElementById("tinh").value

    var urladd = 'http://localhost:8080/api/public/districts?id='+id;
    const response = await fetch(urladd, {
    method: 'GET',
    headers: new Headers({
    })
    });
    var list = await response.json();
    var main = ''
    for(i=0; i<list.length; i++){
        main += `<option value="${list[i].id}">${list[i].name}</option>`
    }
    document.getElementById("huyen").innerHTML = main
    document.getElementById("huyen").value = add.wards.districts.id

    var urladd = 'http://localhost:8080/api/public/wards?id='+add.wards.districts.id;
    const res = await fetch(urladd, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var list = await res.json();
    var main = ''
    for(i=0; i<list.length; i++){
        main += `<option value="${list[i].id}">${list[i].name}</option>`
    }
    document.getElementById("xa").innerHTML = main
    document.getElementById("xa").value = add.wards.id
}

async function deleteAddUser(id) {
    var con = confirm("bạn muốn xóa địa chỉ này?")
    if(con){
        var url = 'http://localhost:8080/api/user/deleteAdressUser?id=' + id;
        const response = await fetch(url, {
            method: 'DELETE',
            headers: new Headers({
                'Authorization': 'Bearer ' + token
            })
        });loadAddressUser();
    }
}