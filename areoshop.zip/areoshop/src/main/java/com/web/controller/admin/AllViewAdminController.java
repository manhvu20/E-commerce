package com.web.controller.admin;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AllViewAdminController {

    @RequestMapping(value = {"/admin/addblog"}, method = RequestMethod.GET)
    public String addblog() {
        return "admin/addblog.html";
    }

    @RequestMapping(value = {"/admin/addproduct"}, method = RequestMethod.GET)
    public String addproduct() {
        return "admin/addproduct.html";
    }

    @RequestMapping(value = {"/admin/adduser"}, method = RequestMethod.GET)
    public String adduser() {
        return "admin/adduser.html";
    }

    @RequestMapping(value = {"/admin/blog"}, method = RequestMethod.GET)
    public String blog() {
        return "admin/blog.html";
    }

    @RequestMapping(value = {"/admin/category"}, method = RequestMethod.GET)
    public String category() {
        return "admin/category.html";
    }

    @RequestMapping(value = {"/admin/doanhthu"}, method = RequestMethod.GET)
    public String doanhthu() {
        return "admin/doanhthu.html";
    }

    @RequestMapping(value = {"/admin/index"}, method = RequestMethod.GET)
    public String index() {
        return "admin/index.html";
    }

    @RequestMapping(value = {"/admin/product"}, method = RequestMethod.GET)
    public String product() {
        return "admin/product.html";
    }

    @RequestMapping(value = {"/admin/stall"}, method = RequestMethod.GET)
    public String stall() {
        return "admin/stall.html";
    }

    @RequestMapping(value = {"/admin/user"}, method = RequestMethod.GET)
    public String user() {
        return "admin/user.html";
    }
}
