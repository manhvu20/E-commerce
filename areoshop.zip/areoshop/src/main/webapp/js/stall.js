async function thongTinShop() {
    var id = window.location.search.split('=')[1];
    var url = 'http://localhost:8080/api/public/shopById?id='+id;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var stall = await response.json();
    document.getElementById("imageshop").src = stall.imageBanner
    document.getElementById("tenshopct").innerHTML = stall.name
    document.getElementById("ngaythamgia").innerHTML = stall.user.createdDate
    document.getElementById("lienhe").innerHTML = stall.email+'<br>'+stall.phone
    document.getElementById("diachishop").innerHTML = stall.stressA+', '+stall.wards.name+', '+stall.wards.districts.name+', '+stall.wards.districts.province.name
    document.getElementById("nhantinchoshop").href = "/chat?user="+stall.user.id+'&shop='+stall.id

    url = 'http://localhost:8080/api/public/soLuongSpCuaShop?id='+id;
    const resp = await fetch(url, { method: 'GET'});
    var soluong = await resp.text();
    document.getElementById("soluongsp").innerHTML = soluong

    url = 'http://localhost:8080/api/public/soLuongCommentShop?id='+id;
    const res = await fetch(url, { method: 'GET'});
    var soluongcm = await res.text();
    document.getElementById("slbinhluan").innerHTML = soluongcm
}

async function danhMucShop() {
    var id = window.location.search.split('=')[1];
    var url = 'http://localhost:8080/api/public/danhMucCuaShop?id='+id;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var list = await response.json();
    var main = '<option value="-1">Tất cả</option>';
    for (i = 0; i < list.length; i++) {
        main += `<option value="${list[i].id}">${list[i].name}</option>`
    }
    document.getElementById("danhmucshop").innerHTML = main
}

async function sanPhamShop() {
    var id = window.location.search.split('=')[1];
    var orderBy = document.getElementById("orderby").value
    var danhmucshop = document.getElementById("danhmucshop").value

    var url = 'http://localhost:8080/api/public/sanPhamCuaShop?id='+id+'&orderBy='+orderBy;
    if(Number(danhmucshop) > 0){
        url = 'http://localhost:8080/api/public/sanPhamCuaShop?id='+id+'&orderBy='+orderBy+'&iddanhmuc='+danhmucshop;
    }
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var list = await response.json();
    var main = '';
    for (i = 0; i < list.length; i++) {
        var noiBan = ''
        if(list[i].stall.wards != null){
            noiBan = list[i].stall.wards.districts.province.name
        }
        main += `<div class="col-sm-3 singleproduct">
                    <div class="noidungsp">
                        <img class="imgsingleproduct" src="${list[i].banner}">
                        <div class="thongtinsp">
                            <h4 class="tensp"><a href="detail?id=${list[i].id}">${list[i].name}</a></h4>
                            <p class="pricesp">${formatmoney(list[i].price)}</p>
                            <p class="dabanps">Đã bán: <span class="daban">${list[i].doanhSo}</span></p>
                            <p class="diachisp">${noiBan}</p>
                        </div>
                    </div>
                </div>`
    }
    document.getElementById("listspshop").innerHTML = main
}