package com.web.repository;

import com.web.entity.Province;
import com.web.entity.VoucherCustomer;
import com.web.entity.VoucherProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.sql.Date;
import java.util.List;

public interface VoucherCustomerRepository extends JpaRepository<VoucherCustomer, Long> {

    @Query("select v from VoucherCustomer v where v.stall.id = ?1")
    public List<VoucherCustomer> findByStall(Long stallId);

    @Query("select v from VoucherCustomer v where v.stall.id = ?1 and v.startDate <= ?2 and v.endDate >= ?2")
    public List<VoucherCustomer> findByStallDangDienRa(Long stallId, Date date);

    @Query("select v from VoucherCustomer v where v.stall.id = ?1 and v.startDate > ?2")
    public List<VoucherCustomer> findByStallSapDienRa(Long stallId, Date date);

    @Query("select v from VoucherCustomer v where v.stall.id = ?1 and v.endDate < ?2")
    public List<VoucherCustomer> findByStallDaKetThuc(Long stallId, Date date);

    @Query("select v from VoucherCustomer v where v.stall.id = ?1 and (v.maxNumber > v.numUsed) and v.startDate <= ?2 and v.endDate >= ?2")
    public List<VoucherCustomer> findByStallDangDienRaConLai(Long stallId, Date date);
}
