$(document).ready(function() {
    loadmenu();
    checkroleSaler();
    function loadmenu(){
        var menu =
        `<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav menuadminleft">
               <a class="nav-link navcha" href="order">
                    <div class="sb-nav-link-icon"><i class="fa fa-list"></i></div>
                    Quản lý đơn hàng
                </a>
                <a class="nav-link collapsed navcha" href="#" data-bs-toggle="collapse" data-bs-target="#collapseShop" aria-expanded="false" aria-controls="collapseShop">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Thiết lập tài khoản
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseShop" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="account">Tài khoản</a>
                        <a class="nav-link" href="account#diachim">Địa chỉ</a>
                    </nav>
                </div>
                <a class="nav-link navcha" href="#" onclick="logout()">
                    <div class="sb-nav-link-icon"><i class="fa fa-sign-out" aria-hidden="true"></i></div>
                    Đăng xuất
                </a>
            </div>
        </div>
    </nav>`
    document.getElementById("layoutSidenav_nav").innerHTML = menu
    }
    loadtop();
    function loadtop(){
        var top =
        `<a style="color:#999" class="navbar-brand ps-3" href="index"><i class="fa fa-shopping-bag tagilogo"></i> Quản lý đơn hàng</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0"></form>
        <ul id="menuleft" class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li></li>
            <li><img style="width:30px" alt="" src="../image/lich.png"></li>
            <li><a id="ngayhientai"></a>
            </li>
            <li><a id="digital-clock"></a></li>
            <li><a href=""><i class="fa fa-user"></i>Xin chào: <span id="userlogged">sss</span></a></li>
            <li><a onclick="logout()" class="poiter"><i class="fas fa-sign-out-alt"></i>Đăng xuất</a></li>
        </ul>`
        document.getElementById("top").innerHTML = top
        document.getElementById("userlogged").innerHTML =localStorage.getItem("username")
    }
    var sidebarToggle = document.getElementById("sidebarToggle");
    sidebarToggle.onclick = function(){
        document.body.classList.toggle('sb-sidenav-toggled');
        localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
    }
});
async function logout(){
    localStorage.removeItem("token");
    localStorage.removeItem("roleweb");
    localStorage.removeItem("role");
    localStorage.removeItem("user");
    window.location.replace('../logout')
}


function formatmoney(money) {
    const VND = new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND',
      });
    return VND.format(money);
}

function getDateTime() {
    var now = new Date();
    var year = now.getFullYear();
    var month = now.getMonth() + 1;
    var day = now.getDate();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();//
    var a = 0;
    //
    if (month.toString().length == 1) {
        month = '0' + month;
    }
    if (day.toString().length == 1) {
        day = '0' + day;
    }
    if (hour.toString().length == 1) {
        hour = '0' + hour;
    }
    if (minute.toString().length == 1) {
        minute = '0' + minute;
    }
    if (second.toString().length == 1) {
        second = '0' + second;
    }
    var dateTime = year + '/' + month + '/' + day + ' ' + hour + ':'
        + minute + ':' + second;
    return dateTime;
}
setInterval(function () {
    currentTime = getDateTime();
    document.getElementById("digital-clock").innerHTML = currentTime;
}, 1000);

var date = new Date();

var current_day = date.getDay();

var day_name = '';

switch (current_day) {
    case 0:
        day_name = "Chủ nhật";
        break;
    case 1:
        day_name = "Thứ hai";
        break;
    case 2:
        day_name = "Thứ ba";
        break;
    case 3:
        day_name = "Thứ tư";
        break;
    case 4:
        day_name = "Thứ năm";
        break;
    case 5:
        day_name = "Thứ sáu";
        break;
    case 6:
        day_name = "Thứ bảy";
}

setInterval(
    function () {
        // $("#here").load(window.location.href + " #here");
        // $("#lienHeMoi").load(window.location.href + " #lienHeMoi");
        // $("#donHangMoi")
        //     .load(window.location.href + " #donHangMoi");
        // if (parseInt(document.getElementById("list").innerHTML) < parseInt(document
        //     .getElementById("listCurrent").innerHTML)) {
        //     Swal.fire('Bạn có thông báo mới!', 'Nhấn "Ok" để hủy',
        //         'warning')
        //     $("#here1").load(window.location.href + " #here1");

        // }

}, 10000);

var token = localStorage.getItem("token");
async function checkMyShop() {
    var url = 'http://localhost:8080/api/saler/mystall';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var stall = await response.json();
    if(stall.name == null || stall.name == ""){
        swal({
            title: "Thông báo", 
            text: "hãy cập nhật thông tin shop của bạn!", 
            type: "warning"
            },
        function(){ 
            window.location.replace('account')
        });
    }
}

async function checkroleSaler(){
    var token = localStorage.getItem("token");
    var url = 'http://localhost:8080/api/shipper/checkroleShipper';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if(response.status > 300){
        window.location.replace('../login')
    }
}