package com.web.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "list_voucher_product")
@Getter
@Setter
public class ProductVoucherProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "voucherProduct_id")
//    @JsonBackReference
    private VoucherProduct voucherProduct;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;
}
