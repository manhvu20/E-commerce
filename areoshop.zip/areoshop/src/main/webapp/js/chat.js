
var stompClient = null;

$( document ).ready(function() {
    var user = localStorage.getItem("user");
    if(user != null){
        user = JSON.parse(user)
        var username = user.username;
        connect(username);
    }
});

function connect(username) {
    var socket = new SockJS('/hello');
    stompClient = Stomp.over(socket);
    stompClient.connect({ username: username, }, function() {
        console.log('Web Socket is connected');
        stompClient.subscribe('/users/queue/messages', function(msg) {
            var Idsender = msg.headers.sender
            var isFile = msg.headers.isFile
            if(Number(isFile) === Number(0)){
                appendTinNhanDen(msg.body, Idsender)
            }
            else{
                appendFileTinNhanDen(msg.body, Idsender)
            }
        });

    });
}


$( document ).ready(function() {
    var uls = new URL(document.URL)
    var id = uls.searchParams.get("user");
    $("#sendmess").click(function() {
        stompClient.send("/app/hello/"+id, {}, $("#contentmess").val());
        append()
    });
    $('#contentmess').keypress(function (e) {
        var key = e.which;
        if(key == 13)  // the enter key code
        {
            stompClient.send("/app/hello/"+id, {}, $("#contentmess").val());
            append()
        }
    });
});

async function sendFile(){
    const file = document.getElementById("btnsendfile").files[0];
    if (file) {
        if (!isImageFile(file)) {
            toastr.error('Đây không phải là file ảnh');
            return;
        }
    }
    const filePath = document.getElementById('btnsendfile')
    const formData = new FormData()
    formData.append("file", filePath.files[0])
    var urlUpload = 'http://localhost:8080/api/public/upload';
    const res = await fetch(urlUpload, {
        method: 'POST',
        body: formData
    });
    if(res.status < 300){
        var linkimage = await res.text();
        appendFile(linkimage)
        var uls = new URL(document.URL)
        var id = uls.searchParams.get("user");
        stompClient.send("/app/file/"+id+"/"+document.getElementById("btnsendfile").files[0].name, {}, linkimage);
    }

}
function isImageFile(file) {
    const fileType = file.type;
    return fileType.startsWith('image/');
}

// nối vào đoạn chat ngay sau khi gửi
function append() {
    var tinhan = `<p class="mychat">${$("#contentmess").val()}</p>`
    document.getElementById('listchatadmin').innerHTML += tinhan;
    var scroll_to_bottom = document.getElementById('listchatadmin');
    scroll_to_bottom.scrollTop = scroll_to_bottom.scrollHeight;
    document.getElementById("contentmess").value = ''
}

function appendFile(link) {
    const newChatElement = document.createElement('img');
    newChatElement.className = "mychatimg";
    newChatElement.src = link;
    document.getElementById('listchatadmin').appendChild(newChatElement);
    var scroll_to_bottom = document.getElementById('listchatadmin');
    scroll_to_bottom.scrollTop = scroll_to_bottom.scrollHeight;
}

function appendTinNhanDen(mess, Idsender) {
    var uls = new URL(document.URL)
    var id = uls.searchParams.get("user");

    if(Idsender != id){
        return;
    }

    const newChatElement = document.createElement('p');
    newChatElement.className = "adminchat";
    newChatElement.textContent = mess;
    document.getElementById('listchatadmin').appendChild(newChatElement);
    var scroll_to_bottom = document.getElementById('listchatadmin');
    scroll_to_bottom.scrollTop = scroll_to_bottom.scrollHeight;
}

function appendFileTinNhanDen(mess, Idsender) {
    var uls = new URL(document.URL)
    var id = uls.searchParams.get("user");
    if(Idsender != id){
        return;
    }
    const newChatElement = document.createElement('img');
    newChatElement.className = "adminimg";
    newChatElement.src = mess;
    document.getElementById('listchatadmin').appendChild(newChatElement);
    var scroll_to_bottom = document.getElementById('listchatadmin');
    scroll_to_bottom.scrollTop = scroll_to_bottom.scrollHeight;
}

async function loadMyChat() {
    var uls = new URL(document.URL)
    var id = uls.searchParams.get("user");
    var shop = uls.searchParams.get("shop");
    if(id == null){
        return;
    }
    const res = await fetch('http://localhost:8080/api/public/shopById?id='+shop, {});
    var stall = await res.json();
    document.getElementById("tenshop").innerHTML = stall.name

    var url = 'http://localhost:8080/api/chat/user/getListChat?idreciver='+id;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var list = await response.json();
    var user = localStorage.getItem("user");
    user = JSON.parse(user);
    var main = '';
    for (i = 0; i < list.length; i++) {
        if(list[i].sender.id == user.id){
            if(list[i].isFile != true){
                main += `<p class="mychat">${list[i].content}</p>`
            }
            else{
                main += `<img class="mychatimg" src="${list[i].content}">`
            }
        }
        else{
            if(list[i].isFile != true){
                main += `<p class="adminchat">${list[i].content}</p>`
            }
            else{
                main += `<img class="adminimg" src="${list[i].content}">`
            }
        }
    }
    document.getElementById("listchatadmin").innerHTML = main
    var scroll_to_bottom = document.getElementById('listchatadmin');
    scroll_to_bottom.scrollTop = scroll_to_bottom.scrollHeight;
    document.getElementById("contentmess").value = ''
}

async function loadUserChat(){
    var search = document.getElementById("keysearchuser").value
    const response = await fetch('http://localhost:8080/api/chat/user/getAllUserChat?search='+search, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    var list = await response.json();
    var uls = new URL(document.URL)
    var shop = uls.searchParams.get("shop");
    var main = ``;
    for(i=0; i<list.length; i++){
        main += `<div onclick="window.location.href='chat?user=${list[i].user.id}&shop=${list[i].id}'" class="pointer trhoverchat ${shop == list[i].id?'activetrhoverchat':''}">
                    <span>${list[i].name}</span>
                    <span class="timechat">${list[i].user.username}</span>
                </div>`
    }
    document.getElementById("listuserchat").innerHTML = main;
}
