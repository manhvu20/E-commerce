var token = localStorage.getItem("token");
async function clickChonLoaiKm(e, type){
    var listcn = document.getElementById("ulloaiVoucherSp").children;
    for(j=0; j<listcn.length; j++){
        listcn[j].classList.remove("activechon");
    }
    e.classList.add("activechon");
    loadMyVoucherProduct(type);
}

async function loadMyProduct() {
    var search = "";
    var url = 'http://localhost:8080/api/saler/Myproduct?statuspro=-1&search='+search;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var list = await response.json();
    var main = "";
    for (i = 0; i < list.length; i++) {
        main += `<option value="${list[i].id}">${list[i].name}</option>`
    }
    document.getElementById("listsp").innerHTML = main
    document.getElementById("listsp").classList.add("selectpicker");
    $('.selectpicker').selectpicker();
}

async function loadMyVoucherProduct(type) {
    var url = 'http://localhost:8080/api/saler/myVoucherProductAndType?type='+type;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var list = await response.json();
    var main = "";
    for (i = 0; i < list.length; i++) {
        main += `<tr>
                    <td>${list[i].code}</td>
                    <td>${list[i].name}</td>
                    <td>${list[i].startDate}</td>
                    <td>${list[i].endDate}</td>
                    <td>2023-02-19</td>
                    <td>${list[i].discount} %</td>
                    <td>${list[i].maxNumber}</td>
                    <td>${list[i].numUsed}</td>
                    <td>
                        <p onclick="deleteVoucherSp(${list[i].id})" class="poiter">Hủy</p>
                        <a onclick="loadVPById(${list[i].id})" data-bs-toggle="modal" data-bs-target="#modalthemvcsp" class="poiter">Cập nhật</a>
                    </td>
                </tr>`
    }
    document.getElementById("listvoucher").innerHTML = main
}

async function loadVPById(id) {
    var url = 'http://localhost:8080/api/public/voucherProductByID?id='+id;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var vou = await response.json();
    document.getElementById("tenvcsp").value = vou.name
    document.getElementById("mvcsp").value = vou.code
    document.getElementById("tungay").value = vou.startDate
    document.getElementById("denngay").value = vou.endDate
    document.getElementById("phantramsp").value = vou.discount
    document.getElementById("soluottoidasp").value = vou.maxNumber
    document.getElementById("idvcsp").value = vou.id

    var listpro = []
    var url = 'http://localhost:8080/api/public/voucherProByVoucher?id='+id;
    const res = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var listv = await res.json();
    for(i=0; i<listv.length; i++){
        listpro.push(listv[i].product.id)
    }
    console.log(listpro)
    $("#listsp").val(listpro)
}

async function clearThemVcSp() {
    document.getElementById("tenvcsp").value = ""
    document.getElementById("mvcsp").value = ""
    document.getElementById("tungay").value = ""
    document.getElementById("denngay").value = ""
    document.getElementById("phantramsp").value = ""
    document.getElementById("soluottoidasp").value = ""
    document.getElementById("idvcsp").value = ""
    $("#listsp").val(-1)
}

async function saveVoucherSp() {
    var url = 'http://localhost:8080/api/saler/addVoucherProduct';

    var idvcsp = document.getElementById("idvcsp").value
    var tenvcsp = document.getElementById("tenvcsp").value
    var mvcsp = document.getElementById("mvcsp").value
    var tungay = document.getElementById("tungay").value
    var denngay = document.getElementById("denngay").value
    var phantramsp = document.getElementById("phantramsp").value
    var soluottoidasp = document.getElementById("soluottoidasp").value
    var listsp = $("#listsp").val();

    var voucher = {
        "voucherProduct":{
            "id":idvcsp,
            "code":mvcsp,
            "name":tenvcsp,
            "discount":phantramsp,
            "startDate":tungay,
            "endDate":denngay,
            "maxNumber":soluottoidasp,
        },
        "productIds":listsp
    }

    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(voucher)
    });
    if(response.status < 300){
        swal({
            title: "Thông báo", 
            text: "thêm/sửa voucher thành công!", 
            type: "success"
          },
        function(){ 
            window.location.reload();
        });
    }
    else{
        swal({
            title: "Thông báo", 
            text: "thêm/sửa voucher thất bại!", 
            type: "error"
          },
        function(){ 
        });
    }
}

async function deleteVoucherSp(id){
    var con = confirm("bạn chắc chắn muốn hủy voucher này?");
    if(con){
        var url = 'http://localhost:8080/api/saler/deleteVoucherProduct?id='+id;
        const response = await fetch(url, {
            method: 'DELETE',
            headers: new Headers({
                'Authorization': 'Bearer ' + token
            })
        });
        if(response.status < 300){
            swal({
                title: "Notification", 
                text: "xóa voucher thành công!", 
                type: "success"
                },
            function(){ 
                window.location.reload();
            });
        }
        else{
            swal({
                title: "Notification", 
                text: "thất bại!", 
                type: "error"
                },
            function(){ 
                window.location.reload();
            });
        }
    }
}



async function clickChonLoaiKmCus(e, type){
    var listcn = document.getElementById("ulloaiVoucherCustomer").children;
    for(j=0; j<listcn.length; j++){
        listcn[j].classList.remove("activechon");
    }
    e.classList.add("activechon");
    loadMyVoucherCustomer(type);
}

async function loadMyVoucherCustomer(type) {
    var url = 'http://localhost:8080/api/saler/myVoucherCustomerAndType?type='+type;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var list = await response.json();
    var main = "";
    for (i = 0; i < list.length; i++) {
        main += `<tr>
                    <td>${list[i].code}</td>
                    <td>${list[i].name}</td>
                    <td>${list[i].startDate}</td>
                    <td>${list[i].endDate}</td>
                    <td>${list[i].quantityPurchased} %</td>
                    <td>${list[i].discount} %</td>
                    <td>${list[i].maxNumber}</td>
                    <td>${list[i].numUsed}</td>
                    <td>
                        <p onclick="deleteVoucherCus(${list[i].id})" class="poiter">Hủy</p>
                        <a onclick="loadVoucherCusById(${list[i].id})" data-bs-toggle="modal" data-bs-target="#modalthemvckh" class="poiter">Cập nhật</a>
                    </td>
                </tr>`
    }
    document.getElementById("listvouchercustomer").innerHTML = main
}


async function loadVoucherCusById(id) {
    var url = 'http://localhost:8080/api/public/voucherCustomerByID?id='+id;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var vou = await response.json();
    document.getElementById("tenvckh").value = vou.name
    document.getElementById("mavckh").value = vou.code
    document.getElementById("tungaykh").value = vou.startDate
    document.getElementById("denngaykh").value = vou.endDate
    document.getElementById("phantramkh").value = vou.discount
    document.getElementById("soluongvcmax").value = vou.maxNumber
    document.getElementById("idvckh").value = vou.id
    document.getElementById("soluongtt").value = vou.quantityPurchased
}


async function clearThemVcCus() {
    document.getElementById("tenvckh").value = ""
    document.getElementById("mavckh").value = ""
    document.getElementById("tungaykh").value = ""
    document.getElementById("denngaykh").value = ""
    document.getElementById("phantramkh").value = ""
    document.getElementById("soluongvcmax").value = ""
    document.getElementById("idvckh").value = ""
    document.getElementById("soluongtt").value = ""
}


async function saveVoucherKhachhang() {
    var url = 'http://localhost:8080/api/saler/addVoucherCustomer';

    var idvckh = document.getElementById("idvckh").value
    var tenvckh = document.getElementById("tenvckh").value
    var mavckh = document.getElementById("mavckh").value
    var tungaykh = document.getElementById("tungaykh").value
    var denngaykh = document.getElementById("denngaykh").value
    var phantramkh = document.getElementById("phantramkh").value
    var soluongtt = document.getElementById("soluongtt").value
    var soluongvcmax = document.getElementById("soluongvcmax").value

    var voucher = {
        "id":idvckh,
        "code":mavckh,
        "name":tenvckh,
        "discount":phantramkh,
        "startDate":tungaykh,
        "endDate":denngaykh,
        "maxNumber":soluongvcmax,
        "quantityPurchased":soluongtt
    }

    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(voucher)
    });
    if(response.status < 300){
        swal({
            title: "Thông báo", 
            text: "thêm/sửa voucher thành công!", 
            type: "success"
          },
        function(){ 
            window.location.reload();
        });
    }
    else{
        swal({
            title: "Thông báo", 
            text: "thêm/sửa voucher thất bại!", 
            type: "error"
          },
        function(){ 
        });
    }
}


async function deleteVoucherCus(id){
    var con = confirm("bạn chắc chắn muốn hủy voucher này?");
    if(con){
        var url = 'http://localhost:8080/api/saler/deleteVoucherCustomer?id='+id;
        const response = await fetch(url, {
            method: 'DELETE',
            headers: new Headers({
                'Authorization': 'Bearer ' + token
            })
        });
        if(response.status < 300){
            swal({
                title: "Notification", 
                text: "xóa voucher thành công!", 
                type: "success"
                },
            function(){ 
                window.location.reload();
            });
        }
        else{
            swal({
                title: "Notification", 
                text: "thất bại!", 
                type: "error"
                },
            function(){ 
                window.location.reload();
            });
        }
    }
}