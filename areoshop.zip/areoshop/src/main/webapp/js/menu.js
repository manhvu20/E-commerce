async function loadMenu(){
    var authen = `<li class="nav-item"><a class="nav-link" href="login">Đăng nhập</a></li>`
    var ur = '';
    var token = localStorage.getItem("token");
    var roleweb = localStorage.getItem("roleweb");
    var ctl = ``
    var topctl = `<p class="textmenu linkdangnhap lefts"><a href="login">Đăng ký / Đăng nhập</a></p>`
    if(roleweb == "ROLE_ADMIN"){
        ctl = `<li><a class="dropdown-item" href="/admin/index">Trang quản trị</a></li>`
        topctl = `<p class="textmenu linkdangnhap lefts"><a href="/admin/index">Trang quản trị</a></p>`
    }
    if(roleweb == "ROLE_SALER"){
        ctl = `<li><a class="dropdown-item" href="/saler/index">Trang người bán</a></li>`
        topctl = `<p class="textmenu linkdangnhap lefts"><a href="/saler/index">Trang người bán</a></p>`
    }
    if(roleweb == "ROLE_USER"){
        ctl = ` <li><a class="dropdown-item" href="account">Đơn mua</a></li>
                 <li><a class="dropdown-item" href="account">Thông tin tài khoản</a></li>
                <li><a class="dropdown-item" href="chat">Nhắn tin cho shop</a></li>`
        topctl = `<p class="textmenu linkdangnhap lefts"><a href="account">Đơn hàng</a></p>`
    }
    if(token != null){
        authen = `<li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Tài khoản
                    </a>
                    <ul id="authens" class="dropdown-menu" aria-labelledby="navbarDropdown">
                        ${ctl}
                      <li><a class="dropdown-item" href="#" onclick="logout()">Đăng xuất</a></li>
                    </ul>
                  </li>`
        ur = `<a href="login"><i class="fa fa-user iconmenu"></i></a>`
    }

    var menu = 
    `<div class="container">
    <div class="row">
        <div class="col-sm-6 menutopleft">
          <p class="textmenu kenhnguoiban"><a href="saler/index">Kênh người bán</a></p>
          <p class="textmenu kenhnguoiban rights"><a href="">Tải ứng dụng</a></p>
          <p class="textmenu kenhnguoiban rights"><a href="">Kết nối</a></p>
        </div>
        <div class="col-sm-6 menutopright">
          ${topctl}
          <p class="textmenu linkdangnhap"><a href="">Hỗ trợ</a></p>
        </div>
        <div class="col-sm-12 menuduoi">
            <div class="divlogo">
                <a href="index"><img class="imglogo" src="image/logo.png"></a>
            </div>
            <div class="divsearch">
                <div class="thanhsearch">
                    <form class="row" action="product">
                        <div class="col-8">
                          <input name="search" class="inpursearch" placeholder="Tìm kiếm gì đó!">
                        </div>
                        <div class="col-4">
                          <button class="btnsearch"><i class="fa fa-search"></i></button>
                        </div>
                    </form>
                </div>
                <div class="col-12">
                  <nav class="navbar navbar-expand-lg">
                    <button class="navbar-toggler" style="border: 2px solid #fff;padding: 0; width: 40px; padding-left: 5px; padding-right: 5px; padding-top: 5px;" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                      <div class="icon-bars">&ThinSpace;</div>
                      <div class="icon-bars"></div>
                      <div class="icon-bars"></div>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link" href="index">Trang chủ</a></li>
                        <li class="nav-item"><a class="nav-link" href="chinhsach">Chính sách</a></li>
                        <li class="nav-item"><a class="nav-link" href="blog">Bài viết</a></li>
                        <li class="nav-item"><a class="nav-link" href="product">Sản phẩm</a></li>
                        <li class="nav-item dropdown">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Danh mục
                          </a>
                          <ul id="listcategoryheader" class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                          </ul>
                        </li>
                        ${authen}
                      </ul>
                  </div>
              </nav>
                </div>
            </div>
            <div class="divcart">
                <a href="cart"><i class="fa fa-shopping-cart"></i> <span class="slcartmenu" id="slcartmenu">0</span></a>
            </div>
        </div>
    </div>
</div>`
    document.getElementById("menu").innerHTML = menu
    loadDanhMucMenu();
    loadCartMenu();
    try {
      loadFooter();
    } catch (error) {
      
    }
}

async function loadDanhMucMenu() {
  var url = 'http://localhost:8080/api/public/allcategory';
  const response = await fetch(url, {
      method: 'GET',
      headers: new Headers({
      })
  });
  var list = await response.json();
  var main = '';
  for (i = 0; i < list.length; i++) {
      main += `<li><a class="dropdown-item" href="product?category=${list[i].id}">${list[i].name}</a></li>`
  }
  document.getElementById("listcategoryheader").innerHTML = main
}

function loadFooter(){
    var footer = 
    `   <div class="container">
    <footer class="text-center text-lg-start text-muted">
    <section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
      <div class="me-5 d-none d-lg-block"><span>Theo dõi chúng tôi tại:</span></div>
      <div>
        <a href="" class="me-4 text-reset"><i class="fab fa-facebook-f"></i></a>
        <a href="" class="me-4 text-reset"><i class="fab fa-twitter"></i></a>
        <a href="" class="me-4 text-reset"><i class="fab fa-google"></i></a>
        <a href="" class="me-4 text-reset"><i class="fab fa-instagram"></i></a>
        <a href="" class="me-4 text-reset"><i class="fab fa-linkedin"></i></a>
        <a href="" class="me-4 text-reset"><i class="fab fa-github"></i></a>
      </div>
    </section>
    <section class="">
      <div class=" text-center text-md-start mt-5">
        <div class="row mt-3">
          <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
            <h6 class="text-uppercase fw-bold mb-4"><i class="fas fa-gem me-3"></i>Areo-Shop</h6>
            <p>
                MST: 0107934154 cấp ngày 24/7/2017 do Sở KH&ĐT TP Hà Nội cấp<br><br>
                VPGD: số 4 ngách 515/24 Hoàng Hoa Thám, Vĩnh Phúc, Ba Đình, Hà Nội
            </p>
          </div>
          <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
            <h6 class="text-uppercase fw-bold mb-4">Sản phẩm</h6>
            <p><a href="#!" class="text-reset">Uy tín</a></p>
            <p><a href="#!" class="text-reset">Chất lượng</a></p>
            <p><a href="#!" class="text-reset">Nguồn gốc rõ ràng</a></p>
            <p><a href="#!" class="text-reset">Giá rẻ</a></p>
          </div>
          <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
            <h6 class="text-uppercase fw-bold mb-4">Dịch vụ</h6>
            <p><a href="#!" class="text-reset">24/7</a></p>
            <p><a href="#!" class="text-reset">bảo hành 6 tháng</a></p>
            <p><a href="#!" class="text-reset">free ship</a></p>
            <p><a href="#!" class="text-reset">lỗi 1 đổi 1</a></p>
          </div>
          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
            <h6 class="text-uppercase fw-bold mb-4">Liên hệ</h6>
            <input class="form-control" placeholder="Họ tên"><br>
            <input class="form-control" placeholder="Email"><br>
            <textarea class="form-control" placeholder="tin nhắn"></textarea><br>
            <button class="btn btn-primary form-control">Gửi</button><br>
          </div>
        </div>
      </div>
    </section>
  </footer>
    </div>`
    document.getElementById("footer").innerHTML = footer
}

function formatmoney(money) {
  const VND = new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
  });
  return VND.format(money);
}

async function logout(){
  localStorage.removeItem("token");
  localStorage.removeItem("roleweb");
  localStorage.removeItem("user");
  window.location.replace("logout")
}

async function checkroleUser(){
  var token = localStorage.getItem("token");
  var url = 'http://localhost:8080/api/user/checkroleUser';
  const response = await fetch(url, {
      method: 'GET',
      headers: new Headers({
          'Authorization': 'Bearer ' + token
      })
  });
  if(response.status > 300){
      window.location.replace('login')
  }
}

async function loadCartMenu() {
    var search ="";
    var url = 'http://localhost:8080/api/user/gioHangCuaToi?search='+search;
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if(response.status < 300){
        var list = await response.json();
        document.getElementById("slcartmenu").innerHTML = list.length
    }
}