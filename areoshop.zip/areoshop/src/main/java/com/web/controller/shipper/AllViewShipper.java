package com.web.controller.shipper;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AllViewShipper {

    @RequestMapping(value = {"/shipper/account"}, method = RequestMethod.GET)
    public String account() {
        return "shipper/account.html";
    }

    @RequestMapping(value = {"/shipper/order"}, method = RequestMethod.GET)
    public String order() {
        return "shipper/order.html";
    }
}
