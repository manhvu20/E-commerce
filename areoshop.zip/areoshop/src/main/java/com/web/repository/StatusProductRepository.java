package com.web.repository;

import com.web.entity.Province;
import com.web.entity.StatusProduct;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatusProductRepository extends JpaRepository<StatusProduct, Long> {
}
