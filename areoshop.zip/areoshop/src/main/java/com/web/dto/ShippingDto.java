package com.web.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShippingDto {

    private Double shipCost;

    private Long staffId;
}
