var token = localStorage.getItem("token");

async function clickChonLoaiSp(e, idstatus){
    var listcn = document.getElementById("ulloaidonhang").children;
    for(j=0; j<listcn.length; j++){
        listcn[j].classList.remove("activechon");
    }
    e.classList.add("activechon");
    loadSanPham(idstatus, null,"");
}

async function loadCategory() {
    var url = 'http://localhost:8080/api/public/allcategory';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var listcategory = await response.json();
    var main = '<option value="">Tất cả danh mục</option>';
    for (i = 0; i < listcategory.length; i++) {
        main += '<option value="'+listcategory[i].id+'">'+listcategory[i].name+'</option>'
    }
    document.getElementById("danhmuc").innerHTML = main
}

async function loadAllStatusProduct() {
    var url = 'http://localhost:8080/api/public/statusproduct';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
        })
    });
    var list = await response.json();
    var main = '<li onclick="clickChonLoaiSp(this,null)" class="chonloaihang activechon">Tất cả</li>';
    for (i = 0; i < list.length; i++) {
        main += `<li onclick="clickChonLoaiSp(this,${list[i].id})" class="chonloaihang">${list[i].name}</li>`
    }
    document.getElementById("ulloaidonhang").innerHTML = main
}

var idst = null;
async function loadSanPham(idstatus, danhmuc, search) {
    $('#example').DataTable().destroy();
    idst = idstatus;
    var url = 'http://localhost:8080/api/admin/sanPhamAdmin?search='+search;
    if(idstatus != null){
        url = 'http://localhost:8080/api/admin/sanPhamAdmin?idtrangthai='+idstatus+'&search='+search;
    }
    if(danhmuc != null){
        url = 'http://localhost:8080/api/admin/sanPhamAdmin?iddanhmuc='+danhmuc+'&search='+search;
    }
    if(danhmuc != null && idstatus != null){
        url = 'http://localhost:8080/api/admin/sanPhamAdmin?iddanhmuc='+danhmuc+'&search='+search+'&idtrangthai='+idstatus;
    }
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({'Authorization': 'Bearer ' + token})
    });
    var list = await response.json();
    var main = '';
    for (i = 0; i < list.length; i++) {
        var xembl = `<p data-bs-toggle="modal" data-bs-target="#modalbinhluan" class="poiter">Xem đánh giá</p>`
        var dmuc = ''
        for(j=0; j<list[i].productCategories.length; j++){
            dmuc += list[i].productCategories[j].category.name +"<br>"
        }
        var viphn = `<a onclick="setIdSpViPham(${list[i].id})" data-bs-toggle="modal" data-bs-target="#vipham" class="poiter">Vi phạm</a>`
        if(list[i].statusProduct.id == 3){
            viphn = `<a onclick="huyViPham(${list[i].id})" class="poiter">Hủy vi phạm</a>`
        }
        main += `<tr id="trsanpham${list[i].id}">
                    <td>${list[i].stall.name}</td>
                    <td>${list[i].id}</td>
                    <td><img src="${list[i].banner}" style="width: 100px;"></td>
                    <td>${list[i].name}</td>
                    <td>${formatmoney(list[i].price)}</td>
                    <td>${list[i].quantity}</td>
                    <td>${list[i].doanhSo}</td>
                    <td>${dmuc}</td>
                    <td>
                        ${viphn}
                    </td>
                    <td>${xembl}</td>
                </tr>`
    }
    document.getElementById("listproduct").innerHTML = main
    document.getElementById("soluongsp").innerHTML = list.length
    $('#example').DataTable();
}

function timKiemSp(){
    var search = document.getElementById("searchparam").value;
    var danhmuc = document.getElementById("danhmuc").value;
    if(danhmuc == ""){
        danhmuc = null
    }
    loadSanPham(idst, danhmuc, search);
}


async function setViPham() {
    var noidung = document.getElementById("noidungvipham").value
    var id = document.getElementById("idspvipham").value

    var url = 'http://localhost:8080/api/admin/setSanPhamViPham?id=' + id +'&noidung='+noidung;
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({
            title: "Thông báo", 
            text: "Thành công!", 
            type: "success"
          },
        function(){ 
            window.location.reload();
        });
    }
}

function setIdSpViPham(id){
    document.getElementById("idspvipham").value = id;
}


async function huyViPham(id) {
    var url = 'http://localhost:8080/api/admin/setSanPhamViPham?id=' + id +'&noidung=';
    const response = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if (response.status < 300) {
        swal({
            title: "Thông báo", 
            text: "Thành công!", 
            type: "success"
          },
        function(){ 
            window.location.reload();
        });
    }
}
